"use client"

import { useEffect, useState } from "react"
import { Activity } from "lucide-react"

interface SplashScreenProps {
  onComplete?: () => void
  duration?: number
}

export function SplashScreen({ onComplete, duration = 1500 }: SplashScreenProps) {
  const [isVisible, setIsVisible] = useState(true)
  const [isFading, setIsFading] = useState(false)

  useEffect(() => {
    const fadeTimer = setTimeout(() => {
      setIsFading(true)
    }, duration - 300)

    const completeTimer = setTimeout(() => {
      setIsVisible(false)
      onComplete?.()
    }, duration)

    return () => {
      clearTimeout(fadeTimer)
      clearTimeout(completeTimer)
    }
  }, [duration, onComplete])

  if (!isVisible) return null

  return (
    <div 
      className={`fixed inset-0 z-[100] bg-background flex flex-col items-center justify-center transition-opacity duration-300 ${
        isFading ? "opacity-0" : "opacity-100"
      }`}
    >
      <div className="flex flex-col items-center gap-4 animate-pulse">
        <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10 border border-primary/30 glow-green-sm">
          <Activity className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-2xl font-bold text-foreground tracking-tight">
          Sight<span className="text-primary">Line</span>
        </h1>
        <p className="text-xs text-muted-foreground">Advanced Trading Analytics</p>
      </div>
    </div>
  )
}
