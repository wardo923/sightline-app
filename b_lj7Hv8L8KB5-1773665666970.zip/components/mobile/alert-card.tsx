"use client"

import { TrendingUp, TrendingDown, Clock, Target, AlertTriangle } from "lucide-react"

interface AlertCardProps {
  asset: string
  setupType: string
  timeframe: string
  bias: "bullish" | "bearish"
  entryZone: string
  stopLoss: string
  target1: string
  target2?: string
  status: "watching" | "triggered" | "target_reached" | "invalidated"
  timestamp?: string
}

const statusConfig = {
  watching: { label: "Watching", color: "bg-amber-500/20 text-amber-500" },
  triggered: { label: "Triggered", color: "bg-primary/20 text-primary" },
  target_reached: { label: "Target Hit", color: "bg-emerald-500/20 text-emerald-500" },
  invalidated: { label: "Invalidated", color: "bg-destructive/20 text-destructive" },
}

export function AlertCard({
  asset,
  setupType,
  timeframe,
  bias,
  entryZone,
  stopLoss,
  target1,
  target2,
  status,
  timestamp,
}: AlertCardProps) {
  const statusInfo = statusConfig[status]
  const BiasIcon = bias === "bullish" ? TrendingUp : TrendingDown
  
  return (
    <div className="rounded-xl border border-border bg-card p-4 card-glow">
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-foreground">{asset}</span>
          <span className="text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded">
            {timeframe}
          </span>
        </div>
        <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${statusInfo.color}`}>
          {statusInfo.label}
        </span>
      </div>
      
      <div className="flex items-center gap-2 mb-3">
        <BiasIcon className={`h-4 w-4 ${bias === "bullish" ? "text-primary" : "text-destructive"}`} />
        <span className={`text-sm font-medium ${bias === "bullish" ? "text-primary" : "text-destructive"}`}>
          {bias === "bullish" ? "Bullish" : "Bearish"}
        </span>
        <span className="text-xs text-muted-foreground">• {setupType}</span>
      </div>
      
      <div className="grid grid-cols-2 gap-3 text-xs">
        <div>
          <p className="text-muted-foreground mb-0.5">Entry Zone</p>
          <p className="font-semibold text-foreground">{entryZone}</p>
        </div>
        <div>
          <p className="text-muted-foreground mb-0.5">Stop Loss</p>
          <p className="font-semibold text-destructive">{stopLoss}</p>
        </div>
        <div>
          <p className="text-muted-foreground mb-0.5">Target 1</p>
          <p className="font-semibold text-primary">{target1}</p>
        </div>
        {target2 && (
          <div>
            <p className="text-muted-foreground mb-0.5">Target 2</p>
            <p className="font-semibold text-primary">{target2}</p>
          </div>
        )}
      </div>
      
      {timestamp && (
        <div className="flex items-center gap-1 mt-3 pt-3 border-t border-border">
          <Clock className="h-3 w-3 text-muted-foreground" />
          <span className="text-[10px] text-muted-foreground">{timestamp}</span>
        </div>
      )}
    </div>
  )
}
