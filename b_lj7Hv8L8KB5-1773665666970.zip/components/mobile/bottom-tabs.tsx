"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Compass, Bell, LayoutDashboard, User } from "lucide-react"

const tabs = [
  { href: "/m/home", label: "Home", icon: Home },
  { href: "/m/wizard", label: "Wizard", icon: Compass },
  { href: "/m/alerts", label: "Alerts", icon: Bell },
  { href: "/m/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/m/account", label: "Account", icon: User },
]

export function BottomTabs() {
  const pathname = usePathname()
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-sm border-t border-border pb-safe">
      <div className="flex items-center justify-around py-2">
        {tabs.map((tab) => {
          const isActive = pathname === tab.href || pathname?.startsWith(`${tab.href}/`)
          const Icon = tab.icon
          
          return (
            <Link
              key={tab.href}
              href={tab.href}
              className={`flex flex-col items-center gap-1 px-3 py-2 min-w-[64px] transition-colors ${
                isActive 
                  ? "text-primary" 
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Icon className={`h-5 w-5 ${isActive ? "drop-shadow-[0_0_8px_rgba(34,197,94,0.5)]" : ""}`} />
              <span className="text-[10px] font-medium">{tab.label}</span>
            </Link>
          )
        })}
      </div>
    </nav>
  )
}
