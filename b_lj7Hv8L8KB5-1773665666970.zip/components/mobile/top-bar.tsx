"use client"

import { Activity } from "lucide-react"

interface TopBarProps {
  title?: string
  showLogo?: boolean
}

export function TopBar({ title, showLogo = true }: TopBarProps) {
  return (
    <header className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border px-4 py-3">
      <div className="flex items-center justify-between">
        {showLogo ? (
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
              <Activity className="h-4 w-4 text-primary" />
            </div>
            <span className="text-lg font-bold text-foreground tracking-tight">
              Sight<span className="text-primary">Line</span>
            </span>
          </div>
        ) : (
          <h1 className="text-lg font-semibold text-foreground">{title}</h1>
        )}
      </div>
    </header>
  )
}
