"use client"

import { ReactNode } from "react"

interface AppShellProps {
  children: ReactNode
  className?: string
}

export function AppShell({ children, className = "" }: AppShellProps) {
  return (
    <div className={`min-h-screen bg-background flex flex-col ${className}`}>
      <div className="flex-1 flex flex-col pt-safe pb-safe pl-safe pr-safe">
        {children}
      </div>
    </div>
  )
}
