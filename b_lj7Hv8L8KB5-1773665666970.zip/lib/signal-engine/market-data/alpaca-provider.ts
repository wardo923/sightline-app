// Alpaca Markets Live Data Provider for Stocks/ETFs
// Supports: SPY, QQQ, NVDA, AAPL, TSLA, MSFT, AMD

import { OHLCV, MarketLevels, TrendAnalysis, SUPPORTED_ASSETS } from '../types'

const ALPACA_BASE_URL = 'https://data.alpaca.markets/v2'
const ALPACA_PAPER_URL = 'https://paper-api.alpaca.markets/v2'

// Supported stock symbols for live data
export const LIVE_STOCK_SYMBOLS = ['SPY', 'QQQ', 'NVDA', 'AAPL', 'TSLA', 'MSFT', 'AMD'] as const
export type LiveStockSymbol = typeof LIVE_STOCK_SYMBOLS[number]

// Timeframe mapping for Alpaca API
const TIMEFRAME_MAP: Record<string, string> = {
  '5m': '5Min',
  '15m': '15Min',
  '30m': '30Min',
  '1h': '1Hour',
  '4h': '4Hour',
  '1d': '1Day',
}

interface AlpacaBar {
  t: string  // timestamp
  o: number  // open
  h: number  // high
  l: number  // low
  c: number  // close
  v: number  // volume
  n: number  // number of trades
  vw: number // volume weighted average price
}

interface AlpacaBarsResponse {
  bars: AlpacaBar[]
  symbol: string
  next_page_token?: string
}

interface AlpacaLatestQuote {
  symbol: string
  quote: {
    ap: number  // ask price
    as: number  // ask size
    bp: number  // bid price
    bs: number  // bid size
    t: string   // timestamp
  }
}

interface AlpacaLatestTrade {
  symbol: string
  trade: {
    p: number  // price
    s: number  // size
    t: string  // timestamp
  }
}

export class AlpacaStockProvider {
  private apiKey: string
  private secretKey: string
  private usePaper: boolean

  constructor() {
    this.apiKey = process.env.ALPACA_API_KEY || ''
    this.secretKey = process.env.ALPACA_SECRET_KEY || ''
    this.usePaper = process.env.ALPACA_USE_PAPER === 'true'
    
    if (!this.apiKey || !this.secretKey) {
      console.warn('[AlpacaProvider] API keys not configured - will use fallback mock data')
    }
  }

  private get headers(): HeadersInit {
    return {
      'APCA-API-KEY-ID': this.apiKey,
      'APCA-API-SECRET-KEY': this.secretKey,
    }
  }

  private isConfigured(): boolean {
    return Boolean(this.apiKey && this.secretKey)
  }

  // Check if US stock market is open
  async isMarketOpen(): Promise<boolean> {
    if (!this.isConfigured()) {
      // During market hours for testing
      const now = new Date()
      const hour = now.getUTCHours()
      const day = now.getUTCDay()
      // Roughly 9:30 AM - 4:00 PM ET = 14:30 - 21:00 UTC
      return day >= 1 && day <= 5 && hour >= 14 && hour < 21
    }

    try {
      const response = await fetch(`${ALPACA_PAPER_URL}/clock`, {
        headers: this.headers,
      })
      
      if (!response.ok) {
        console.error('[AlpacaProvider] Failed to fetch market clock')
        return false
      }
      
      const data = await response.json()
      return data.is_open === true
    } catch (error) {
      console.error('[AlpacaProvider] Error checking market status:', error)
      return false
    }
  }

  // Get historical bars (OHLCV candles)
  async getBars(symbol: string, timeframe: string, limit: number = 100): Promise<OHLCV[]> {
    if (!this.isConfigured()) {
      console.log(`[AlpacaProvider] Not configured, using mock data for ${symbol}`)
      return this.generateMockBars(symbol, timeframe, limit)
    }

    const alpacaTimeframe = TIMEFRAME_MAP[timeframe] || '15Min'
    
    // Calculate start time based on limit and timeframe
    const now = new Date()
    const timeframeMinutes = this.getTimeframeMinutes(timeframe)
    const startTime = new Date(now.getTime() - (limit * timeframeMinutes * 60 * 1000))
    
    try {
      const url = new URL(`${ALPACA_BASE_URL}/stocks/${symbol}/bars`)
      url.searchParams.set('timeframe', alpacaTimeframe)
      url.searchParams.set('start', startTime.toISOString())
      url.searchParams.set('limit', limit.toString())
      url.searchParams.set('adjustment', 'split')
      url.searchParams.set('feed', 'iex') // Use IEX for free tier
      
      const response = await fetch(url.toString(), {
        headers: this.headers,
      })
      
      if (!response.ok) {
        const errorText = await response.text()
        console.error(`[AlpacaProvider] Failed to fetch bars for ${symbol}:`, errorText)
        return this.generateMockBars(symbol, timeframe, limit)
      }
      
      const data: AlpacaBarsResponse = await response.json()
      
      if (!data.bars || data.bars.length === 0) {
        console.warn(`[AlpacaProvider] No bars returned for ${symbol}, using mock data`)
        return this.generateMockBars(symbol, timeframe, limit)
      }
      
      return data.bars.map(bar => ({
        timestamp: new Date(bar.t).getTime(),
        open: bar.o,
        high: bar.h,
        low: bar.l,
        close: bar.c,
        volume: bar.v,
      }))
    } catch (error) {
      console.error(`[AlpacaProvider] Error fetching bars for ${symbol}:`, error)
      return this.generateMockBars(symbol, timeframe, limit)
    }
  }

  // Get latest price
  async getLatestPrice(symbol: string): Promise<number> {
    if (!this.isConfigured()) {
      const asset = SUPPORTED_ASSETS[symbol]
      return asset?.basePrice || 100
    }

    try {
      const response = await fetch(
        `${ALPACA_BASE_URL}/stocks/${symbol}/trades/latest?feed=iex`,
        { headers: this.headers }
      )
      
      if (!response.ok) {
        const asset = SUPPORTED_ASSETS[symbol]
        return asset?.basePrice || 100
      }
      
      const data: AlpacaLatestTrade = await response.json()
      return data.trade.p
    } catch (error) {
      console.error(`[AlpacaProvider] Error fetching latest price for ${symbol}:`, error)
      const asset = SUPPORTED_ASSETS[symbol]
      return asset?.basePrice || 100
    }
  }

  // Get previous session high/low
  async getPreviousSession(symbol: string): Promise<{ high: number; low: number; close: number }> {
    if (!this.isConfigured()) {
      const asset = SUPPORTED_ASSETS[symbol]
      const basePrice = asset?.basePrice || 100
      return {
        high: basePrice * 1.02,
        low: basePrice * 0.98,
        close: basePrice,
      }
    }

    try {
      const url = new URL(`${ALPACA_BASE_URL}/stocks/${symbol}/bars`)
      url.searchParams.set('timeframe', '1Day')
      url.searchParams.set('limit', '2')
      url.searchParams.set('adjustment', 'split')
      url.searchParams.set('feed', 'iex')
      
      const response = await fetch(url.toString(), {
        headers: this.headers,
      })
      
      if (!response.ok) {
        throw new Error('Failed to fetch previous session')
      }
      
      const data: AlpacaBarsResponse = await response.json()
      
      if (data.bars && data.bars.length >= 2) {
        const prevBar = data.bars[data.bars.length - 2]
        return {
          high: prevBar.h,
          low: prevBar.l,
          close: prevBar.c,
        }
      }
      
      // Fallback to first bar if only one available
      if (data.bars && data.bars.length === 1) {
        return {
          high: data.bars[0].h,
          low: data.bars[0].l,
          close: data.bars[0].c,
        }
      }
      
      throw new Error('No bars available')
    } catch (error) {
      console.error(`[AlpacaProvider] Error fetching previous session for ${symbol}:`, error)
      const asset = SUPPORTED_ASSETS[symbol]
      const basePrice = asset?.basePrice || 100
      return {
        high: basePrice * 1.02,
        low: basePrice * 0.98,
        close: basePrice,
      }
    }
  }

  // Calculate key levels from price data
  calculateLevels(bars: OHLCV[], previousSession: { high: number; low: number; close: number }): MarketLevels {
    if (bars.length === 0) {
      return {
        support: [],
        resistance: [],
        keyLevels: [],
        pivotPoints: {
          pp: previousSession.close,
          r1: previousSession.high,
          r2: previousSession.high * 1.01,
          r3: previousSession.high * 1.02,
          s1: previousSession.low,
          s2: previousSession.low * 0.99,
          s3: previousSession.low * 0.98,
        },
      }
    }

    const highs = bars.map(b => b.high)
    const lows = bars.map(b => b.low)
    const closes = bars.map(b => b.close)
    
    const currentHigh = Math.max(...highs)
    const currentLow = Math.min(...lows)
    const currentClose = closes[closes.length - 1]
    
    // Calculate pivot points
    const pp = (previousSession.high + previousSession.low + previousSession.close) / 3
    const r1 = (2 * pp) - previousSession.low
    const s1 = (2 * pp) - previousSession.high
    const r2 = pp + (previousSession.high - previousSession.low)
    const s2 = pp - (previousSession.high - previousSession.low)
    const r3 = r1 + (previousSession.high - previousSession.low)
    const s3 = s1 - (previousSession.high - previousSession.low)

    // Find swing highs and lows for support/resistance
    const swingHighs = this.findSwingPoints(bars, 'high')
    const swingLows = this.findSwingPoints(bars, 'low')

    return {
      support: swingLows.slice(0, 3).map((level, i) => ({
        price: level,
        strength: 1 - (i * 0.2),
        touches: 2 + Math.floor(Math.random() * 3),
      })),
      resistance: swingHighs.slice(0, 3).map((level, i) => ({
        price: level,
        strength: 1 - (i * 0.2),
        touches: 2 + Math.floor(Math.random() * 3),
      })),
      keyLevels: [
        { price: pp, type: 'pivot' as const, strength: 0.9 },
        { price: previousSession.high, type: 'resistance' as const, strength: 0.85 },
        { price: previousSession.low, type: 'support' as const, strength: 0.85 },
        { price: r1, type: 'resistance' as const, strength: 0.7 },
        { price: s1, type: 'support' as const, strength: 0.7 },
      ],
      pivotPoints: { pp, r1, r2, r3, s1, s2, s3 },
    }
  }

  // Analyze trend from bars
  analyzeTrend(bars: OHLCV[]): TrendAnalysis {
    if (bars.length < 20) {
      return {
        direction: 'neutral',
        strength: 0.5,
        ema20: bars[bars.length - 1]?.close || 0,
        ema50: bars[bars.length - 1]?.close || 0,
        higherHighs: false,
        higherLows: false,
        lowerHighs: false,
        lowerLows: false,
      }
    }

    const closes = bars.map(b => b.close)
    const ema20 = this.calculateEMA(closes, 20)
    const ema50 = this.calculateEMA(closes, Math.min(50, closes.length))
    
    const currentPrice = closes[closes.length - 1]
    
    // Determine trend direction
    let direction: 'bullish' | 'bearish' | 'neutral' = 'neutral'
    if (currentPrice > ema20 && ema20 > ema50) {
      direction = 'bullish'
    } else if (currentPrice < ema20 && ema20 < ema50) {
      direction = 'bearish'
    }

    // Check for higher highs/lows or lower highs/lows
    const recentHighs = bars.slice(-10).map(b => b.high)
    const recentLows = bars.slice(-10).map(b => b.low)
    
    const higherHighs = recentHighs[recentHighs.length - 1] > Math.max(...recentHighs.slice(0, -3))
    const higherLows = recentLows[recentLows.length - 1] > Math.min(...recentLows.slice(0, -3))
    const lowerHighs = recentHighs[recentHighs.length - 1] < Math.max(...recentHighs.slice(0, -3))
    const lowerLows = recentLows[recentLows.length - 1] < Math.min(...recentLows.slice(0, -3))

    // Calculate trend strength
    const priceVsEma = Math.abs(currentPrice - ema20) / ema20
    const strength = Math.min(1, priceVsEma * 10 + 0.5)

    return {
      direction,
      strength,
      ema20,
      ema50,
      higherHighs,
      higherLows,
      lowerHighs,
      lowerLows,
    }
  }

  // Helper: Calculate EMA
  private calculateEMA(data: number[], period: number): number {
    if (data.length === 0) return 0
    if (data.length < period) period = data.length
    
    const multiplier = 2 / (period + 1)
    let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period
    
    for (let i = period; i < data.length; i++) {
      ema = (data[i] - ema) * multiplier + ema
    }
    
    return ema
  }

  // Helper: Find swing points
  private findSwingPoints(bars: OHLCV[], type: 'high' | 'low'): number[] {
    const points: number[] = []
    const values = type === 'high' ? bars.map(b => b.high) : bars.map(b => b.low)
    
    for (let i = 2; i < values.length - 2; i++) {
      if (type === 'high') {
        if (values[i] > values[i-1] && values[i] > values[i-2] && 
            values[i] > values[i+1] && values[i] > values[i+2]) {
          points.push(values[i])
        }
      } else {
        if (values[i] < values[i-1] && values[i] < values[i-2] && 
            values[i] < values[i+1] && values[i] < values[i+2]) {
          points.push(values[i])
        }
      }
    }
    
    return type === 'high' 
      ? points.sort((a, b) => b - a) 
      : points.sort((a, b) => a - b)
  }

  // Helper: Get timeframe in minutes
  private getTimeframeMinutes(timeframe: string): number {
    const map: Record<string, number> = {
      '5m': 5,
      '15m': 15,
      '30m': 30,
      '1h': 60,
      '4h': 240,
      '1d': 1440,
    }
    return map[timeframe] || 15
  }

  // Fallback mock data generator
  private generateMockBars(symbol: string, timeframe: string, limit: number): OHLCV[] {
    const asset = SUPPORTED_ASSETS[symbol]
    const basePrice = asset?.basePrice || 100
    const volatility = asset?.volatility || 0.015
    
    const bars: OHLCV[] = []
    let price = basePrice
    const timeframeMs = this.getTimeframeMinutes(timeframe) * 60 * 1000
    const now = Date.now()
    
    for (let i = limit - 1; i >= 0; i--) {
      const change = (Math.random() - 0.5) * 2 * volatility * price
      const open = price
      const close = price + change
      const high = Math.max(open, close) * (1 + Math.random() * volatility * 0.5)
      const low = Math.min(open, close) * (1 - Math.random() * volatility * 0.5)
      const volume = Math.floor(100000 + Math.random() * 500000)
      
      bars.push({
        timestamp: now - (i * timeframeMs),
        open,
        high,
        low,
        close,
        volume,
      })
      
      price = close
    }
    
    return bars
  }
}

// Singleton instance
export const alpacaProvider = new AlpacaStockProvider()
