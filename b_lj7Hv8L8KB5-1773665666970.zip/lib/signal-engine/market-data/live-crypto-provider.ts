// Live Crypto Market Data Provider
// Uses Binance public API for real-time cryptocurrency data (no API key required)
// Supported assets: BTC, ETH

import { 
  OHLCV, 
  SupportResistanceLevel,
  TrendAnalysis
} from '../types'

const BINANCE_BASE_URL = 'https://api.binance.com'

// Supported live crypto assets (limited set for initial launch)
export const LIVE_CRYPTO_ASSETS = ['BTC', 'ETH'] as const
export type LiveCryptoAsset = typeof LIVE_CRYPTO_ASSETS[number]

// Map our symbols to Binance trading pairs
const BINANCE_SYMBOLS: Record<string, string> = {
  'BTC': 'BTCUSDT',
  'ETH': 'ETHUSDT'
}

// Binance kline intervals
const BINANCE_INTERVALS: Record<string, string> = {
  '15m': '15m',
  '30m': '30m',
  '1h': '1h'
}

interface BinanceKline {
  openTime: number
  open: string
  high: string
  low: string
  close: string
  volume: string
  closeTime: number
  quoteVolume: string
  trades: number
  takerBuyBaseVolume: string
  takerBuyQuoteVolume: string
}

interface BinanceTickerResponse {
  symbol: string
  priceChange: string
  priceChangePercent: string
  lastPrice: string
  volume: string
  highPrice: string
  lowPrice: string
}

interface Binance24hrResponse {
  symbol: string
  priceChange: string
  priceChangePercent: string
  prevClosePrice: string
  lastPrice: string
  highPrice: string
  lowPrice: string
  volume: string
  quoteVolume: string
}

export class LiveCryptoProvider {
  
  isAssetSupported(symbol: string): boolean {
    return LIVE_CRYPTO_ASSETS.includes(symbol as LiveCryptoAsset)
  }
  
  // Crypto markets are 24/7
  isMarketOpen(): boolean {
    return true
  }
  
  // Get current session based on global activity patterns
  getCurrentSession(): string {
    const hour = new Date().getUTCHours()
    
    if (hour >= 0 && hour < 8) return 'asia'
    if (hour >= 8 && hour < 13) return 'europe'
    if (hour >= 13 && hour < 21) return 'us'
    return 'overnight'
  }
  
  // Fetch OHLCV candles from Binance
  async getCandles(symbol: string, timeframe: string, count: number = 100): Promise<OHLCV[]> {
    if (!this.isAssetSupported(symbol)) {
      console.log(`[LiveCryptoProvider] Asset ${symbol} not in live supported list`)
      return []
    }
    
    const binanceSymbol = BINANCE_SYMBOLS[symbol]
    const interval = BINANCE_INTERVALS[timeframe] || '1h'
    
    if (!binanceSymbol) {
      console.error(`[LiveCryptoProvider] No Binance symbol mapping for ${symbol}`)
      return []
    }
    
    try {
      const url = `${BINANCE_BASE_URL}/api/v3/klines?symbol=${binanceSymbol}&interval=${interval}&limit=${count}`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        console.error(`[LiveCryptoProvider] Binance API error: ${response.status}`)
        return []
      }
      
      const data: (string | number)[][] = await response.json()
      
      if (!data || data.length === 0) {
        console.log(`[LiveCryptoProvider] No candle data returned for ${symbol}`)
        return []
      }
      
      // Binance kline format: [openTime, open, high, low, close, volume, closeTime, ...]
      return data.map((kline): OHLCV => ({
        timestamp: kline[0] as number,
        open: parseFloat(kline[1] as string),
        high: parseFloat(kline[2] as string),
        low: parseFloat(kline[3] as string),
        close: parseFloat(kline[4] as string),
        volume: parseFloat(kline[5] as string)
      }))
    } catch (error) {
      console.error(`[LiveCryptoProvider] Error fetching candles for ${symbol}:`, error)
      return []
    }
  }
  
  // Get latest price
  async getLatestPrice(symbol: string): Promise<{ price: number; change: number; changePercent: number } | null> {
    if (!this.isAssetSupported(symbol)) {
      return null
    }
    
    const binanceSymbol = BINANCE_SYMBOLS[symbol]
    if (!binanceSymbol) return null
    
    try {
      const url = `${BINANCE_BASE_URL}/api/v3/ticker/24hr?symbol=${binanceSymbol}`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        console.error(`[LiveCryptoProvider] Ticker error: ${response.status}`)
        return null
      }
      
      const data: Binance24hrResponse = await response.json()
      
      return {
        price: parseFloat(data.lastPrice),
        change: parseFloat(data.priceChange),
        changePercent: parseFloat(data.priceChangePercent)
      }
    } catch (error) {
      console.error(`[LiveCryptoProvider] Error fetching price for ${symbol}:`, error)
      return null
    }
  }
  
  // Get 24h high/low (previous "session" equivalent for 24/7 markets)
  async get24hRange(symbol: string): Promise<{ high: number; low: number; prevClose: number } | null> {
    if (!this.isAssetSupported(symbol)) {
      return null
    }
    
    const binanceSymbol = BINANCE_SYMBOLS[symbol]
    if (!binanceSymbol) return null
    
    try {
      const url = `${BINANCE_BASE_URL}/api/v3/ticker/24hr?symbol=${binanceSymbol}`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        return null
      }
      
      const data: Binance24hrResponse = await response.json()
      
      return {
        high: parseFloat(data.highPrice),
        low: parseFloat(data.lowPrice),
        prevClose: parseFloat(data.prevClosePrice)
      }
    } catch (error) {
      console.error(`[LiveCryptoProvider] Error fetching 24h range:`, error)
      return null
    }
  }
  
  // Calculate support/resistance levels from candle data
  calculateLevels(candles: OHLCV[]): SupportResistanceLevel[] {
    if (candles.length < 20) return []
    
    const levels: SupportResistanceLevel[] = []
    const recentCandles = candles.slice(-50)
    
    // Find swing highs and lows
    for (let i = 2; i < recentCandles.length - 2; i++) {
      const candle = recentCandles[i]
      const prev1 = recentCandles[i - 1]
      const prev2 = recentCandles[i - 2]
      const next1 = recentCandles[i + 1]
      const next2 = recentCandles[i + 2]
      
      // Swing high
      if (candle.high > prev1.high && candle.high > prev2.high &&
          candle.high > next1.high && candle.high > next2.high) {
        levels.push({
          price: candle.high,
          type: 'resistance',
          strength: 0.7 + Math.random() * 0.3,
          touches: 1
        })
      }
      
      // Swing low
      if (candle.low < prev1.low && candle.low < prev2.low &&
          candle.low < next1.low && candle.low < next2.low) {
        levels.push({
          price: candle.low,
          type: 'support',
          strength: 0.7 + Math.random() * 0.3,
          touches: 1
        })
      }
    }
    
    // Merge nearby levels (crypto uses 0.5% threshold due to higher volatility)
    const mergedLevels: SupportResistanceLevel[] = []
    const sortedLevels = levels.sort((a, b) => a.price - b.price)
    
    for (const level of sortedLevels) {
      const nearby = mergedLevels.find(l => Math.abs(l.price - level.price) / level.price < 0.005)
      if (nearby) {
        nearby.touches++
        nearby.strength = Math.min(1, nearby.strength + 0.1)
      } else {
        mergedLevels.push({ ...level })
      }
    }
    
    return mergedLevels.sort((a, b) => b.strength - a.strength).slice(0, 10)
  }
  
  // Analyze trend from candle data
  analyzeTrend(candles: OHLCV[]): TrendAnalysis {
    if (candles.length < 20) {
      return { direction: 'neutral', strength: 0, ema20: 0, ema50: 0 }
    }
    
    // Calculate EMAs
    const closes = candles.map(c => c.close)
    const ema20 = this.calculateEMA(closes, 20)
    const ema50 = this.calculateEMA(closes, Math.min(50, closes.length))
    
    const currentPrice = closes[closes.length - 1]
    
    // Determine trend direction
    let direction: 'bullish' | 'bearish' | 'neutral' = 'neutral'
    if (currentPrice > ema20 && ema20 > ema50) {
      direction = 'bullish'
    } else if (currentPrice < ema20 && ema20 < ema50) {
      direction = 'bearish'
    }
    
    // Calculate trend strength (0-1) - crypto tends to have stronger trends
    const priceVsEma = Math.abs(currentPrice - ema20) / currentPrice
    const emaSpread = Math.abs(ema20 - ema50) / ema50
    const strength = Math.min(1, (priceVsEma + emaSpread) * 8)
    
    return { direction, strength, ema20, ema50 }
  }
  
  private calculateEMA(data: number[], period: number): number {
    if (data.length < period) return data[data.length - 1] || 0
    
    const k = 2 / (period + 1)
    let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period
    
    for (let i = period; i < data.length; i++) {
      ema = data[i] * k + ema * (1 - k)
    }
    
    return ema
  }
}

// Singleton instance
export const liveCryptoProvider = new LiveCryptoProvider()
