// Binance Live Data Provider for Crypto
// Supports: BTC, ETH (24/7 markets)
// Uses public API - no API key required for market data

import { OHLCV, MarketLevels, TrendAnalysis, SUPPORTED_ASSETS } from '../types'

const BINANCE_BASE_URL = 'https://api.binance.com/api/v3'

// Supported crypto symbols for live data
export const LIVE_CRYPTO_SYMBOLS = ['BTC', 'ETH', 'SOL'] as const
export type LiveCryptoSymbol = typeof LIVE_CRYPTO_SYMBOLS[number]

// Symbol mapping for Binance (they use BTCUSDT format)
const BINANCE_SYMBOL_MAP: Record<string, string> = {
  'BTC': 'BTCUSDT',
  'ETH': 'ETHUSDT',
  'SOL': 'SOLUSDT',
}

// Timeframe mapping for Binance API
const TIMEFRAME_MAP: Record<string, string> = {
  '5m': '5m',
  '15m': '15m',
  '30m': '30m',
  '1h': '1h',
  '4h': '4h',
  '1d': '1d',
}

interface BinanceKline {
  0: number   // Open time
  1: string   // Open
  2: string   // High
  3: string   // Low
  4: string   // Close
  5: string   // Volume
  6: number   // Close time
  7: string   // Quote asset volume
  8: number   // Number of trades
  9: string   // Taker buy base asset volume
  10: string  // Taker buy quote asset volume
  11: string  // Ignore
}

interface BinanceTickerPrice {
  symbol: string
  price: string
}

interface Binance24hrTicker {
  symbol: string
  highPrice: string
  lowPrice: string
  lastPrice: string
  prevClosePrice: string
  volume: string
}

export class BinanceCryptoProvider {
  // Crypto markets are always open
  async isMarketOpen(): Promise<boolean> {
    return true
  }

  // Get historical bars (OHLCV candles)
  async getBars(symbol: string, timeframe: string, limit: number = 100): Promise<OHLCV[]> {
    const binanceSymbol = BINANCE_SYMBOL_MAP[symbol]
    if (!binanceSymbol) {
      console.warn(`[BinanceProvider] Unknown symbol: ${symbol}, using mock data`)
      return this.generateMockBars(symbol, timeframe, limit)
    }

    const binanceTimeframe = TIMEFRAME_MAP[timeframe] || '15m'
    
    try {
      const url = new URL(`${BINANCE_BASE_URL}/klines`)
      url.searchParams.set('symbol', binanceSymbol)
      url.searchParams.set('interval', binanceTimeframe)
      url.searchParams.set('limit', limit.toString())
      
      const response = await fetch(url.toString())
      
      if (!response.ok) {
        const errorText = await response.text()
        console.error(`[BinanceProvider] Failed to fetch bars for ${symbol}:`, errorText)
        return this.generateMockBars(symbol, timeframe, limit)
      }
      
      const data: BinanceKline[] = await response.json()
      
      if (!data || data.length === 0) {
        console.warn(`[BinanceProvider] No bars returned for ${symbol}, using mock data`)
        return this.generateMockBars(symbol, timeframe, limit)
      }
      
      return data.map(kline => ({
        timestamp: kline[0],
        open: parseFloat(kline[1]),
        high: parseFloat(kline[2]),
        low: parseFloat(kline[3]),
        close: parseFloat(kline[4]),
        volume: parseFloat(kline[5]),
      }))
    } catch (error) {
      console.error(`[BinanceProvider] Error fetching bars for ${symbol}:`, error)
      return this.generateMockBars(symbol, timeframe, limit)
    }
  }

  // Get latest price
  async getLatestPrice(symbol: string): Promise<number> {
    const binanceSymbol = BINANCE_SYMBOL_MAP[symbol]
    if (!binanceSymbol) {
      const asset = SUPPORTED_ASSETS[symbol]
      return asset?.basePrice || 100
    }

    try {
      const response = await fetch(
        `${BINANCE_BASE_URL}/ticker/price?symbol=${binanceSymbol}`
      )
      
      if (!response.ok) {
        const asset = SUPPORTED_ASSETS[symbol]
        return asset?.basePrice || 100
      }
      
      const data: BinanceTickerPrice = await response.json()
      return parseFloat(data.price)
    } catch (error) {
      console.error(`[BinanceProvider] Error fetching latest price for ${symbol}:`, error)
      const asset = SUPPORTED_ASSETS[symbol]
      return asset?.basePrice || 100
    }
  }

  // Get 24hr high/low (crypto equivalent of previous session)
  async get24hrStats(symbol: string): Promise<{ high: number; low: number; close: number }> {
    const binanceSymbol = BINANCE_SYMBOL_MAP[symbol]
    if (!binanceSymbol) {
      const asset = SUPPORTED_ASSETS[symbol]
      const basePrice = asset?.basePrice || 100
      return {
        high: basePrice * 1.03,
        low: basePrice * 0.97,
        close: basePrice,
      }
    }

    try {
      const response = await fetch(
        `${BINANCE_BASE_URL}/ticker/24hr?symbol=${binanceSymbol}`
      )
      
      if (!response.ok) {
        throw new Error('Failed to fetch 24hr stats')
      }
      
      const data: Binance24hrTicker = await response.json()
      
      return {
        high: parseFloat(data.highPrice),
        low: parseFloat(data.lowPrice),
        close: parseFloat(data.prevClosePrice),
      }
    } catch (error) {
      console.error(`[BinanceProvider] Error fetching 24hr stats for ${symbol}:`, error)
      const asset = SUPPORTED_ASSETS[symbol]
      const basePrice = asset?.basePrice || 100
      return {
        high: basePrice * 1.03,
        low: basePrice * 0.97,
        close: basePrice,
      }
    }
  }

  // Calculate key levels from price data
  calculateLevels(bars: OHLCV[], stats24hr: { high: number; low: number; close: number }): MarketLevels {
    if (bars.length === 0) {
      return {
        support: [],
        resistance: [],
        keyLevels: [],
        pivotPoints: {
          pp: stats24hr.close,
          r1: stats24hr.high,
          r2: stats24hr.high * 1.02,
          r3: stats24hr.high * 1.04,
          s1: stats24hr.low,
          s2: stats24hr.low * 0.98,
          s3: stats24hr.low * 0.96,
        },
      }
    }

    const highs = bars.map(b => b.high)
    const lows = bars.map(b => b.low)
    
    // Calculate pivot points using 24hr data
    const pp = (stats24hr.high + stats24hr.low + stats24hr.close) / 3
    const r1 = (2 * pp) - stats24hr.low
    const s1 = (2 * pp) - stats24hr.high
    const r2 = pp + (stats24hr.high - stats24hr.low)
    const s2 = pp - (stats24hr.high - stats24hr.low)
    const r3 = r1 + (stats24hr.high - stats24hr.low)
    const s3 = s1 - (stats24hr.high - stats24hr.low)

    // Find swing highs and lows for support/resistance
    const swingHighs = this.findSwingPoints(bars, 'high')
    const swingLows = this.findSwingPoints(bars, 'low')

    // Round numbers are significant in crypto
    const currentPrice = bars[bars.length - 1].close
    const roundNumber = Math.round(currentPrice / 1000) * 1000

    return {
      support: swingLows.slice(0, 3).map((level, i) => ({
        price: level,
        strength: 1 - (i * 0.2),
        touches: 2 + Math.floor(Math.random() * 3),
      })),
      resistance: swingHighs.slice(0, 3).map((level, i) => ({
        price: level,
        strength: 1 - (i * 0.2),
        touches: 2 + Math.floor(Math.random() * 3),
      })),
      keyLevels: [
        { price: pp, type: 'pivot' as const, strength: 0.9 },
        { price: stats24hr.high, type: 'resistance' as const, strength: 0.85 },
        { price: stats24hr.low, type: 'support' as const, strength: 0.85 },
        { price: roundNumber, type: 'key level' as const, strength: 0.8 },
        { price: r1, type: 'resistance' as const, strength: 0.7 },
        { price: s1, type: 'support' as const, strength: 0.7 },
      ],
      pivotPoints: { pp, r1, r2, r3, s1, s2, s3 },
    }
  }

  // Analyze trend from bars
  analyzeTrend(bars: OHLCV[]): TrendAnalysis {
    if (bars.length < 20) {
      return {
        direction: 'neutral',
        strength: 0.5,
        ema20: bars[bars.length - 1]?.close || 0,
        ema50: bars[bars.length - 1]?.close || 0,
        higherHighs: false,
        higherLows: false,
        lowerHighs: false,
        lowerLows: false,
      }
    }

    const closes = bars.map(b => b.close)
    const ema20 = this.calculateEMA(closes, 20)
    const ema50 = this.calculateEMA(closes, Math.min(50, closes.length))
    
    const currentPrice = closes[closes.length - 1]
    
    // Determine trend direction
    let direction: 'bullish' | 'bearish' | 'neutral' = 'neutral'
    if (currentPrice > ema20 && ema20 > ema50) {
      direction = 'bullish'
    } else if (currentPrice < ema20 && ema20 < ema50) {
      direction = 'bearish'
    }

    // Check for higher highs/lows or lower highs/lows
    const recentHighs = bars.slice(-10).map(b => b.high)
    const recentLows = bars.slice(-10).map(b => b.low)
    
    const higherHighs = recentHighs[recentHighs.length - 1] > Math.max(...recentHighs.slice(0, -3))
    const higherLows = recentLows[recentLows.length - 1] > Math.min(...recentLows.slice(0, -3))
    const lowerHighs = recentHighs[recentHighs.length - 1] < Math.max(...recentHighs.slice(0, -3))
    const lowerLows = recentLows[recentLows.length - 1] < Math.min(...recentLows.slice(0, -3))

    // Calculate trend strength
    const priceVsEma = Math.abs(currentPrice - ema20) / ema20
    const strength = Math.min(1, priceVsEma * 10 + 0.5)

    return {
      direction,
      strength,
      ema20,
      ema50,
      higherHighs,
      higherLows,
      lowerHighs,
      lowerLows,
    }
  }

  // Get current trading session (crypto runs 24/7 but has regional activity patterns)
  getCurrentSession(): string {
    const hour = new Date().getUTCHours()
    
    if (hour >= 0 && hour < 8) return 'Asia'
    if (hour >= 8 && hour < 14) return 'Europe'
    if (hour >= 14 && hour < 21) return 'US'
    return 'Asia'
  }

  // Helper: Calculate EMA
  private calculateEMA(data: number[], period: number): number {
    if (data.length === 0) return 0
    if (data.length < period) period = data.length
    
    const multiplier = 2 / (period + 1)
    let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period
    
    for (let i = period; i < data.length; i++) {
      ema = (data[i] - ema) * multiplier + ema
    }
    
    return ema
  }

  // Helper: Find swing points
  private findSwingPoints(bars: OHLCV[], type: 'high' | 'low'): number[] {
    const points: number[] = []
    const values = type === 'high' ? bars.map(b => b.high) : bars.map(b => b.low)
    
    for (let i = 2; i < values.length - 2; i++) {
      if (type === 'high') {
        if (values[i] > values[i-1] && values[i] > values[i-2] && 
            values[i] > values[i+1] && values[i] > values[i+2]) {
          points.push(values[i])
        }
      } else {
        if (values[i] < values[i-1] && values[i] < values[i-2] && 
            values[i] < values[i+1] && values[i] < values[i+2]) {
          points.push(values[i])
        }
      }
    }
    
    return type === 'high' 
      ? points.sort((a, b) => b - a) 
      : points.sort((a, b) => a - b)
  }

  // Helper: Get timeframe in minutes
  private getTimeframeMinutes(timeframe: string): number {
    const map: Record<string, number> = {
      '5m': 5,
      '15m': 15,
      '30m': 30,
      '1h': 60,
      '4h': 240,
      '1d': 1440,
    }
    return map[timeframe] || 15
  }

  // Fallback mock data generator
  private generateMockBars(symbol: string, timeframe: string, limit: number): OHLCV[] {
    const asset = SUPPORTED_ASSETS[symbol]
    const basePrice = asset?.basePrice || 50000
    const volatility = asset?.volatility || 0.025
    
    const bars: OHLCV[] = []
    let price = basePrice
    const timeframeMs = this.getTimeframeMinutes(timeframe) * 60 * 1000
    const now = Date.now()
    
    for (let i = limit - 1; i >= 0; i--) {
      const change = (Math.random() - 0.5) * 2 * volatility * price
      const open = price
      const close = price + change
      const high = Math.max(open, close) * (1 + Math.random() * volatility * 0.5)
      const low = Math.min(open, close) * (1 - Math.random() * volatility * 0.5)
      const volume = Math.floor(1000 + Math.random() * 5000)
      
      bars.push({
        timestamp: now - (i * timeframeMs),
        open,
        high,
        low,
        close,
        volume,
      })
      
      price = close
    }
    
    return bars
  }
}

// Singleton instance
export const binanceProvider = new BinanceCryptoProvider()
