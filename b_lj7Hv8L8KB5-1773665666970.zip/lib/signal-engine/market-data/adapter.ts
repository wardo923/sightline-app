// Market Data Adapter
// Provides a unified interface for market data
// Routes to live providers (Alpaca for stocks, Binance for crypto)

import { 
  OHLCV, 
  MarketLevels,
  TrendAnalysis,
  getAssetClass,
  AssetClass,
  SUPPORTED_ASSETS,
  isAssetSupported
} from '../types'
import { alpacaProvider, LIVE_STOCK_SYMBOLS } from './alpaca-provider'
import { binanceProvider, LIVE_CRYPTO_SYMBOLS } from './binance-provider'

// Live supported assets (limited set for initial launch)
export const LIVE_ASSETS = [...LIVE_STOCK_SYMBOLS, ...LIVE_CRYPTO_SYMBOLS] as const

// Check if we're in live mode for stocks (have Alpaca API keys)
export function isStockLiveMode(): boolean {
  return !!(process.env.ALPACA_API_KEY && process.env.ALPACA_SECRET_KEY)
}

// Check if an asset has live data support
export function hasLiveSupport(symbol: string): boolean {
  return LIVE_ASSETS.includes(symbol as typeof LIVE_ASSETS[number])
}

export interface FullAnalysisResult {
  candles: OHLCV[]
  levels: MarketLevels
  trend: TrendAnalysis
  assetClass: AssetClass
  isMarketOpen: boolean
  currentSession: string
  isLive: boolean
  latestPrice: number
}

export class MarketDataAdapter {
  
  // Get asset class for a symbol
  getAssetClass(symbol: string): AssetClass {
    return getAssetClass(symbol)
  }
  
  // Check if asset is supported
  isSupported(symbol: string): boolean {
    return isAssetSupported(symbol)
  }
  
  // Check if asset has live data
  hasLiveData(symbol: string): boolean {
    return hasLiveSupport(symbol)
  }
  
  // Get all supported assets
  getSupportedAssets(): string[] {
    return Object.keys(SUPPORTED_ASSETS)
  }
  
  // Get live supported assets only
  getLiveAssets(): string[] {
    return [...LIVE_ASSETS]
  }
  
  // Get supported assets by class
  getAssetsByClass(assetClass: AssetClass): string[] {
    return Object.entries(SUPPORTED_ASSETS)
      .filter(([_, config]) => config.class === assetClass)
      .map(([symbol]) => symbol)
  }
  
  // Get OHLCV candles
  async getCandles(symbol: string, timeframe: string, count: number = 100): Promise<OHLCV[]> {
    const assetClass = getAssetClass(symbol)
    
    if (assetClass === 'crypto') {
      return binanceProvider.getBars(symbol, timeframe, count)
    }
    
    return alpacaProvider.getBars(symbol, timeframe, count)
  }
  
  // Get latest price
  async getLatestPrice(symbol: string): Promise<number> {
    const assetClass = getAssetClass(symbol)
    
    if (assetClass === 'crypto') {
      return binanceProvider.getLatestPrice(symbol)
    }
    
    return alpacaProvider.getLatestPrice(symbol)
  }
  
  // Check if market is open
  async isMarketOpen(symbol: string): Promise<boolean> {
    const assetClass = getAssetClass(symbol)
    
    if (assetClass === 'crypto') {
      return binanceProvider.isMarketOpen()
    }
    
    return alpacaProvider.isMarketOpen()
  }
  
  // Get support/resistance levels
  async getLevels(symbol: string, timeframe: string): Promise<MarketLevels> {
    const assetClass = getAssetClass(symbol)
    const candles = await this.getCandles(symbol, timeframe, 100)
    
    if (assetClass === 'crypto') {
      const stats = await binanceProvider.get24hrStats(symbol)
      return binanceProvider.calculateLevels(candles, stats)
    }
    
    const prevSession = await alpacaProvider.getPreviousSession(symbol)
    return alpacaProvider.calculateLevels(candles, prevSession)
  }
  
  // Get trend analysis
  async getTrend(symbol: string, timeframe: string): Promise<TrendAnalysis> {
    const assetClass = getAssetClass(symbol)
    const candles = await this.getCandles(symbol, timeframe, 100)
    
    if (assetClass === 'crypto') {
      return binanceProvider.analyzeTrend(candles)
    }
    
    return alpacaProvider.analyzeTrend(candles)
  }
  
  // Get current trading session
  getCurrentSession(symbol: string): string {
    const assetClass = getAssetClass(symbol)
    
    if (assetClass === 'crypto') {
      return binanceProvider.getCurrentSession()
    }
    
    // Stock session based on time
    const now = new Date()
    const hour = now.getUTCHours()
    
    if (hour >= 14 && hour < 21) return 'US Regular'
    if (hour >= 9 && hour < 14) return 'US Pre-Market'
    if (hour >= 21 || hour < 9) return 'US After-Hours'
    return 'Closed'
  }
  
  // Check if session matches user preference
  async isPreferredSession(symbol: string, preference: string): Promise<boolean> {
    if (!preference || preference === 'any' || preference === 'All Sessions') {
      return true
    }
    
    const assetClass = getAssetClass(symbol)
    
    // Crypto is always available
    if (assetClass === 'crypto') {
      return true
    }
    
    const currentSession = this.getCurrentSession(symbol)
    
    switch (preference) {
      case 'US Session':
      case 'us':
        return currentSession === 'US Regular'
      case 'London Session':
      case 'london':
        // London overlaps with early US
        const hour = new Date().getUTCHours()
        return hour >= 7 && hour < 16
      case 'Asian Session':
      case 'asia':
        const asiaHour = new Date().getUTCHours()
        return asiaHour >= 0 && asiaHour < 8
      default:
        return true
    }
  }
  
  // Full market analysis
  async getFullAnalysis(symbol: string, timeframe: string): Promise<FullAnalysisResult> {
    const assetClass = getAssetClass(symbol)
    const isLive = hasLiveSupport(symbol)
    
    // Fetch all data in parallel
    const [candles, isOpen, latestPrice] = await Promise.all([
      this.getCandles(symbol, timeframe, 100),
      this.isMarketOpen(symbol),
      this.getLatestPrice(symbol),
    ])
    
    // Calculate levels and trend from candles
    let levels: MarketLevels
    let trend: TrendAnalysis
    
    if (assetClass === 'crypto') {
      const stats = await binanceProvider.get24hrStats(symbol)
      levels = binanceProvider.calculateLevels(candles, stats)
      trend = binanceProvider.analyzeTrend(candles)
    } else {
      const prevSession = await alpacaProvider.getPreviousSession(symbol)
      levels = alpacaProvider.calculateLevels(candles, prevSession)
      trend = alpacaProvider.analyzeTrend(candles)
    }
    
    const currentSession = this.getCurrentSession(symbol)
    
    return {
      candles,
      levels,
      trend,
      assetClass,
      isMarketOpen: isOpen,
      currentSession,
      isLive,
      latestPrice,
    }
  }
}

// Export singleton instance
export const marketDataAdapter = new MarketDataAdapter()
