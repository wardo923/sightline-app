// Crypto Market Data Provider
// Handles cryptocurrency assets - 24/7 markets
// Currently uses mock data - can be swapped with real providers (Binance, Coinbase, etc.)

import { 
  MarketDataProvider, 
  OHLCV, 
  SupportResistanceLevel,
  SUPPORTED_ASSETS
} from '../types'

// Crypto-specific sessions (based on global activity patterns)
interface CryptoSession {
  name: string
  startHour: number  // UTC
  endHour: number
  description: string
}

const CRYPTO_SESSIONS: CryptoSession[] = [
  { name: 'asia', startHour: 0, endHour: 8, description: 'Asian Session' },
  { name: 'europe', startHour: 8, endHour: 13, description: 'European Session' },
  { name: 'us', startHour: 13, endHour: 21, description: 'US Session' },
  { name: 'overnight', startHour: 21, endHour: 24, description: 'Overnight Session' },
]

// Generate realistic crypto OHLCV data with 24/7 patterns
function generateCryptoCandles(
  symbol: string,
  timeframe: string,
  count: number
): OHLCV[] {
  const config = SUPPORTED_ASSETS[symbol] || { basePrice: 1000, volatility: 0.03 }
  const candles: OHLCV[] = []
  
  const timeframeMinutes: Record<string, number> = {
    '15m': 15, '30m': 30, '1h': 60
  }
  const minutes = timeframeMinutes[timeframe] || 60
  
  // Crypto tends to have more volatile trends
  const trendBias = Math.random() > 0.5 ? 1 : -1
  const trendStrength = Math.random() * 0.4 + 0.1  // Slightly higher trend strength for crypto
  
  let currentPrice = config.basePrice * (1 + (Math.random() - 0.5) * 0.05)
  const now = Date.now()
  
  for (let i = count - 1; i >= 0; i--) {
    const timestamp = now - (i * minutes * 60 * 1000)
    const date = new Date(timestamp)
    const hour = date.getUTCHours()
    
    // Volume patterns - higher during US hours
    let volumeMultiplier = 1
    if (hour >= 13 && hour < 21) volumeMultiplier = 1.8  // US session
    if (hour >= 8 && hour < 13) volumeMultiplier = 1.4   // Europe session
    
    // Crypto tends to have weekend activity spikes sometimes
    const day = date.getUTCDay()
    if (day === 0 || day === 6) {
      volumeMultiplier *= 0.8  // Slightly lower weekend volume but still active
    }
    
    // Higher volatility for crypto
    const trendMove = trendBias * trendStrength * config.volatility * currentPrice * (Math.random() * 0.6)
    const noise = (Math.random() - 0.5) * config.volatility * currentPrice
    
    const open = currentPrice
    const change = trendMove + noise
    const close = open + change
    
    // Crypto has larger wicks typically
    const range = Math.abs(change) + (Math.random() * config.volatility * currentPrice * 0.7)
    const high = Math.max(open, close) + (Math.random() * range * 0.4)
    const low = Math.min(open, close) - (Math.random() * range * 0.4)
    
    // Crypto volume varies widely
    const baseVolume = symbol === 'BTC' ? 50000000000 : symbol === 'ETH' ? 20000000000 : 5000000000
    const volume = Math.floor(baseVolume * (0.3 + Math.random() * 0.7) * volumeMultiplier / 1000000)
    
    candles.push({
      timestamp,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume
    })
    
    currentPrice = close
  }
  
  return candles
}

// Find support/resistance levels from crypto candle data
function findCryptoLevels(candles: OHLCV[]): SupportResistanceLevel[] {
  const levels: SupportResistanceLevel[] = []
  const pricePoints: number[] = []
  
  for (let i = 2; i < candles.length - 2; i++) {
    const curr = candles[i]
    const prev1 = candles[i - 1]
    const prev2 = candles[i - 2]
    const next1 = candles[i + 1]
    const next2 = candles[i + 2]
    
    if (curr.high > prev1.high && curr.high > prev2.high &&
        curr.high > next1.high && curr.high > next2.high) {
      pricePoints.push(curr.high)
    }
    
    if (curr.low < prev1.low && curr.low < prev2.low &&
        curr.low < next1.low && curr.low < next2.low) {
      pricePoints.push(curr.low)
    }
  }
  
  // Crypto levels tend to cluster around round numbers
  const currentPrice = candles[candles.length - 1]?.close || 1000
  const tolerance = currentPrice * 0.005  // 0.5% tolerance for crypto
  const clusters: number[][] = []
  
  for (const price of pricePoints) {
    let foundCluster = false
    for (const cluster of clusters) {
      if (Math.abs(cluster[0] - price) < tolerance) {
        cluster.push(price)
        foundCluster = true
        break
      }
    }
    if (!foundCluster) {
      clusters.push([price])
    }
  }
  
  for (const cluster of clusters) {
    if (cluster.length >= 2) {
      const avgPrice = cluster.reduce((a, b) => a + b, 0) / cluster.length
      levels.push({
        price: Number(avgPrice.toFixed(2)),
        type: avgPrice < currentPrice ? 'support' : 'resistance',
        strength: Math.min(5, cluster.length),
        touches: cluster.length
      })
    }
  }
  
  levels.sort((a, b) => 
    Math.abs(a.price - currentPrice) - Math.abs(b.price - currentPrice)
  )
  
  return levels.slice(0, 10)
}

export class CryptoMarketDataProvider implements MarketDataProvider {
  private cache: Map<string, { data: OHLCV[]; timestamp: number }> = new Map()
  private cacheTTL = 30000  // 30 second cache for crypto (more real-time)
  
  getName(): string {
    return 'CryptoProvider'
  }
  
  async getCandles(symbol: string, timeframe: string, limit: number = 100): Promise<OHLCV[]> {
    const cacheKey = `crypto-${symbol}-${timeframe}-${limit}`
    const cached = this.cache.get(cacheKey)
    
    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.data
    }
    
    // TODO: Replace with real provider (Binance, Coinbase, CoinGecko)
    // if (process.env.BINANCE_API_KEY) {
    //   return fetchFromBinance(symbol, timeframe, limit)
    // }
    
    const candles = generateCryptoCandles(symbol, timeframe, limit)
    this.cache.set(cacheKey, { data: candles, timestamp: Date.now() })
    
    return candles
  }
  
  async getCurrentPrice(symbol: string): Promise<number> {
    const candles = await this.getCandles(symbol, '15m', 1)
    return candles[candles.length - 1]?.close || SUPPORTED_ASSETS[symbol]?.basePrice || 1000
  }
  
  async getSupportResistance(symbol: string, timeframe: string): Promise<SupportResistanceLevel[]> {
    const candles = await this.getCandles(symbol, timeframe, 200)
    return findCryptoLevels(candles)
  }
  
  async isMarketOpen(_symbol: string): Promise<boolean> {
    // Crypto markets are always open 24/7
    return true
  }
  
  // Get current global trading session
  async getCurrentSession(): Promise<string> {
    const now = new Date()
    const hour = now.getUTCHours()
    
    for (const session of CRYPTO_SESSIONS) {
      if (hour >= session.startHour && hour < session.endHour) {
        return session.name
      }
    }
    
    return 'asia'  // Default fallback
  }
  
  // Check if current session matches user preference
  // For crypto, this is more of a preference than a hard filter
  async isPreferredSession(userTimeOfDay: string): Promise<boolean> {
    // Crypto is 24/7 so we honor user time-of-day preference differently
    // We check based on the user's likely local time activity patterns
    const currentSession = await this.getCurrentSession()
    
    switch (userTimeOfDay) {
      case 'morning':
        // Morning preference - US morning aligns with us session start
        return currentSession === 'us' || currentSession === 'europe'
      case 'midday':
        return currentSession === 'us'
      case 'afternoon':
        return currentSession === 'us' || currentSession === 'overnight'
      case 'any':
      default:
        // Always return true for crypto - market is always open
        return true
    }
  }
}

export const cryptoProvider = new CryptoMarketDataProvider()
