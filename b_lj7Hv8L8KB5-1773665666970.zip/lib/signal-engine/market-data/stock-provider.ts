// Stock Market Data Provider
// Handles stocks and ETFs with market hours awareness
// Currently uses mock data - can be swapped with real providers (Polygon, Alpha Vantage, etc.)

import { 
  MarketDataProvider, 
  OHLCV, 
  SupportResistanceLevel,
  SUPPORTED_ASSETS
} from '../types'

// US Stock Market Hours (Eastern Time)
const MARKET_OPEN_HOUR = 9.5  // 9:30 AM ET
const MARKET_CLOSE_HOUR = 16  // 4:00 PM ET

// Pre-market: 4:00 AM - 9:30 AM ET
// After-hours: 4:00 PM - 8:00 PM ET

interface StockSession {
  name: string
  startHour: number
  endHour: number
}

const STOCK_SESSIONS: StockSession[] = [
  { name: 'premarket', startHour: 4, endHour: 9.5 },
  { name: 'morning', startHour: 9.5, endHour: 12 },
  { name: 'midday', startHour: 12, endHour: 14 },
  { name: 'afternoon', startHour: 14, endHour: 16 },
  { name: 'afterhours', startHour: 16, endHour: 20 },
]

// Generate realistic stock OHLCV data with market patterns
function generateStockCandles(
  symbol: string,
  timeframe: string,
  count: number
): OHLCV[] {
  const config = SUPPORTED_ASSETS[symbol] || { basePrice: 100, volatility: 0.01 }
  const candles: OHLCV[] = []
  
  const timeframeMinutes: Record<string, number> = {
    '15m': 15, '30m': 30, '1h': 60
  }
  const minutes = timeframeMinutes[timeframe] || 60
  
  // Generate trend bias for session
  const trendBias = Math.random() > 0.5 ? 1 : -1
  const trendStrength = Math.random() * 0.3 + 0.1
  
  let currentPrice = config.basePrice * (1 + (Math.random() - 0.5) * 0.02)
  const now = Date.now()
  
  for (let i = count - 1; i >= 0; i--) {
    const timestamp = now - (i * minutes * 60 * 1000)
    const date = new Date(timestamp)
    const hour = date.getUTCHours() - 5 // Convert to ET (simplified)
    
    // Skip weekend candles for stocks
    const day = date.getUTCDay()
    if (day === 0 || day === 6) {
      continue
    }
    
    // Add volume spike at open and close
    let volumeMultiplier = 1
    if (hour >= 9 && hour < 10) volumeMultiplier = 2.5  // Opening hour
    if (hour >= 15 && hour < 16) volumeMultiplier = 2   // Closing hour
    
    // Add trend component with session awareness
    const trendMove = trendBias * trendStrength * config.volatility * currentPrice * (Math.random() * 0.5)
    const noise = (Math.random() - 0.5) * config.volatility * currentPrice
    
    const open = currentPrice
    const change = trendMove + noise
    const close = open + change
    
    const range = Math.abs(change) + (Math.random() * config.volatility * currentPrice * 0.5)
    const high = Math.max(open, close) + (Math.random() * range * 0.3)
    const low = Math.min(open, close) - (Math.random() * range * 0.3)
    
    const baseVolume = 5000000 // Higher volume for stocks
    const volume = Math.floor(baseVolume * (0.5 + Math.random()) * volumeMultiplier)
    
    candles.push({
      timestamp,
      open: Number(open.toFixed(2)),
      high: Number(high.toFixed(2)),
      low: Number(low.toFixed(2)),
      close: Number(close.toFixed(2)),
      volume
    })
    
    currentPrice = close
  }
  
  return candles
}

// Find support/resistance levels from stock candle data
function findStockLevels(candles: OHLCV[]): SupportResistanceLevel[] {
  const levels: SupportResistanceLevel[] = []
  const pricePoints: number[] = []
  
  for (let i = 2; i < candles.length - 2; i++) {
    const curr = candles[i]
    const prev1 = candles[i - 1]
    const prev2 = candles[i - 2]
    const next1 = candles[i + 1]
    const next2 = candles[i + 2]
    
    if (curr.high > prev1.high && curr.high > prev2.high &&
        curr.high > next1.high && curr.high > next2.high) {
      pricePoints.push(curr.high)
    }
    
    if (curr.low < prev1.low && curr.low < prev2.low &&
        curr.low < next1.low && curr.low < next2.low) {
      pricePoints.push(curr.low)
    }
  }
  
  const tolerance = candles[0]?.close * 0.003 || 1
  const clusters: number[][] = []
  
  for (const price of pricePoints) {
    let foundCluster = false
    for (const cluster of clusters) {
      if (Math.abs(cluster[0] - price) < tolerance) {
        cluster.push(price)
        foundCluster = true
        break
      }
    }
    if (!foundCluster) {
      clusters.push([price])
    }
  }
  
  const currentPrice = candles[candles.length - 1]?.close || 100
  
  for (const cluster of clusters) {
    if (cluster.length >= 2) {
      const avgPrice = cluster.reduce((a, b) => a + b, 0) / cluster.length
      levels.push({
        price: Number(avgPrice.toFixed(2)),
        type: avgPrice < currentPrice ? 'support' : 'resistance',
        strength: Math.min(5, cluster.length),
        touches: cluster.length
      })
    }
  }
  
  levels.sort((a, b) => 
    Math.abs(a.price - currentPrice) - Math.abs(b.price - currentPrice)
  )
  
  return levels.slice(0, 10)
}

export class StockMarketDataProvider implements MarketDataProvider {
  private cache: Map<string, { data: OHLCV[]; timestamp: number }> = new Map()
  private cacheTTL = 60000
  
  getName(): string {
    return 'StockProvider'
  }
  
  async getCandles(symbol: string, timeframe: string, limit: number = 100): Promise<OHLCV[]> {
    const cacheKey = `stock-${symbol}-${timeframe}-${limit}`
    const cached = this.cache.get(cacheKey)
    
    if (cached && Date.now() - cached.timestamp < this.cacheTTL) {
      return cached.data
    }
    
    // TODO: Replace with real provider (Polygon, Alpha Vantage)
    // if (process.env.POLYGON_API_KEY) {
    //   return fetchFromPolygon(symbol, timeframe, limit)
    // }
    
    const candles = generateStockCandles(symbol, timeframe, limit)
    this.cache.set(cacheKey, { data: candles, timestamp: Date.now() })
    
    return candles
  }
  
  async getCurrentPrice(symbol: string): Promise<number> {
    const candles = await this.getCandles(symbol, '15m', 1)
    return candles[candles.length - 1]?.close || SUPPORTED_ASSETS[symbol]?.basePrice || 100
  }
  
  async getSupportResistance(symbol: string, timeframe: string): Promise<SupportResistanceLevel[]> {
    const candles = await this.getCandles(symbol, timeframe, 200)
    return findStockLevels(candles)
  }
  
  async isMarketOpen(symbol: string): Promise<boolean> {
    const now = new Date()
    const day = now.getUTCDay()
    
    // Closed on weekends
    if (day === 0 || day === 6) {
      return false
    }
    
    // Convert to Eastern Time (simplified - doesn't account for DST)
    const etHour = (now.getUTCHours() - 5 + 24) % 24
    const etMinutes = now.getUTCMinutes()
    const etDecimalHour = etHour + etMinutes / 60
    
    // Regular market hours: 9:30 AM - 4:00 PM ET
    return etDecimalHour >= MARKET_OPEN_HOUR && etDecimalHour < MARKET_CLOSE_HOUR
  }
  
  // Get current trading session
  async getCurrentSession(): Promise<string> {
    const now = new Date()
    const etHour = (now.getUTCHours() - 5 + 24) % 24
    const etMinutes = now.getUTCMinutes()
    const etDecimalHour = etHour + etMinutes / 60
    
    for (const session of STOCK_SESSIONS) {
      if (etDecimalHour >= session.startHour && etDecimalHour < session.endHour) {
        return session.name
      }
    }
    
    return 'closed'
  }
  
  // Check if session matches user preference
  async isPreferredSession(userTimeOfDay: string): Promise<boolean> {
    const currentSession = await this.getCurrentSession()
    
    switch (userTimeOfDay) {
      case 'morning':
        return currentSession === 'morning'
      case 'midday':
        return currentSession === 'midday'
      case 'afternoon':
        return currentSession === 'afternoon'
      case 'any':
      default:
        return currentSession !== 'closed'
    }
  }
}

export const stockProvider = new StockMarketDataProvider()
