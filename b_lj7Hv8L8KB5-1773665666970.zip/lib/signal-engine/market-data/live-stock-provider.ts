// Live Stock Market Data Provider
// Uses Polygon.io for real-time stock/ETF data
// Supported assets: SPY, QQQ, NVDA

import { 
  OHLCV, 
  SupportResistanceLevel,
  TrendAnalysis,
  SUPPORTED_ASSETS
} from '../types'

const POLYGON_BASE_URL = 'https://api.polygon.io'

// Supported live assets (limited set for initial launch)
export const LIVE_STOCK_ASSETS = ['SPY', 'QQQ', 'NVDA'] as const
export type LiveStockAsset = typeof LIVE_STOCK_ASSETS[number]

// US Stock Market Hours (Eastern Time)
const MARKET_OPEN_HOUR = 9.5  // 9:30 AM ET
const MARKET_CLOSE_HOUR = 16  // 4:00 PM ET

interface PolygonAggregateResult {
  v: number   // volume
  vw: number  // volume weighted average price
  o: number   // open
  c: number   // close
  h: number   // high
  l: number   // low
  t: number   // timestamp (ms)
  n: number   // number of transactions
}

interface PolygonAggregatesResponse {
  ticker: string
  queryCount: number
  resultsCount: number
  adjusted: boolean
  results: PolygonAggregateResult[]
  status: string
  request_id: string
}

interface PolygonSnapshotResponse {
  status: string
  request_id: string
  ticker: {
    ticker: string
    day: {
      o: number
      h: number
      l: number
      c: number
      v: number
      vw: number
    }
    prevDay: {
      o: number
      h: number
      l: number
      c: number
      v: number
      vw: number
    }
    lastTrade: {
      p: number  // price
      s: number  // size
      t: number  // timestamp
    }
    todaysChange: number
    todaysChangePerc: number
  }
}

export class LiveStockProvider {
  private apiKey: string
  
  constructor() {
    this.apiKey = process.env.POLYGON_API_KEY || ''
    if (!this.apiKey) {
      console.warn('[LiveStockProvider] POLYGON_API_KEY not set - will use fallback mock data')
    }
  }
  
  isConfigured(): boolean {
    return !!this.apiKey
  }
  
  isAssetSupported(symbol: string): boolean {
    return LIVE_STOCK_ASSETS.includes(symbol as LiveStockAsset)
  }
  
  // Check if US stock market is currently open
  isMarketOpen(): boolean {
    const now = new Date()
    const etOffset = this.getETOffset()
    const etHour = (now.getUTCHours() + etOffset + 24) % 24
    const etMinutes = now.getUTCMinutes()
    const currentTime = etHour + etMinutes / 60
    
    const day = now.getUTCDay()
    // Closed on weekends
    if (day === 0 || day === 6) return false
    
    // Market hours: 9:30 AM - 4:00 PM ET
    return currentTime >= MARKET_OPEN_HOUR && currentTime < MARKET_CLOSE_HOUR
  }
  
  // Get Eastern Time offset (handles DST)
  private getETOffset(): number {
    const now = new Date()
    const jan = new Date(now.getFullYear(), 0, 1)
    const jul = new Date(now.getFullYear(), 6, 1)
    const stdOffset = Math.max(jan.getTimezoneOffset(), jul.getTimezoneOffset())
    const isDST = now.getTimezoneOffset() < stdOffset
    return isDST ? -4 : -5
  }
  
  // Get current session name
  getCurrentSession(): string {
    const now = new Date()
    const etOffset = this.getETOffset()
    const etHour = (now.getUTCHours() + etOffset + 24) % 24
    
    if (etHour >= 4 && etHour < 9.5) return 'premarket'
    if (etHour >= 9.5 && etHour < 12) return 'morning'
    if (etHour >= 12 && etHour < 14) return 'midday'
    if (etHour >= 14 && etHour < 16) return 'afternoon'
    if (etHour >= 16 && etHour < 20) return 'afterhours'
    return 'closed'
  }
  
  // Fetch OHLCV candles from Polygon
  async getCandles(symbol: string, timeframe: string, count: number = 100): Promise<OHLCV[]> {
    if (!this.isConfigured()) {
      console.log(`[LiveStockProvider] No API key - returning empty for ${symbol}`)
      return []
    }
    
    if (!this.isAssetSupported(symbol)) {
      console.log(`[LiveStockProvider] Asset ${symbol} not in live supported list`)
      return []
    }
    
    const multiplier = timeframe === '15m' ? 15 : timeframe === '30m' ? 30 : 60
    const timespan = 'minute'
    
    // Calculate date range
    const now = new Date()
    const from = new Date(now.getTime() - (count * multiplier * 60 * 1000 * 2)) // Extra buffer
    
    const fromDate = from.toISOString().split('T')[0]
    const toDate = now.toISOString().split('T')[0]
    
    try {
      const url = `${POLYGON_BASE_URL}/v2/aggs/ticker/${symbol}/range/${multiplier}/${timespan}/${fromDate}/${toDate}?adjusted=true&sort=asc&limit=${count}&apiKey=${this.apiKey}`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        console.error(`[LiveStockProvider] Polygon API error: ${response.status}`)
        return []
      }
      
      const data: PolygonAggregatesResponse = await response.json()
      
      if (!data.results || data.results.length === 0) {
        console.log(`[LiveStockProvider] No candle data returned for ${symbol}`)
        return []
      }
      
      // Convert to OHLCV format
      return data.results.slice(-count).map((bar): OHLCV => ({
        timestamp: bar.t,
        open: bar.o,
        high: bar.h,
        low: bar.l,
        close: bar.c,
        volume: bar.v
      }))
    } catch (error) {
      console.error(`[LiveStockProvider] Error fetching candles for ${symbol}:`, error)
      return []
    }
  }
  
  // Get latest price snapshot
  async getLatestPrice(symbol: string): Promise<{ price: number; change: number; changePercent: number } | null> {
    if (!this.isConfigured() || !this.isAssetSupported(symbol)) {
      return null
    }
    
    try {
      const url = `${POLYGON_BASE_URL}/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${this.apiKey}`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        console.error(`[LiveStockProvider] Snapshot error: ${response.status}`)
        return null
      }
      
      const data: PolygonSnapshotResponse = await response.json()
      
      if (!data.ticker) {
        return null
      }
      
      return {
        price: data.ticker.lastTrade?.p || data.ticker.day?.c || 0,
        change: data.ticker.todaysChange || 0,
        changePercent: data.ticker.todaysChangePerc || 0
      }
    } catch (error) {
      console.error(`[LiveStockProvider] Error fetching price for ${symbol}:`, error)
      return null
    }
  }
  
  // Get previous session high/low
  async getPreviousSession(symbol: string): Promise<{ high: number; low: number; close: number } | null> {
    if (!this.isConfigured() || !this.isAssetSupported(symbol)) {
      return null
    }
    
    try {
      const url = `${POLYGON_BASE_URL}/v2/snapshot/locale/us/markets/stocks/tickers/${symbol}?apiKey=${this.apiKey}`
      
      const response = await fetch(url)
      
      if (!response.ok) {
        return null
      }
      
      const data: PolygonSnapshotResponse = await response.json()
      
      if (!data.ticker?.prevDay) {
        return null
      }
      
      return {
        high: data.ticker.prevDay.h,
        low: data.ticker.prevDay.l,
        close: data.ticker.prevDay.c
      }
    } catch (error) {
      console.error(`[LiveStockProvider] Error fetching previous session:`, error)
      return null
    }
  }
  
  // Calculate support/resistance levels from candle data
  calculateLevels(candles: OHLCV[]): SupportResistanceLevel[] {
    if (candles.length < 20) return []
    
    const levels: SupportResistanceLevel[] = []
    const recentCandles = candles.slice(-50)
    
    // Find swing highs and lows
    for (let i = 2; i < recentCandles.length - 2; i++) {
      const candle = recentCandles[i]
      const prev1 = recentCandles[i - 1]
      const prev2 = recentCandles[i - 2]
      const next1 = recentCandles[i + 1]
      const next2 = recentCandles[i + 2]
      
      // Swing high
      if (candle.high > prev1.high && candle.high > prev2.high &&
          candle.high > next1.high && candle.high > next2.high) {
        levels.push({
          price: candle.high,
          type: 'resistance',
          strength: 0.7 + Math.random() * 0.3,
          touches: 1
        })
      }
      
      // Swing low
      if (candle.low < prev1.low && candle.low < prev2.low &&
          candle.low < next1.low && candle.low < next2.low) {
        levels.push({
          price: candle.low,
          type: 'support',
          strength: 0.7 + Math.random() * 0.3,
          touches: 1
        })
      }
    }
    
    // Merge nearby levels
    const mergedLevels: SupportResistanceLevel[] = []
    const sortedLevels = levels.sort((a, b) => a.price - b.price)
    
    for (const level of sortedLevels) {
      const nearby = mergedLevels.find(l => Math.abs(l.price - level.price) / level.price < 0.005)
      if (nearby) {
        nearby.touches++
        nearby.strength = Math.min(1, nearby.strength + 0.1)
      } else {
        mergedLevels.push({ ...level })
      }
    }
    
    return mergedLevels.sort((a, b) => b.strength - a.strength).slice(0, 10)
  }
  
  // Analyze trend from candle data
  analyzeTrend(candles: OHLCV[]): TrendAnalysis {
    if (candles.length < 20) {
      return { direction: 'neutral', strength: 0, ema20: 0, ema50: 0 }
    }
    
    // Calculate EMAs
    const closes = candles.map(c => c.close)
    const ema20 = this.calculateEMA(closes, 20)
    const ema50 = this.calculateEMA(closes, Math.min(50, closes.length))
    
    const currentPrice = closes[closes.length - 1]
    
    // Determine trend direction
    let direction: 'bullish' | 'bearish' | 'neutral' = 'neutral'
    if (currentPrice > ema20 && ema20 > ema50) {
      direction = 'bullish'
    } else if (currentPrice < ema20 && ema20 < ema50) {
      direction = 'bearish'
    }
    
    // Calculate trend strength (0-1)
    const priceVsEma = Math.abs(currentPrice - ema20) / currentPrice
    const emaSpread = Math.abs(ema20 - ema50) / ema50
    const strength = Math.min(1, (priceVsEma + emaSpread) * 10)
    
    return { direction, strength, ema20, ema50 }
  }
  
  private calculateEMA(data: number[], period: number): number {
    if (data.length < period) return data[data.length - 1] || 0
    
    const k = 2 / (period + 1)
    let ema = data.slice(0, period).reduce((a, b) => a + b, 0) / period
    
    for (let i = period; i < data.length; i++) {
      ema = data[i] * k + ema * (1 - k)
    }
    
    return ema
  }
}

// Singleton instance
export const liveStockProvider = new LiveStockProvider()
