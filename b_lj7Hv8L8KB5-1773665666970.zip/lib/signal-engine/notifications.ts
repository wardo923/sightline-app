// Notification Service
// Handles sending real notifications based on user plan and preferences

import { createClient } from '@/lib/supabase/server'
import { SignalRecord } from './types'

type NotificationChannel = 'email' | 'sms' | 'push' | 'webhook' | 'in_app'
type AlertType = 'new_setup' | 'setup_changed' | 'setup_invalidated'

interface NotificationConfig {
  channels: NotificationChannel[]
}

// Plan-based notification configuration
const PLAN_NOTIFICATIONS: Record<string, NotificationConfig> = {
  starter: {
    channels: ['email', 'in_app']
  },
  pro: {
    channels: ['email', 'sms', 'in_app']
  },
  elite: {
    channels: ['email', 'sms', 'webhook', 'in_app']
  }
}

// Format signal for new setup email
function formatNewSetupEmail(signal: SignalRecord): { subject: string; html: string; text: string } {
  const direction = signal.direction === 'BUY' ? 'Long' : 'Short'
  const subject = `${signal.asset} ${signal.setup_type} Setup Detected`
  
  const html = `
<!DOCTYPE html>
<html>
<head>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0a0a0a; color: #fff; padding: 20px; }
    .container { max-width: 500px; margin: 0 auto; background: #111; border: 1px solid #222; border-radius: 12px; padding: 24px; }
    .header { border-bottom: 1px solid #222; padding-bottom: 16px; margin-bottom: 16px; }
    .asset { font-size: 24px; font-weight: bold; color: #fff; }
    .setup-type { font-size: 14px; color: #00dc82; margin-top: 4px; }
    .grade { display: inline-block; background: ${signal.signal_grade === 'A' ? '#00dc82' : signal.signal_grade === 'B' ? '#f59e0b' : '#6b7280'}20; color: ${signal.signal_grade === 'A' ? '#00dc82' : signal.signal_grade === 'B' ? '#f59e0b' : '#6b7280'}; padding: 4px 12px; border-radius: 6px; font-weight: bold; margin-top: 8px; }
    .levels { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; margin: 16px 0; }
    .level-box { background: #1a1a1a; border-radius: 8px; padding: 12px; }
    .level-label { font-size: 11px; color: #666; text-transform: uppercase; }
    .level-value { font-size: 18px; font-weight: bold; margin-top: 4px; }
    .entry { color: #fff; }
    .stop { color: #ef4444; }
    .target { color: #00dc82; }
    .rr { color: #00dc82; }
    .disclaimer { font-size: 11px; color: #666; margin-top: 20px; padding-top: 16px; border-top: 1px solid #222; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <div class="asset">${signal.asset}</div>
      <div class="setup-type">${signal.setup_type} - ${direction}</div>
      <div class="grade">Grade ${signal.signal_grade}</div>
    </div>
    
    <div class="levels">
      <div class="level-box">
        <div class="level-label">Entry</div>
        <div class="level-value entry">${signal.entry_price}</div>
      </div>
      <div class="level-box">
        <div class="level-label">Stop Loss</div>
        <div class="level-value stop">${signal.stop_loss}</div>
      </div>
      <div class="level-box">
        <div class="level-label">Target 1</div>
        <div class="level-value target">${signal.target_1}</div>
      </div>
      <div class="level-box">
        <div class="level-label">R:R</div>
        <div class="level-value rr">${signal.reward_risk_ratio}</div>
      </div>
    </div>
    
    <div class="disclaimer">
      <strong>Educational alert only.</strong> SightLine provides market analytics, not investment advice. Always conduct your own analysis.
    </div>
  </div>
</body>
</html>
  `.trim()

  const text = `
${signal.asset} ${signal.setup_type} Setup Detected

Strategy: ${signal.setup_type}
Direction: ${direction}
Grade: ${signal.signal_grade}

Watch Level: ${signal.entry_price}
Example Entry Zone: ${signal.entry_price}
Example Invalidation Level: ${signal.stop_loss}
Example Target Zone: ${signal.target_1}

Educational market alert only.
SightLine provides market analytics, not investment advice.
  `.trim()

  return { subject, html, text }
}

// Format signal for SMS (short)
function formatSMSMessage(signal: SignalRecord, alertType: AlertType): string {
  const direction = signal.direction === 'BUY' ? 'Long' : 'Short'
  
  switch (alertType) {
    case 'new_setup':
      return `SightLine: ${signal.asset} ${signal.setup_type}\n${direction} @ ${signal.entry_price}\nStop: ${signal.stop_loss} | T1: ${signal.target_1}\nGrade ${signal.signal_grade} | ${signal.reward_risk_ratio}R\n\nEducational only.`
    case 'setup_changed':
      return `SightLine: ${signal.asset} setup updated.\nNew Entry: ${signal.entry_price}\nNew Stop: ${signal.stop_loss}\n\nEducational only.`
    case 'setup_invalidated':
      return `SightLine: ${signal.asset} ${signal.setup_type} setup invalidated. Price hit stop level.\n\nEducational only.`
    default:
      return `SightLine: ${signal.asset} alert. Check dashboard.`
  }
}

// Format for webhook payload
function formatWebhookPayload(signal: SignalRecord, alertType: AlertType): object {
  return {
    event: alertType,
    timestamp: new Date().toISOString(),
    signal: {
      id: signal.id,
      asset: signal.asset,
      direction: signal.direction,
      setup_type: signal.setup_type,
      timeframe: signal.timeframe,
      grade: signal.signal_grade,
      entry_price: signal.entry_price,
      stop_loss: signal.stop_loss,
      target_1: signal.target_1,
      target_2: signal.target_2,
      reward_risk_ratio: signal.reward_risk_ratio,
      structure_bias: signal.structure_bias,
      market_condition: signal.market_condition,
      why_qualifies: signal.why_qualifies
    }
  }
}

export class NotificationService {
  
  // Get user's subscription plan
  private async getUserPlan(supabase: Awaited<ReturnType<typeof createClient>>, userId: string): Promise<string> {
    const { data } = await supabase
      .from('subscriptions')
      .select('plan, status')
      .eq('user_id', userId)
      .eq('status', 'active')
      .single()
    
    return data?.plan || 'starter'
  }
  
  // Get user's contact info
  private async getUserContact(supabase: Awaited<ReturnType<typeof createClient>>, userId: string): Promise<{ email: string | null; phone: string | null; webhookUrl: string | null }> {
    const { data: profile } = await supabase
      .from('profiles')
      .select('email, phone, webhook_url')
      .eq('id', userId)
      .single()
    
    // Also check auth.users for email
    const { data: authUser } = await supabase.auth.admin.getUserById(userId).catch(() => ({ data: null }))
    
    return {
      email: profile?.email || authUser?.user?.email || null,
      phone: profile?.phone || null,
      webhookUrl: profile?.webhook_url || null
    }
  }
  
  // Log notification delivery
  private async logDelivery(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    signalId: string,
    channel: NotificationChannel,
    status: 'pending' | 'sent' | 'delivered' | 'failed',
    subject: string,
    body: string,
    recipient: string,
    errorMessage?: string
  ): Promise<void> {
    await supabase
      .from('notification_delivery_log')
      .insert({
        user_id: userId,
        signal_id: signalId,
        channel,
        status,
        subject,
        body,
        recipient,
        sent_at: status === 'sent' || status === 'delivered' ? new Date().toISOString() : null,
        error_message: errorMessage
      })
  }
  
  // Send email via Resend
  private async sendEmail(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    signalId: string,
    email: string,
    subject: string,
    html: string,
    text: string
  ): Promise<boolean> {
    const resendApiKey = process.env.RESEND_API_KEY
    
    if (!resendApiKey) {
      console.log('[Email] RESEND_API_KEY not configured, logging only')
      await this.logDelivery(supabase, userId, signalId, 'email', 'pending', subject, text, email, 'RESEND_API_KEY not configured')
      return false
    }
    
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${resendApiKey}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          from: 'SightLine <alerts@sightline.app>',
          to: [email],
          subject,
          html,
          text
        })
      })
      
      if (!response.ok) {
        const error = await response.text()
        throw new Error(`Resend API error: ${error}`)
      }
      
      await this.logDelivery(supabase, userId, signalId, 'email', 'sent', subject, text, email)
      console.log(`[Email] Sent to ${email}`)
      return true
    } catch (error) {
      console.error(`[Email] Failed:`, error)
      await this.logDelivery(supabase, userId, signalId, 'email', 'failed', subject, text, email, String(error))
      return false
    }
  }
  
  // Send SMS via Twilio
  private async sendSMS(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    signalId: string,
    phone: string,
    message: string
  ): Promise<boolean> {
    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER
    
    if (!accountSid || !authToken || !fromNumber) {
      console.log('[SMS] Twilio not configured, logging only')
      await this.logDelivery(supabase, userId, signalId, 'sms', 'pending', 'Signal Alert', message, phone, 'Twilio not configured')
      return false
    }
    
    try {
      const response = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${accountSid}/Messages.json`,
        {
          method: 'POST',
          headers: {
            'Authorization': 'Basic ' + Buffer.from(`${accountSid}:${authToken}`).toString('base64'),
            'Content-Type': 'application/x-www-form-urlencoded'
          },
          body: new URLSearchParams({
            To: phone,
            From: fromNumber,
            Body: message
          })
        }
      )
      
      if (!response.ok) {
        const error = await response.text()
        throw new Error(`Twilio API error: ${error}`)
      }
      
      await this.logDelivery(supabase, userId, signalId, 'sms', 'sent', 'Signal Alert', message, phone)
      console.log(`[SMS] Sent to ${phone}`)
      return true
    } catch (error) {
      console.error(`[SMS] Failed:`, error)
      await this.logDelivery(supabase, userId, signalId, 'sms', 'failed', 'Signal Alert', message, phone, String(error))
      return false
    }
  }
  
  // Send webhook notification
  private async sendWebhook(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    signalId: string,
    webhookUrl: string,
    payload: object
  ): Promise<boolean> {
    try {
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
      
      if (!response.ok) {
        throw new Error(`Webhook returned ${response.status}`)
      }
      
      await this.logDelivery(
        supabase, 
        userId, 
        signalId, 
        'webhook', 
        'delivered', 
        'Signal Webhook', 
        JSON.stringify(payload), 
        webhookUrl
      )
      console.log(`[Webhook] Delivered to ${webhookUrl}`)
      return true
    } catch (error) {
      console.error(`[Webhook] Failed:`, error)
      await this.logDelivery(
        supabase, 
        userId, 
        signalId, 
        'webhook', 
        'failed', 
        'Signal Webhook', 
        JSON.stringify(payload), 
        webhookUrl, 
        String(error)
      )
      return false
    }
  }
  
  // Create in-app notification
  private async createInAppNotification(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    signalId: string,
    subject: string,
    body: string
  ): Promise<boolean> {
    try {
      await this.logDelivery(supabase, userId, signalId, 'in_app', 'delivered', subject, body, userId)
      return true
    } catch (error) {
      return false
    }
  }
  
  // Send all notifications for a new signal
  async notifyNewSetup(signal: SignalRecord): Promise<{ sent: string[]; failed: string[] }> {
    return this.notify(signal, 'new_setup')
  }
  
  // Send all notifications for a changed signal
  async notifySetupChanged(signal: SignalRecord): Promise<{ sent: string[]; failed: string[] }> {
    return this.notify(signal, 'setup_changed')
  }
  
  // Send all notifications for an invalidated signal
  async notifySetupInvalidated(signal: SignalRecord): Promise<{ sent: string[]; failed: string[] }> {
    return this.notify(signal, 'setup_invalidated')
  }
  
  // Core notification logic
  private async notify(signal: SignalRecord, alertType: AlertType): Promise<{ sent: string[]; failed: string[] }> {
    const supabase = await createClient()
    const sent: string[] = []
    const failed: string[] = []
    
    if (!signal.id) {
      return { sent, failed: ['Signal has no ID'] }
    }
    
    // Get user plan and config
    const plan = await this.getUserPlan(supabase, signal.user_id)
    const config = PLAN_NOTIFICATIONS[plan] || PLAN_NOTIFICATIONS.starter
    
    // Get user contact info
    const contact = await this.getUserContact(supabase, signal.user_id)
    
    // Format messages
    const { subject, html, text } = formatNewSetupEmail(signal)
    const smsMessage = formatSMSMessage(signal, alertType)
    const webhookPayload = formatWebhookPayload(signal, alertType)
    
    // Send to each channel
    for (const channel of config.channels) {
      switch (channel) {
        case 'email':
          if (contact.email) {
            const success = await this.sendEmail(supabase, signal.user_id, signal.id, contact.email, subject, html, text)
            success ? sent.push('email') : failed.push('email')
          } else {
            failed.push('email (no address)')
          }
          break
        
        case 'sms':
          if (contact.phone) {
            const success = await this.sendSMS(supabase, signal.user_id, signal.id, contact.phone, smsMessage)
            success ? sent.push('sms') : failed.push('sms')
          } else {
            // Not a failure - just not configured
            sent.push('sms (skipped - no phone)')
          }
          break
        
        case 'webhook':
          if (contact.webhookUrl) {
            const success = await this.sendWebhook(supabase, signal.user_id, signal.id, contact.webhookUrl, webhookPayload)
            success ? sent.push('webhook') : failed.push('webhook')
          } else {
            sent.push('webhook (skipped - no URL)')
          }
          break
        
        case 'in_app':
          const success = await this.createInAppNotification(supabase, signal.user_id, signal.id, subject, text)
          success ? sent.push('in_app') : failed.push('in_app')
          break
      }
    }
    
    return { sent, failed }
  }
  
  // Notify for multiple signals
  async notifyForSignals(signals: SignalRecord[]): Promise<Map<string, { sent: string[]; failed: string[] }>> {
    const results = new Map<string, { sent: string[]; failed: string[] }>()
    
    for (const signal of signals) {
      if (signal.id) {
        const result = await this.notifyNewSetup(signal)
        results.set(signal.id, result)
      }
    }
    
    return results
  }
}

// Export singleton
export const notificationService = new NotificationService()
