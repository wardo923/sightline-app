// ============================================
// SIGHTLINE MODEL DEFINITIONS
// Locked configurations for signal generation
// ============================================

import { SetupType } from './types'

// Market types
export type MarketType = 'index_etf' | 'largecap_stocks' | 'crypto'

export interface MarketTypeConfig {
  id: MarketType
  name: string
  description: string
  assets: string[]
}

export const MARKET_TYPES: Record<MarketType, MarketTypeConfig> = {
  index_etf: {
    id: 'index_etf',
    name: 'Index / ETF',
    description: 'SPY, QQQ',
    assets: ['SPY', 'QQQ'],
  },
  largecap_stocks: {
    id: 'largecap_stocks',
    name: 'Large-Cap Stocks',
    description: 'NVDA, AAPL, MSFT, AMD, TSLA',
    assets: ['NVDA', 'AAPL', 'MSFT', 'AMD', 'TSLA'],
  },
  crypto: {
    id: 'crypto',
    name: 'Crypto',
    description: 'BTC, ETH, SOL',
    assets: ['BTC', 'ETH', 'SOL'],
  },
}

export interface ModelConfig {
  id: string
  name: string
  subtitle: string
  description: string
  marketType: MarketType
  assets: string[]
  timeframes: string[]
  session: string
  signalType: string
  minRiskReward: number
  minGrade: 'A' | 'B' | 'C'
  confirmationStyle: 'strict' | 'standard' | 'relaxed'
  setupTypes: SetupType[]
  requireVolumeConfirmation: boolean
  requireTrendAlignment: boolean
  maxSignalsPerDay: number
  cooldownMinutes: number
  whyItWorks: string[]
  // Visual styling
  gradient: string
  icon: string
}

// ============================================
// INDEX / ETF MODELS (5)
// ============================================

const INDEX_MODELS: Record<string, ModelConfig> = {
  opening_range_expert: {
    id: 'opening_range_expert',
    name: 'Opening Range Expert',
    subtitle: 'Precision Market Open Strategy',
    description: 'Captures institutional momentum at market open with strict breakout confirmation.',
    marketType: 'index_etf',
    assets: ['SPY', 'QQQ'],
    timeframes: ['5m', '15m'],
    session: 'Market Open',
    signalType: 'Opening Range Breakout',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'strict',
    setupTypes: ['breakout'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: false,
    maxSignalsPerDay: 3,
    cooldownMinutes: 30,
    whyItWorks: [
      'Captures institutional open momentum',
      'Avoids midday chop',
      'Strong volume confirmation required',
      'Strict risk-to-reward filtering',
    ],
    gradient: 'from-emerald-500/20 to-teal-500/20',
    icon: 'sunrise',
  },
  vwap_reclaim: {
    id: 'vwap_reclaim',
    name: 'VWAP Reclaim',
    subtitle: 'Institutional Reclaim Strategy',
    description: 'Tracks institutional fair value with VWAP reclaim setups.',
    marketType: 'index_etf',
    assets: ['SPY', 'QQQ'],
    timeframes: ['5m', '15m'],
    session: 'Morning / Midday',
    signalType: 'VWAP Reclaim',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'standard',
    setupTypes: ['break_retest'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: false,
    maxSignalsPerDay: 4,
    cooldownMinutes: 45,
    whyItWorks: [
      'Tracks institutional fair value behavior',
      'Strong continuation after reclaim',
      'Cleaner entries than random breakouts',
      'Designed to avoid chop',
    ],
    gradient: 'from-blue-500/20 to-indigo-500/20',
    icon: 'activity',
  },
  liquidity_sweep_index: {
    id: 'liquidity_sweep_index',
    name: 'Liquidity Sweep',
    subtitle: 'Stop-Run Reversal Strategy',
    description: 'Targets stop-run reversals at key liquidity levels.',
    marketType: 'index_etf',
    assets: ['SPY', 'QQQ'],
    timeframes: ['5m', '15m'],
    session: 'Morning / Afternoon',
    signalType: 'Liquidity Sweep Reversal',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'strict',
    setupTypes: ['support_hold', 'resistance_rejection'],
    requireVolumeConfirmation: false,
    requireTrendAlignment: false,
    maxSignalsPerDay: 3,
    cooldownMinutes: 60,
    whyItWorks: [
      'Targets stop-run reversals',
      'Uses rejection and confirmation',
      'Focuses on high-liquidity levels',
      'Built for selective reversal entries',
    ],
    gradient: 'from-purple-500/20 to-pink-500/20',
    icon: 'zap',
  },
  index_pullback: {
    id: 'index_pullback',
    name: 'Index Pullback',
    subtitle: 'Trend Continuation Pullback Model',
    description: 'Buys retracements in strong trends with structure confirmation.',
    marketType: 'index_etf',
    assets: ['SPY', 'QQQ'],
    timeframes: ['15m'],
    session: 'Morning / Midday',
    signalType: 'Pullback Continuation',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'standard',
    setupTypes: ['pullback'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: true,
    maxSignalsPerDay: 4,
    cooldownMinutes: 45,
    whyItWorks: [
      'Buys retracements in strong trends',
      'Avoids chasing extended moves',
      'Uses structure-based confirmation',
      'Designed for cleaner continuation setups',
    ],
    gradient: 'from-cyan-500/20 to-blue-500/20',
    icon: 'trending-up',
  },
  index_momentum: {
    id: 'index_momentum',
    name: 'Index Momentum',
    subtitle: 'Directional Expansion Model',
    description: 'Captures clean directional momentum moves in the morning session.',
    marketType: 'index_etf',
    assets: ['SPY', 'QQQ'],
    timeframes: ['15m'],
    session: 'Morning',
    signalType: 'Momentum Breakout',
    minRiskReward: 2.0,
    minGrade: 'A',
    confirmationStyle: 'strict',
    setupTypes: ['breakout', 'trend_continuation'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: false,
    maxSignalsPerDay: 3,
    cooldownMinutes: 60,
    whyItWorks: [
      'Captures clean directional moves',
      'Focuses on morning momentum',
      'Uses strict breakout confirmation',
      'Avoids weak low-energy sessions',
    ],
    gradient: 'from-amber-500/20 to-orange-500/20',
    icon: 'rocket',
  },
}

// ============================================
// LARGE-CAP STOCK MODELS (4)
// ============================================

const LARGECAP_MODELS: Record<string, ModelConfig> = {
  largecap_breakout: {
    id: 'largecap_breakout',
    name: 'Large-Cap Breakout',
    subtitle: 'Momentum Expansion for Large-Cap Leaders',
    description: 'Captures strong momentum breakouts in leading large-cap stocks.',
    marketType: 'largecap_stocks',
    assets: ['NVDA', 'AAPL', 'MSFT', 'AMD', 'TSLA'],
    timeframes: ['15m', '30m'],
    session: 'Morning',
    signalType: 'Breakout + Volume',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'standard',
    setupTypes: ['breakout'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: false,
    maxSignalsPerDay: 4,
    cooldownMinutes: 45,
    whyItWorks: [
      'Captures strong large-cap momentum',
      'Best for clean expansion moves',
      'Volume confirms break quality',
      'Designed for leading names only',
    ],
    gradient: 'from-emerald-500/20 to-green-500/20',
    icon: 'bar-chart-2',
  },
  institutional_pullback: {
    id: 'institutional_pullback',
    name: 'Institutional Pullback',
    subtitle: 'High-Quality Retracement Model',
    description: 'Patient continuation entries at meaningful support levels.',
    marketType: 'largecap_stocks',
    assets: ['NVDA', 'AAPL', 'MSFT', 'AMD', 'TSLA'],
    timeframes: ['30m', '1h'],
    session: 'Midday',
    signalType: 'Pullback Continuation',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'strict',
    setupTypes: ['pullback', 'break_retest'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: true,
    maxSignalsPerDay: 3,
    cooldownMinutes: 90,
    whyItWorks: [
      'Focuses on patient continuation entries',
      'Avoids chasing strength',
      'Uses structure for cleaner risk',
      'Better for disciplined swing-style flow',
    ],
    gradient: 'from-blue-500/20 to-cyan-500/20',
    icon: 'git-pull-request',
  },
  level_rejection: {
    id: 'level_rejection',
    name: 'Level Rejection',
    subtitle: 'Support / Resistance Defense Model',
    description: 'High-probability bounces at major structure zones.',
    marketType: 'largecap_stocks',
    assets: ['NVDA', 'AAPL', 'MSFT', 'AMD', 'TSLA'],
    timeframes: ['30m', '1h'],
    session: 'Any Session',
    signalType: 'Support Hold / Resistance Rejection',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'strict',
    setupTypes: ['support_hold', 'resistance_rejection'],
    requireVolumeConfirmation: false,
    requireTrendAlignment: false,
    maxSignalsPerDay: 4,
    cooldownMinutes: 60,
    whyItWorks: [
      'Built around key structure zones',
      'Uses rejection, not guessing',
      'Avoids weak random reversals',
      'Designed for cleaner risk placement',
    ],
    gradient: 'from-violet-500/20 to-purple-500/20',
    icon: 'shield',
  },
  trend_rider: {
    id: 'trend_rider',
    name: 'Trend Rider',
    subtitle: 'Ride Strong Momentum',
    description: 'Continuation entries aligned with higher timeframe trends.',
    marketType: 'largecap_stocks',
    assets: ['NVDA', 'AAPL', 'MSFT', 'AMD', 'TSLA'],
    timeframes: ['30m', '1h'],
    session: 'Morning / Midday',
    signalType: 'Trend Continuation',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'standard',
    setupTypes: ['trend_continuation', 'pullback'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: true,
    maxSignalsPerDay: 3,
    cooldownMinutes: 90,
    whyItWorks: [
      'Built for strong established trends',
      'Aligns with higher timeframe direction',
      'Focuses on continuation, not prediction',
      'Selective model with clear invalidation',
    ],
    gradient: 'from-teal-500/20 to-emerald-500/20',
    icon: 'trending-up',
  },
}

// ============================================
// CRYPTO MODELS (4)
// ============================================

const CRYPTO_MODELS: Record<string, ModelConfig> = {
  crypto_momentum: {
    id: 'crypto_momentum',
    name: 'Crypto Momentum',
    subtitle: 'Trade BTC, ETH, and SOL Trends',
    description: 'Captures breakout expansion in liquid crypto majors.',
    marketType: 'crypto',
    assets: ['BTC', 'ETH', 'SOL'],
    timeframes: ['15m'],
    session: 'Anytime (24/7)',
    signalType: 'Momentum Breakout',
    minRiskReward: 2.0,
    minGrade: 'A',
    confirmationStyle: 'strict',
    setupTypes: ['breakout', 'trend_continuation'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: false,
    maxSignalsPerDay: 5,
    cooldownMinutes: 60,
    whyItWorks: [
      'Built for 24/7 crypto momentum',
      'Captures breakout expansion',
      'Designed for strong trend days',
      'Focuses on liquid majors only',
    ],
    gradient: 'from-orange-500/20 to-amber-500/20',
    icon: 'zap',
  },
  crypto_continuation: {
    id: 'crypto_continuation',
    name: 'Crypto Continuation',
    subtitle: 'Trend Continuation in Liquid Crypto',
    description: 'Trend-following pullback entries in strong crypto moves.',
    marketType: 'crypto',
    assets: ['BTC', 'ETH', 'SOL'],
    timeframes: ['15m'],
    session: 'Anytime (24/7)',
    signalType: 'Pullback Continuation',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'standard',
    setupTypes: ['pullback', 'trend_continuation'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: true,
    maxSignalsPerDay: 4,
    cooldownMinutes: 45,
    whyItWorks: [
      'Designed for trend-following crypto setups',
      'Avoids late chase entries',
      'Cleaner structure-based risk',
      'Works best in strong directional conditions',
    ],
    gradient: 'from-blue-500/20 to-indigo-500/20',
    icon: 'repeat',
  },
  compression_breakout: {
    id: 'compression_breakout',
    name: 'Compression Breakout',
    subtitle: 'Volatility Contraction Expansion Model',
    description: 'Captures explosive moves after tight range compression.',
    marketType: 'crypto',
    assets: ['BTC', 'ETH', 'SOL'],
    timeframes: ['15m', '30m'],
    session: 'Anytime (24/7)',
    signalType: 'Compression Breakout',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'standard',
    setupTypes: ['breakout'],
    requireVolumeConfirmation: true,
    requireTrendAlignment: false,
    maxSignalsPerDay: 3,
    cooldownMinutes: 90,
    whyItWorks: [
      'Captures explosive moves after compression',
      'Designed for coiled market conditions',
      'Strong expansion potential',
      'Selective by nature',
    ],
    gradient: 'from-purple-500/20 to-pink-500/20',
    icon: 'maximize-2',
  },
  crypto_liquidity_sweep: {
    id: 'crypto_liquidity_sweep',
    name: 'Crypto Liquidity Sweep',
    subtitle: 'Stop-Run Crypto Reversal Model',
    description: 'Targets crypto stop-run reversals at key liquidity levels.',
    marketType: 'crypto',
    assets: ['BTC', 'ETH', 'SOL'],
    timeframes: ['5m', '15m'],
    session: 'Anytime (24/7)',
    signalType: 'Liquidity Sweep Reversal',
    minRiskReward: 2.0,
    minGrade: 'B',
    confirmationStyle: 'strict',
    setupTypes: ['support_hold', 'resistance_rejection'],
    requireVolumeConfirmation: false,
    requireTrendAlignment: false,
    maxSignalsPerDay: 4,
    cooldownMinutes: 45,
    whyItWorks: [
      'Built for crypto stop-run reversals',
      'Uses clear liquidity logic',
      'Avoids weak random countertrend entries',
      'Stronger when volatility expands',
    ],
    gradient: 'from-red-500/20 to-orange-500/20',
    icon: 'refresh-cw',
  },
}

// ============================================
// COMBINED MODEL REGISTRY
// ============================================

export const MODEL_CONFIGS: Record<string, ModelConfig> = {
  ...INDEX_MODELS,
  ...LARGECAP_MODELS,
  ...CRYPTO_MODELS,
}

// Get models by market type
export function getModelsForMarket(marketType: MarketType): ModelConfig[] {
  return Object.values(MODEL_CONFIGS).filter(m => m.marketType === marketType)
}

// Get model config by ID
export function getModelConfig(modelId: string): ModelConfig | null {
  return MODEL_CONFIGS[modelId] || null
}

// Validate if a detected setup passes model filters
export function validateSetupForModel(
  modelId: string,
  setup: {
    setupType: SetupType
    timeframe: string
    riskReward: number
    grade: 'A' | 'B' | 'C'
    hasVolumeConfirmation: boolean
    alignsWithTrend: boolean
  }
): { valid: boolean; reason?: string } {
  const model = getModelConfig(modelId)
  if (!model) {
    return { valid: false, reason: 'Model not found' }
  }

  // Check setup type
  if (!model.setupTypes.includes(setup.setupType)) {
    return { valid: false, reason: `Setup type ${setup.setupType} not in model` }
  }

  // Check timeframe
  if (!model.timeframes.includes(setup.timeframe)) {
    return { valid: false, reason: `Timeframe ${setup.timeframe} not in model` }
  }

  // Check risk/reward
  if (setup.riskReward < model.minRiskReward) {
    return { valid: false, reason: `R:R ${setup.riskReward} below minimum ${model.minRiskReward}` }
  }

  // Check grade
  const gradeOrder = { 'A': 3, 'B': 2, 'C': 1 }
  if (gradeOrder[setup.grade] < gradeOrder[model.minGrade]) {
    return { valid: false, reason: `Grade ${setup.grade} below minimum ${model.minGrade}` }
  }

  // Check volume confirmation if required
  if (model.requireVolumeConfirmation && !setup.hasVolumeConfirmation) {
    return { valid: false, reason: 'Volume confirmation required but not present' }
  }

  // Check trend alignment if required
  if (model.requireTrendAlignment && !setup.alignsWithTrend) {
    return { valid: false, reason: 'Trend alignment required but not present' }
  }

  return { valid: true }
}

// Calculate signal quality grade based on factors
export function calculateGrade(factors: {
  riskReward: number
  levelStrength: number
  volumeConfirmation: boolean
  trendAlignment: boolean
  multipleTimeframeConfirmation: boolean
}): 'A' | 'B' | 'C' {
  let score = 0

  if (factors.riskReward >= 3) score += 30
  else if (factors.riskReward >= 2.5) score += 25
  else if (factors.riskReward >= 2) score += 20
  else if (factors.riskReward >= 1.5) score += 10

  score += Math.round(factors.levelStrength * 25)
  if (factors.volumeConfirmation) score += 15
  if (factors.trendAlignment) score += 15
  if (factors.multipleTimeframeConfirmation) score += 15

  if (score >= 75) return 'A'
  if (score >= 50) return 'B'
  return 'C'
}

// Generate "Why This Qualifies" reasons based on model and setup
export function generateQualificationReasons(
  modelId: string,
  factors: {
    setupType: SetupType
    riskReward: number
    levelStrength: number
    volumeConfirmation: boolean
    trendAlignment: boolean
    priceAction: string
    levelType: string
  }
): string[] {
  const reasons: string[] = []
  const model = getModelConfig(modelId)
  if (!model) return reasons

  // Model-specific first reason
  reasons.push(`${model.name} criteria met`)

  // Setup-specific reasons
  switch (factors.setupType) {
    case 'breakout':
      reasons.push('Clean breakout through key level')
      if (factors.volumeConfirmation) reasons.push('Volume confirms breakout strength')
      break
    case 'break_retest':
      reasons.push('Successful retest of broken level')
      reasons.push('Level now acting as support')
      break
    case 'pullback':
      reasons.push('Pullback to key support zone')
      if (factors.trendAlignment) reasons.push('Aligned with higher timeframe trend')
      break
    case 'trend_continuation':
      reasons.push('Strong trend momentum')
      if (factors.trendAlignment) reasons.push('Higher timeframe trend intact')
      break
    case 'support_hold':
      reasons.push(`Strong rejection at ${factors.levelType}`)
      if (factors.priceAction) reasons.push(`${factors.priceAction} confirmation`)
      break
    case 'resistance_rejection':
      reasons.push(`Clean rejection at resistance`)
      if (factors.priceAction) reasons.push(`${factors.priceAction} reversal signal`)
      break
  }

  if (factors.riskReward >= 2.5) {
    reasons.push(`${factors.riskReward.toFixed(1)}:1 reward to risk`)
  }

  return reasons.slice(0, 4)
}

// Generate example trade for a model
export function generateExampleTrade(modelId: string, asset: string): {
  direction: 'BUY' | 'SELL'
  entry: number
  stop: number
  target: number
  riskReward: string
} | null {
  const model = getModelConfig(modelId)
  if (!model) return null

  // Base prices for different assets
  const basePrices: Record<string, number> = {
    SPY: 523.80,
    QQQ: 448.20,
    NVDA: 875.40,
    AAPL: 184.60,
    MSFT: 418.30,
    AMD: 164.80,
    TSLA: 172.50,
    BTC: 67450,
    ETH: 3420,
    SOL: 145.80,
  }

  const basePrice = basePrices[asset] || 100
  const direction = Math.random() > 0.5 ? 'BUY' : 'SELL'
  
  // Calculate realistic stop and target based on asset volatility
  const volatility = ['BTC', 'ETH', 'SOL', 'TSLA', 'NVDA', 'AMD'].includes(asset) ? 0.012 : 0.005
  const stopDistance = basePrice * volatility
  const targetDistance = stopDistance * model.minRiskReward

  if (direction === 'BUY') {
    return {
      direction,
      entry: basePrice,
      stop: basePrice - stopDistance,
      target: basePrice + targetDistance,
      riskReward: `${model.minRiskReward.toFixed(1)}R`,
    }
  } else {
    return {
      direction,
      entry: basePrice,
      stop: basePrice + stopDistance,
      target: basePrice - targetDistance,
      riskReward: `${model.minRiskReward.toFixed(1)}R`,
    }
  }
}
