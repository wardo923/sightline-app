// Signal Engine Types

// Asset classification
export type AssetClass = 'stock' | 'crypto'

// Supported assets with their classification
export const SUPPORTED_ASSETS: Record<string, { name: string; class: AssetClass; basePrice: number; volatility: number }> = {
  // Crypto (24/7 markets)
  'BTC': { name: 'Bitcoin', class: 'crypto', basePrice: 67500, volatility: 0.025 },
  'ETH': { name: 'Ethereum', class: 'crypto', basePrice: 3400, volatility: 0.030 },
  'SOL': { name: 'Solana', class: 'crypto', basePrice: 145, volatility: 0.035 },
  
  // Stocks/ETFs (market hours apply)
  'SPY': { name: 'S&P 500 ETF', class: 'stock', basePrice: 520, volatility: 0.008 },
  'QQQ': { name: 'Nasdaq 100 ETF', class: 'stock', basePrice: 450, volatility: 0.010 },
  'NVDA': { name: 'NVIDIA', class: 'stock', basePrice: 880, volatility: 0.020 },
  'AAPL': { name: 'Apple', class: 'stock', basePrice: 185, volatility: 0.012 },
  'TSLA': { name: 'Tesla', class: 'stock', basePrice: 175, volatility: 0.025 },
  'MSFT': { name: 'Microsoft', class: 'stock', basePrice: 420, volatility: 0.010 },
  'AMD': { name: 'AMD', class: 'stock', basePrice: 165, volatility: 0.022 },
}

// Helper to get asset class
export function getAssetClass(symbol: string): AssetClass {
  return SUPPORTED_ASSETS[symbol]?.class || 'stock'
}

// Helper to check if asset is supported
export function isAssetSupported(symbol: string): boolean {
  return symbol in SUPPORTED_ASSETS
}

// Supported timeframes
export const SUPPORTED_TIMEFRAMES = ['15m', '30m', '1h'] as const
export type SupportedTimeframe = typeof SUPPORTED_TIMEFRAMES[number]

export interface OHLCV {
  timestamp: number
  open: number
  high: number
  low: number
  close: number
  volume: number
}

export interface MarketData {
  symbol: string
  timeframe: string
  candles: OHLCV[]
  currentPrice: number
  dailyChange: number
  dailyVolume: number
}

export interface SupportResistanceLevel {
  price: number
  type: 'support' | 'resistance'
  strength: number // 1-5
  touches: number
}

export interface TrendAnalysis {
  direction: 'bullish' | 'bearish' | 'neutral'
  strength: number // 0-100
  higherHighs: boolean
  higherLows: boolean
  lowerHighs: boolean
  lowerLows: boolean
}

export interface SetupDetectionResult {
  detected: boolean
  setupType: SetupType
  direction: 'BUY' | 'SELL'
  entryPrice: number
  stopLoss: number
  target1: number
  target2: number
  rewardRiskRatio: number
  structureBias: 'bullish' | 'bearish' | 'neutral'
  whyQualifies: string[]
  marketCondition: string
  grade: 'A' | 'B' | 'C'
  confidence: number // 0-100
  // V1 additions
  setupQuality?: 'Elite' | 'Strong' | 'Developing' | 'NoAlert'
  v1Score?: number // 0-8
  watchLevel?: number
}

// V1 Setup Quality levels
export type SetupQuality = 'Elite' | 'Strong' | 'Developing' | 'NoAlert'

// V1 Alert output format
export interface V1AlertOutput {
  setupQuality: SetupQuality
  whyAppeared: string[]
  watchLevel: number
  exampleEntryZone: { low: number; high: number }
  exampleInvalidation: number
  exampleTargetZone: { target1: number; target2: number }
}

export type SetupType = 
  | 'Breakout'
  | 'Break + Retest'
  | 'Pullback'
  | 'Trend Continuation'
  | 'Support Hold'
  | 'Resistance Rejection'

export interface UserStrategy {
  id: string
  user_id: string
  markets: string[]
  trading_style: string
  timeframe: string
  time_of_day: string
  setup_preference: string
  confirmation_style: string
  alert_style: string
  signal_frequency: string
  risk_per_trade: string
  account_size: string | null
  // Matrix bundle info (from new wizard)
  bundle_name?: string
  wizard_answers?: {
    _matrixBundle?: string
    _matrixSecondary?: string | null
    _matrixConfidence?: number
    _matrixScores?: Record<string, number>
    [key: string]: unknown
  }
}

export interface UserSubscription {
  id: string
  user_id: string
  plan: 'starter' | 'pro' | 'elite'
  status: string
}

export interface SignalRecord {
  id?: string
  user_id: string
  strategy_id: string
  asset: string
  timeframe: string
  direction: 'BUY' | 'SELL'
  setup_type: SetupType
  entry_price: number
  stop_loss: number
  target_1: number
  target_2: number
  reward_risk_ratio: number
  signal_grade: 'A' | 'B' | 'C'
  structure_bias: string
  market_condition: string
  why_qualifies: string[]
  status: 'pending' | 'active' | 'triggered' | 'stopped' | 'target_hit' | 'invalidated'
}

export interface NotificationPayload {
  userId: string
  signalId: string
  channel: 'email' | 'sms' | 'push' | 'webhook'
  subject: string
  body: string
  recipient: string
}

// Market data provider interface
export interface MarketDataProvider {
  getName(): string
  getCandles(symbol: string, timeframe: string, limit?: number): Promise<OHLCV[]>
  getCurrentPrice(symbol: string): Promise<number>
  getSupportResistance(symbol: string, timeframe: string): Promise<SupportResistanceLevel[]>
  isMarketOpen(symbol: string): Promise<boolean>
}

// Setup detector interface
export interface SetupDetector {
  type: SetupType
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null
}
