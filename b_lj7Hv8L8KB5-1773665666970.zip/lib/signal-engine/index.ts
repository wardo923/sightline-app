// Signal Engine - Main Export

export * from './types'
export { SignalEngine, signalEngine } from './engine'
export { NotificationService, notificationService } from './notifications'
export { MarketDataAdapter, marketDataAdapter } from './market-data/adapter'
export { StockMarketDataProvider, stockProvider } from './market-data/stock-provider'
export { CryptoMarketDataProvider, cryptoProvider } from './market-data/crypto-provider'
export { detectors, getDetector, getDetectorsForPreference } from './detectors'
