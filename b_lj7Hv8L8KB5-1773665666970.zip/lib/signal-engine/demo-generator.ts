// SightLine V1 Demo Signal Generator
// Conservative V1: Fewer, cleaner signals that feel believable and well-filtered

import { SetupQuality, isLiquidStockSession } from './v1-scoring'
import { STRATEGY_INFO } from '@/lib/strategies'
import { StrategyBundle } from '@/types/strategy'

export interface DemoSignal {
  symbol: string
  timeframe: string
  direction: 'BUY' | 'SELL'
  setup_type: string
  setup_quality: SetupQuality
  entry_price: number
  stop_loss: number
  target_1: number
  target_2: number
  risk_reward: string
  watch_level: number
  v1_score: number
  reasons: string[]
  market_condition: string
  grade: string
  suppressed?: boolean
  suppressReason?: string
}

// Realistic price data for demo
const ASSET_DATA: Record<string, { price: number; atr: number; type: 'stock' | 'crypto' }> = {
  SPY: { price: 592.45, atr: 3.20, type: 'stock' },
  QQQ: { price: 518.32, atr: 4.15, type: 'stock' },
  NVDA: { price: 142.78, atr: 5.40, type: 'stock' },
  BTC: { price: 97845.00, atr: 1850.00, type: 'crypto' },
  ETH: { price: 3542.00, atr: 95.00, type: 'crypto' },
}

// V1 Conservative: Condition requirements by framework
// Each framework has REQUIRED conditions that must be met
const FRAMEWORK_REQUIREMENTS: Record<StrategyBundle, {
  required: string[]
  optional: string[]
  minScore: number
}> = {
  MOMENTUM_BREAKOUT: {
    required: ['Structure break at key level', 'Retest confirmation'],
    optional: ['Higher timeframe trend aligned', 'Momentum expansion detected', 'Volume above average', 'Active liquidity session', 'Compression detected before breakout', 'Room to next structure verified'],
    minScore: 5,
  },
  LIQUIDITY_REVERSAL: {
    required: ['Liquidity sweep completed', 'Reclaim of previous level'],
    optional: ['Momentum shift confirmed', 'Volume expansion on reclaim', 'Higher timeframe not opposing', 'Active liquidity session'],
    minScore: 5,
  },
  STRUCTURE_REACTION: {
    required: ['Key level tested', 'Clear rejection pattern'],
    optional: ['Momentum shift away from level', 'Higher timeframe context supports', 'Level respected previously', 'Active liquidity session', 'Volume confirmation'],
    minScore: 5,
  },
  OPENING_RANGE: {
    required: ['Opening range established', 'Range break confirmed'],
    optional: ['Volume supports the move', 'Momentum follow-through', 'Higher timeframe not opposing', 'Active morning session'],
    minScore: 4,
  },
  VOLATILITY_EXPANSION: {
    required: ['Breakout from consolidation', 'Compression detected before breakout'],
    optional: ['Range expansion detected', 'Strong momentum', 'Volume confirms expansion', 'Room to next structure verified', 'Active liquidity session'],
    minScore: 5,
  },
  SESSION_STRUCTURE: {
    required: ['Session level interaction', 'Clear acceptance or rejection'],
    optional: ['Momentum confirms direction', 'Higher timeframe aligned', 'Active liquidity session', 'Volume confirmation'],
    minScore: 4,
  },
}

// Market condition descriptions by asset type
const STOCK_CONDITIONS = [
  'Trending with institutional flow',
  'Range-bound with breakout potential',
  'Strong directional bias',
  'Consolidating near key level',
]

const CRYPTO_CONDITIONS = [
  'Volatile with directional bias',
  'High volume expansion phase',
  'Liquidity grab followed by reversal',
  'Session structure forming',
]

function getRandomElement<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)]
}

function generateRiskReward(entry: number, stop: number, target: number): string {
  const risk = Math.abs(entry - stop)
  const reward = Math.abs(target - entry)
  const rr = (reward / risk).toFixed(1)
  return `1:${rr}`
}

function qualityToGrade(quality: SetupQuality): string {
  return quality === 'Elite' ? 'A' : quality === 'Strong' ? 'B' : 'C'
}

// V1: Score based on actual conditions met
function calculateV1Score(conditions: string[]): number {
  let score = 0
  
  // Core conditions worth 2 points each
  if (conditions.some(c => c.includes('Structure') || c.includes('level'))) score += 2
  if (conditions.some(c => c.includes('Retest') || c.includes('Reclaim') || c.includes('rejection'))) score += 2
  
  // Secondary conditions worth 1 point each
  if (conditions.some(c => c.includes('Higher timeframe'))) score += 1
  if (conditions.some(c => c.includes('Momentum'))) score += 1
  if (conditions.some(c => c.includes('Volume'))) score += 1
  if (conditions.some(c => c.includes('liquidity') || c.includes('session'))) score += 1
  if (conditions.some(c => c.includes('Compression'))) score += 1
  
  return Math.min(score, 9) // Cap at max score
}

function determineQuality(score: number): SetupQuality {
  if (score >= 7) return 'Elite'
  if (score >= 5) return 'Strong'
  if (score >= 4) return 'Developing'
  return 'NoAlert'
}

// V1 Conservative: Check if signal should be suppressed
function shouldSuppressSignal(
  asset: { type: 'stock' | 'crypto' },
  framework: StrategyBundle,
  extensionRatio: number
): { suppress: boolean; reason?: string } {
  
  // 1. Stock midday suppression (unless very strong setup)
  if (asset.type === 'stock' && !isLiquidStockSession()) {
    // 70% chance to suppress midday stock signals
    if (Math.random() < 0.7) {
      return { suppress: true, reason: 'Weak midday liquidity period' }
    }
  }
  
  // 2. Exhausted breakout suppression for momentum frameworks
  const momentumFrameworks: StrategyBundle[] = ['MOMENTUM_BREAKOUT', 'VOLATILITY_EXPANSION', 'OPENING_RANGE']
  if (momentumFrameworks.includes(framework)) {
    if (extensionRatio >= 2.5) {
      return { suppress: true, reason: 'Move already extended beyond entry zone' }
    }
    if (extensionRatio >= 1.8 && Math.random() < 0.6) {
      return { suppress: true, reason: 'Extended move - waiting for retest' }
    }
  }
  
  return { suppress: false }
}

export function generateDemoSignal(
  symbol: string,
  framework: StrategyBundle,
  forcedQuality?: SetupQuality,
  direction?: 'BUY' | 'SELL'
): DemoSignal {
  const asset = ASSET_DATA[symbol] || ASSET_DATA.SPY
  const dir = direction || (Math.random() > 0.5 ? 'BUY' : 'SELL')
  const requirements = FRAMEWORK_REQUIREMENTS[framework]
  
  // Calculate realistic prices based on direction
  const entryOffset = (Math.random() * 0.002) * asset.price
  const entry = asset.price + (dir === 'BUY' ? entryOffset : -entryOffset)
  
  // Stop loss: 0.5-1 ATR away
  const stopDistance = asset.atr * (0.5 + Math.random() * 0.5)
  const stop = dir === 'BUY' ? entry - stopDistance : entry + stopDistance
  
  // Targets: 1.5-2 ATR and 2.5-3.5 ATR
  const target1Distance = asset.atr * (1.5 + Math.random() * 0.5)
  const target2Distance = asset.atr * (2.5 + Math.random() * 1)
  const target1 = dir === 'BUY' ? entry + target1Distance : entry - target1Distance
  const target2 = dir === 'BUY' ? entry + target2Distance : entry - target2Distance
  
  // Watch level: the key structure level
  const watchLevel = dir === 'BUY' 
    ? entry - asset.atr * 0.3 
    : entry + asset.atr * 0.3
  
  // V1 Conservative: Build conditions based on requirements
  const conditions: string[] = [...requirements.required]
  
  // Add optional conditions probabilistically
  for (const optional of requirements.optional) {
    // Higher bar for optional conditions
    if (Math.random() < 0.5) {
      conditions.push(optional)
    }
  }
  
  // Calculate actual score and quality
  const v1Score = calculateV1Score(conditions)
  const calculatedQuality = forcedQuality || determineQuality(v1Score)
  
  // Check for suppression
  const extensionRatio = Math.random() * 3 // Simulate random extension
  const suppression = shouldSuppressSignal(asset, framework, extensionRatio)
  
  // Timeframe based on asset type
  const timeframes = asset.type === 'stock' 
    ? ['5m', '15m', '1h'] 
    : ['15m', '1h', '4h']
  const timeframe = getRandomElement(timeframes)
  
  // Market conditions by type
  const marketConditions = asset.type === 'stock' ? STOCK_CONDITIONS : CRYPTO_CONDITIONS
  
  return {
    symbol,
    timeframe,
    direction: dir,
    setup_type: framework,
    setup_quality: suppression.suppress ? 'NoAlert' : calculatedQuality,
    entry_price: Number(entry.toFixed(symbol.includes('BTC') ? 0 : 2)),
    stop_loss: Number(stop.toFixed(symbol.includes('BTC') ? 0 : 2)),
    target_1: Number(target1.toFixed(symbol.includes('BTC') ? 0 : 2)),
    target_2: Number(target2.toFixed(symbol.includes('BTC') ? 0 : 2)),
    risk_reward: generateRiskReward(entry, stop, target1),
    watch_level: Number(watchLevel.toFixed(symbol.includes('BTC') ? 0 : 2)),
    v1_score: suppression.suppress ? 0 : v1Score,
    reasons: suppression.suppress ? [suppression.reason || 'Conditions not met'] : conditions,
    market_condition: getRandomElement(marketConditions),
    grade: suppression.suppress ? 'N' : qualityToGrade(calculatedQuality),
    suppressed: suppression.suppress,
    suppressReason: suppression.reason,
  }
}

// V1 Conservative: Generate batch with realistic distribution
// Target: 10% Elite, 35% Strong, 25% Developing, 30% Suppressed/NoAlert
export function generateDemoSignalBatch(
  assets: string[],
  framework: StrategyBundle,
  count: number = 1
): DemoSignal[] {
  const signals: DemoSignal[] = []
  
  for (const asset of assets) {
    for (let i = 0; i < count; i++) {
      const signal = generateDemoSignal(asset, framework)
      // Only include signals that pass the filter
      if (signal.setup_quality !== 'NoAlert') {
        signals.push(signal)
      }
    }
  }
  
  return signals
}

// Generate signals across all frameworks for a single asset
export function generateAssetSignals(
  asset: string,
  frameworks: StrategyBundle[]
): DemoSignal[] {
  const signals: DemoSignal[] = []
  
  for (const framework of frameworks) {
    const signal = generateDemoSignal(asset, framework)
    if (signal.setup_quality !== 'NoAlert') {
      signals.push(signal)
    }
  }
  
  return signals
}

// Get best framework for asset (unchanged)
export function getBestFrameworksForAsset(asset: string): StrategyBundle[] {
  const frameworks: StrategyBundle[] = []
  
  for (const [key, info] of Object.entries(STRATEGY_INFO)) {
    if (info.bestFor.includes(asset)) {
      frameworks.push(key as StrategyBundle)
    }
  }
  
  return frameworks.length > 0 ? frameworks : ['MOMENTUM_BREAKOUT', 'STRUCTURE_REACTION']
}

// V1: Generate preview signals showing both passed and suppressed
export function generatePreviewSignals(
  asset: string,
  framework: StrategyBundle,
  count: number = 5
): { passed: DemoSignal[]; suppressed: DemoSignal[] } {
  const passed: DemoSignal[] = []
  const suppressed: DemoSignal[] = []
  
  for (let i = 0; i < count; i++) {
    const signal = generateDemoSignal(asset, framework)
    if (signal.suppressed) {
      suppressed.push(signal)
    } else if (signal.setup_quality !== 'NoAlert') {
      passed.push(signal)
    }
  }
  
  return { passed, suppressed }
}
