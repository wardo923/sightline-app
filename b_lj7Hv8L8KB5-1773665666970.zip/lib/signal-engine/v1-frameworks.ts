// SightLine V1 Framework Rules
// Conservative detection logic for each strategy bundle

import {
  ConditionScore,
  calculateSetupScore,
  SetupScoreResult,
  getHigherTimeframe,
  isLiquidStockSession,
  hasRoomToNextLevel,
  hasVolumeConfirmation,
  hasMomentumExpansion,
  hasRetestConfirmation,
  AlertOutput,
  formatAlertOutput,
} from './v1-scoring'
import { OHLCV, MarketData, SupportResistanceLevel, TrendAnalysis, AssetClass, getAssetClass } from './types'

// Helper: Calculate ATR
function getATR(candles: OHLCV[], period: number = 14): number {
  if (candles.length < period + 1) return candles[0].high - candles[0].low
  let atr = 0
  for (let i = candles.length - period; i < candles.length; i++) {
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    )
    atr += tr
  }
  return atr / period
}

// Helper: Get recent candle ranges
function getRecentRanges(candles: OHLCV[], count: number = 10): number[] {
  return candles.slice(-count).map(c => c.high - c.low)
}

// Helper: Get recent volumes
function getRecentVolumes(candles: OHLCV[], count: number = 10): number[] {
  return candles.slice(-count).map(c => c.volume)
}

export interface FrameworkResult {
  triggered: boolean
  direction: 'BUY' | 'SELL'
  scoreResult: SetupScoreResult
  alertOutput: AlertOutput | null
  suppressReason?: string
}

// ============================================
// MOMENTUM BREAKOUT FRAMEWORK
// ============================================
export function evaluateMomentumBreakout(
  marketData: MarketData,
  levels: SupportResistanceLevel[],
  trend: TrendAnalysis,
  htfTrend: TrendAnalysis,
  userAlertWindow: string
): FrameworkResult | null {
  const { candles, currentPrice, symbol } = marketData
  const assetClass = getAssetClass(symbol)
  const atr = getATR(candles)
  const currentCandle = candles[candles.length - 1]
  const prevCandle = candles[candles.length - 2]
  
  // Find resistance breakout
  const resistance = levels.find(l =>
    l.type === 'resistance' &&
    l.strength >= 2 &&
    currentPrice > l.price &&
    prevCandle.close <= l.price
  )
  
  // Find support breakdown
  const support = levels.find(l =>
    l.type === 'support' &&
    l.strength >= 2 &&
    currentPrice < l.price &&
    prevCandle.close >= l.price
  )
  
  const breakoutLevel = resistance || support
  const direction: 'BUY' | 'SELL' = resistance ? 'BUY' : 'SELL'
  
  if (!breakoutLevel) return null
  
  // SUPPRESSION CHECKS
  
  // Check if breakout immediately rejected
  if (direction === 'BUY' && currentCandle.close < breakoutLevel.price) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Breakout immediately rejected' }
  }
  if (direction === 'SELL' && currentCandle.close > breakoutLevel.price) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Breakdown immediately rejected' }
  }
  
  // Check room to next structure
  const roomCheck = hasRoomToNextLevel(currentPrice, direction, levels, atr)
  if (!roomCheck.hasRoom) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Breaking into nearby structure - insufficient room' }
  }
  
  // EVALUATE CONDITIONS
  const conditions: ConditionScore = {
    htfAligned: direction === 'BUY' ? htfTrend.direction === 'bullish' : htfTrend.direction === 'bearish',
    structureMet: breakoutLevel.strength >= 2 && breakoutLevel.touches >= 2,
    retestConfirmed: hasRetestConfirmation(candles, breakoutLevel.price, direction) ||
      // OR decisive breakout candle with strong expansion
      (Math.abs(currentCandle.close - currentCandle.open) > atr * 0.5),
    momentumExpanding: hasMomentumExpansion(currentCandle.high - currentCandle.low, getRecentRanges(candles)),
    volumeConfirmed: hasVolumeConfirmation(currentCandle.volume, getRecentVolumes(candles)),
    sessionLiquid: assetClass === 'crypto' ? true : isLiquidStockSession(),
  }
  
  const scoreResult = calculateSetupScore(conditions)
  
  if (!scoreResult.shouldAlert) {
    return { triggered: false, direction, scoreResult, alertOutput: null, suppressReason: `Score ${scoreResult.score}/8 below threshold` }
  }
  
  // Generate alert output
  const entry = currentPrice
  const stop = direction === 'BUY' ? breakoutLevel.price - atr * 0.5 : breakoutLevel.price + atr * 0.5
  const target1 = direction === 'BUY' ? entry + atr * 2 : entry - atr * 2
  const target2 = direction === 'BUY' ? entry + atr * 3.5 : entry - atr * 3.5
  
  const alertOutput = formatAlertOutput(
    scoreResult.quality,
    scoreResult.whyConditions,
    breakoutLevel.price,
    entry,
    stop,
    target1,
    target2,
    atr
  )
  
  return { triggered: true, direction, scoreResult, alertOutput }
}

// ============================================
// OPENING RANGE FRAMEWORK
// ============================================
export function evaluateOpeningRange(
  marketData: MarketData,
  levels: SupportResistanceLevel[],
  trend: TrendAnalysis,
  htfTrend: TrendAnalysis,
  openingRangeHigh: number,
  openingRangeLow: number,
  userAlertWindow: string
): FrameworkResult | null {
  const { candles, currentPrice, symbol } = marketData
  const assetClass = getAssetClass(symbol)
  const atr = getATR(candles)
  const currentCandle = candles[candles.length - 1]
  
  // Check if opening range is established (need range values)
  if (!openingRangeHigh || !openingRangeLow) return null
  
  const brokeHigh = currentPrice > openingRangeHigh
  const brokeLow = currentPrice < openingRangeLow
  
  if (!brokeHigh && !brokeLow) return null
  
  const direction: 'BUY' | 'SELL' = brokeHigh ? 'BUY' : 'SELL'
  
  // SUPPRESSION CHECKS
  
  // Check if price broke and immediately returned inside
  const prevCandles = candles.slice(-3, -1)
  const justBroke = prevCandles.every(c => 
    c.close >= openingRangeLow && c.close <= openingRangeHigh
  )
  if (!justBroke) {
    // Price was already outside, this is late
  }
  
  // Check if break occurred very late in session (for stocks)
  if (assetClass === 'stock') {
    const now = new Date()
    const etHour = now.getUTCHours() - 5
    if (etHour >= 15) {
      return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Break too late in session' }
    }
  }
  
  // EVALUATE CONDITIONS
  const conditions: ConditionScore = {
    htfAligned: direction === 'BUY' ? htfTrend.direction !== 'bearish' : htfTrend.direction !== 'bullish',
    structureMet: true, // Opening range is a defined structure
    retestConfirmed: false, // Opening range breaks don't require retest
    momentumExpanding: hasMomentumExpansion(currentCandle.high - currentCandle.low, getRecentRanges(candles)),
    volumeConfirmed: hasVolumeConfirmation(currentCandle.volume, getRecentVolumes(candles)),
    sessionLiquid: assetClass === 'crypto' ? true : isLiquidStockSession(),
  }
  
  const scoreResult = calculateSetupScore(conditions)
  
  if (!scoreResult.shouldAlert) {
    return { triggered: false, direction, scoreResult, alertOutput: null, suppressReason: `Score ${scoreResult.score}/8 below threshold` }
  }
  
  const entry = currentPrice
  const stop = direction === 'BUY' ? openingRangeLow - atr * 0.2 : openingRangeHigh + atr * 0.2
  const target1 = direction === 'BUY' ? entry + atr * 1.5 : entry - atr * 1.5
  const target2 = direction === 'BUY' ? entry + atr * 2.5 : entry - atr * 2.5
  
  const alertOutput = formatAlertOutput(
    scoreResult.quality,
    scoreResult.whyConditions,
    direction === 'BUY' ? openingRangeHigh : openingRangeLow,
    entry,
    stop,
    target1,
    target2,
    atr
  )
  
  return { triggered: true, direction, scoreResult, alertOutput }
}

// ============================================
// STRUCTURE REACTION FRAMEWORK
// ============================================
export function evaluateStructureReaction(
  marketData: MarketData,
  levels: SupportResistanceLevel[],
  trend: TrendAnalysis,
  htfTrend: TrendAnalysis,
  userAlertWindow: string
): FrameworkResult | null {
  const { candles, currentPrice, symbol } = marketData
  const assetClass = getAssetClass(symbol)
  const atr = getATR(candles)
  const currentCandle = candles[candles.length - 1]
  const recentCandles = candles.slice(-5)
  
  // Find meaningful support/resistance level being tested
  const testedLevel = levels.find(l =>
    l.strength >= 3 && // Must be strong level
    l.touches >= 2 &&  // Must have been respected previously
    Math.abs(currentPrice - l.price) / l.price < 0.01 // Within 1%
  )
  
  if (!testedLevel) return null
  
  // Check for rejection or acceptance
  const isSupport = testedLevel.type === 'support'
  const touchedLevel = recentCandles.some(c => 
    isSupport ? c.low <= testedLevel.price * 1.005 : c.high >= testedLevel.price * 0.995
  )
  
  if (!touchedLevel) return null
  
  // Check momentum shift away from level
  const momentum = isSupport
    ? currentCandle.close > currentCandle.open && currentCandle.close > recentCandles[0].close
    : currentCandle.close < currentCandle.open && currentCandle.close < recentCandles[0].close
  
  if (!momentum) {
    return { triggered: false, direction: isSupport ? 'BUY' : 'SELL', scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'No momentum shift detected' }
  }
  
  const direction: 'BUY' | 'SELL' = isSupport ? 'BUY' : 'SELL'
  
  // EVALUATE CONDITIONS
  const conditions: ConditionScore = {
    htfAligned: direction === 'BUY' ? htfTrend.direction !== 'bearish' : htfTrend.direction !== 'bullish',
    structureMet: testedLevel.strength >= 3 && testedLevel.touches >= 2,
    retestConfirmed: true, // This IS a retest/reaction
    momentumExpanding: hasMomentumExpansion(currentCandle.high - currentCandle.low, getRecentRanges(candles), 1.1),
    volumeConfirmed: hasVolumeConfirmation(currentCandle.volume, getRecentVolumes(candles), 1.1),
    sessionLiquid: assetClass === 'crypto' ? true : isLiquidStockSession(),
  }
  
  const scoreResult = calculateSetupScore(conditions)
  
  if (!scoreResult.shouldAlert) {
    return { triggered: false, direction, scoreResult, alertOutput: null, suppressReason: `Score ${scoreResult.score}/8 below threshold` }
  }
  
  const entry = currentPrice
  const stop = isSupport ? testedLevel.price - atr * 0.3 : testedLevel.price + atr * 0.3
  const target1 = isSupport ? entry + atr * 2 : entry - atr * 2
  const target2 = isSupport ? entry + atr * 3 : entry - atr * 3
  
  const alertOutput = formatAlertOutput(
    scoreResult.quality,
    scoreResult.whyConditions,
    testedLevel.price,
    entry,
    stop,
    target1,
    target2,
    atr
  )
  
  return { triggered: true, direction, scoreResult, alertOutput }
}

// ============================================
// LIQUIDITY REVERSAL FRAMEWORK
// ============================================
export function evaluateLiquidityReversal(
  marketData: MarketData,
  levels: SupportResistanceLevel[],
  trend: TrendAnalysis,
  htfTrend: TrendAnalysis,
  userAlertWindow: string
): FrameworkResult | null {
  const { candles, currentPrice, symbol } = marketData
  const assetClass = getAssetClass(symbol)
  const atr = getATR(candles)
  const currentCandle = candles[candles.length - 1]
  const recentCandles = candles.slice(-10)
  
  // Find recent highs/lows that could be liquidity zones
  const recentHigh = Math.max(...recentCandles.slice(0, -2).map(c => c.high))
  const recentLow = Math.min(...recentCandles.slice(0, -2).map(c => c.low))
  
  // Check for sweep and reclaim
  const sweptHigh = currentCandle.high > recentHigh && currentCandle.close < recentHigh
  const sweptLow = currentCandle.low < recentLow && currentCandle.close > recentLow
  
  if (!sweptHigh && !sweptLow) return null
  
  const direction: 'BUY' | 'SELL' = sweptLow ? 'BUY' : 'SELL'
  const sweepLevel = sweptLow ? recentLow : recentHigh
  
  // Check for quick reclaim (within same or next candle)
  const reclaimed = sweptLow
    ? currentCandle.close > recentLow
    : currentCandle.close < recentHigh
  
  if (!reclaimed) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Sweep without reclaim' }
  }
  
  // Check reversal candle strength
  const candleStrength = Math.abs(currentCandle.close - currentCandle.open) / atr
  if (candleStrength < 0.3) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Reversal candle too weak' }
  }
  
  // EVALUATE CONDITIONS
  const conditions: ConditionScore = {
    htfAligned: htfTrend.direction !== (direction === 'BUY' ? 'bearish' : 'bullish'),
    structureMet: true, // Liquidity zone is structure
    retestConfirmed: true, // The reclaim IS confirmation
    momentumExpanding: hasMomentumExpansion(currentCandle.high - currentCandle.low, getRecentRanges(candles)),
    volumeConfirmed: hasVolumeConfirmation(currentCandle.volume, getRecentVolumes(candles)),
    sessionLiquid: assetClass === 'crypto' ? true : isLiquidStockSession(),
  }
  
  const scoreResult = calculateSetupScore(conditions)
  
  if (!scoreResult.shouldAlert) {
    return { triggered: false, direction, scoreResult, alertOutput: null, suppressReason: `Score ${scoreResult.score}/8 below threshold` }
  }
  
  const entry = currentPrice
  const stop = sweptLow ? recentLow - atr * 0.3 : recentHigh + atr * 0.3
  const target1 = sweptLow ? entry + atr * 2 : entry - atr * 2
  const target2 = sweptLow ? entry + atr * 3.5 : entry - atr * 3.5
  
  const alertOutput = formatAlertOutput(
    scoreResult.quality,
    scoreResult.whyConditions,
    sweepLevel,
    entry,
    stop,
    target1,
    target2,
    atr
  )
  
  return { triggered: true, direction, scoreResult, alertOutput }
}

// ============================================
// VOLATILITY EXPANSION FRAMEWORK
// ============================================
export function evaluateVolatilityExpansion(
  marketData: MarketData,
  levels: SupportResistanceLevel[],
  trend: TrendAnalysis,
  htfTrend: TrendAnalysis,
  userAlertWindow: string
): FrameworkResult | null {
  const { candles, currentPrice, symbol } = marketData
  const assetClass = getAssetClass(symbol)
  const atr = getATR(candles)
  const currentCandle = candles[candles.length - 1]
  
  // Check for consolidation/compression before expansion
  const recentRanges = getRecentRanges(candles, 10)
  const avgRange = recentRanges.reduce((sum, r) => sum + r, 0) / recentRanges.length
  const currentRange = currentCandle.high - currentCandle.low
  
  // Require significant expansion
  if (currentRange < avgRange * 1.5) return null
  
  const direction: 'BUY' | 'SELL' = currentCandle.close > currentCandle.open ? 'BUY' : 'SELL'
  
  // Check room to next structure
  const roomCheck = hasRoomToNextLevel(currentPrice, direction, levels, atr)
  if (!roomCheck.hasRoom) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Expansion into nearby structure' }
  }
  
  // Check if move appears exhausted (long wick in direction of move)
  const bodySize = Math.abs(currentCandle.close - currentCandle.open)
  const upperWick = currentCandle.high - Math.max(currentCandle.close, currentCandle.open)
  const lowerWick = Math.min(currentCandle.close, currentCandle.open) - currentCandle.low
  
  if (direction === 'BUY' && upperWick > bodySize * 0.5) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Move appears exhausted (upper wick)' }
  }
  if (direction === 'SELL' && lowerWick > bodySize * 0.5) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Move appears exhausted (lower wick)' }
  }
  
  // EVALUATE CONDITIONS
  const conditions: ConditionScore = {
    htfAligned: direction === 'BUY' ? htfTrend.direction === 'bullish' : htfTrend.direction === 'bearish',
    structureMet: true, // Breaking from consolidation is structure
    retestConfirmed: false, // Volatility expansion doesn't require retest
    momentumExpanding: true, // This is the expansion itself
    volumeConfirmed: hasVolumeConfirmation(currentCandle.volume, getRecentVolumes(candles)),
    sessionLiquid: assetClass === 'crypto' ? true : isLiquidStockSession(),
  }
  
  const scoreResult = calculateSetupScore(conditions)
  
  if (!scoreResult.shouldAlert) {
    return { triggered: false, direction, scoreResult, alertOutput: null, suppressReason: `Score ${scoreResult.score}/8 below threshold` }
  }
  
  const entry = currentPrice
  const stop = direction === 'BUY' ? currentCandle.low - atr * 0.2 : currentCandle.high + atr * 0.2
  const target1 = direction === 'BUY' ? entry + atr * 1.5 : entry - atr * 1.5
  const target2 = direction === 'BUY' ? entry + atr * 2.5 : entry - atr * 2.5
  
  const alertOutput = formatAlertOutput(
    scoreResult.quality,
    scoreResult.whyConditions,
    direction === 'BUY' ? currentCandle.low : currentCandle.high,
    entry,
    stop,
    target1,
    target2,
    atr
  )
  
  return { triggered: true, direction, scoreResult, alertOutput }
}

// ============================================
// SESSION STRUCTURE FRAMEWORK
// ============================================
export function evaluateSessionStructure(
  marketData: MarketData,
  levels: SupportResistanceLevel[],
  trend: TrendAnalysis,
  htfTrend: TrendAnalysis,
  sessionHigh: number,
  sessionLow: number,
  vwap: number,
  userAlertWindow: string
): FrameworkResult | null {
  const { candles, currentPrice, symbol } = marketData
  const assetClass = getAssetClass(symbol)
  const atr = getATR(candles)
  const currentCandle = candles[candles.length - 1]
  const recentCandles = candles.slice(-5)
  
  // Check interaction with session levels
  const nearSessionHigh = Math.abs(currentPrice - sessionHigh) / sessionHigh < 0.005
  const nearSessionLow = Math.abs(currentPrice - sessionLow) / sessionLow < 0.005
  const nearVWAP = Math.abs(currentPrice - vwap) / vwap < 0.003
  
  if (!nearSessionHigh && !nearSessionLow && !nearVWAP) return null
  
  // Determine which level and direction
  let level: number
  let direction: 'BUY' | 'SELL'
  
  if (nearSessionHigh) {
    level = sessionHigh
    // Check for rejection (sell) or acceptance (buy)
    const rejecting = currentCandle.close < currentCandle.open && currentCandle.close < sessionHigh
    direction = rejecting ? 'SELL' : 'BUY'
  } else if (nearSessionLow) {
    level = sessionLow
    const bouncing = currentCandle.close > currentCandle.open && currentCandle.close > sessionLow
    direction = bouncing ? 'BUY' : 'SELL'
  } else {
    level = vwap
    const aboveVWAP = currentPrice > vwap
    direction = aboveVWAP ? 'BUY' : 'SELL'
  }
  
  // Check for clear acceptance/rejection (not drifting)
  const hasReaction = Math.abs(currentCandle.close - currentCandle.open) > atr * 0.3
  if (!hasReaction) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Price drifting without reaction' }
  }
  
  // Check session liquidity
  if (assetClass === 'stock' && !isLiquidStockSession()) {
    return { triggered: false, direction, scoreResult: emptyScoreResult(), alertOutput: null, suppressReason: 'Low liquidity session' }
  }
  
  // EVALUATE CONDITIONS
  const conditions: ConditionScore = {
    htfAligned: htfTrend.direction !== (direction === 'BUY' ? 'bearish' : 'bullish'),
    structureMet: true, // Session level is structure
    retestConfirmed: true, // Interaction with session level
    momentumExpanding: hasMomentumExpansion(currentCandle.high - currentCandle.low, getRecentRanges(candles), 1.1),
    volumeConfirmed: hasVolumeConfirmation(currentCandle.volume, getRecentVolumes(candles), 1.1),
    sessionLiquid: assetClass === 'crypto' ? true : isLiquidStockSession(),
  }
  
  const scoreResult = calculateSetupScore(conditions)
  
  if (!scoreResult.shouldAlert) {
    return { triggered: false, direction, scoreResult, alertOutput: null, suppressReason: `Score ${scoreResult.score}/8 below threshold` }
  }
  
  const entry = currentPrice
  const stop = direction === 'BUY' ? level - atr * 0.3 : level + atr * 0.3
  const target1 = direction === 'BUY' ? entry + atr * 1.5 : entry - atr * 1.5
  const target2 = direction === 'BUY' ? entry + atr * 2.5 : entry - atr * 2.5
  
  const alertOutput = formatAlertOutput(
    scoreResult.quality,
    scoreResult.whyConditions,
    level,
    entry,
    stop,
    target1,
    target2,
    atr
  )
  
  return { triggered: true, direction, scoreResult, alertOutput }
}

// Helper to create empty score result
function emptyScoreResult(): SetupScoreResult {
  return {
    score: 0,
    quality: 'NoAlert',
    conditions: {
      htfAligned: false,
      structureMet: false,
      retestConfirmed: false,
      momentumExpanding: false,
      volumeConfirmed: false,
      sessionLiquid: false,
    },
    whyConditions: [],
    shouldAlert: false,
  }
}
