// SightLine V1 Conservative Scoring System
// Designed to prioritize high-quality setups over frequent alerts

export type SetupQuality = 'Elite' | 'Strong' | 'Developing' | 'NoAlert'

export interface ConditionScore {
  htfAligned: boolean       // Higher timeframe bias aligned (1 point)
  structureMet: boolean     // Structure condition met (2 points)
  retestConfirmed: boolean  // Retest or reclaim confirmed (2 points)
  momentumExpanding: boolean // Momentum expansion (1 point)
  volumeConfirmed: boolean  // Volume confirmation (1 point)
  sessionLiquid: boolean    // Session liquidity valid (1 point)
  compressionDetected: boolean // Compression before expansion (1 point)
}

export interface SetupScoreResult {
  score: number
  quality: SetupQuality
  conditions: ConditionScore
  whyConditions: string[]
  shouldAlert: boolean
}

// Scoring weights per condition
const CONDITION_WEIGHTS = {
  htfAligned: 1,
  structureMet: 2,
  retestConfirmed: 2,
  momentumExpanding: 1,
  volumeConfirmed: 1,
  sessionLiquid: 1,
  compressionDetected: 1,
}

// Maximum possible score = 9
const MAX_SCORE = 9

// Quality thresholds
const QUALITY_THRESHOLDS = {
  elite: 7,      // 7-9 = Elite Setup
  strong: 5,     // 5-6 = Strong Setup
  developing: 4, // 4 = Developing Setup
  // Below 4 = No alert
}

/**
 * Calculate setup score from conditions
 */
export function calculateSetupScore(conditions: ConditionScore): SetupScoreResult {
  let score = 0
  const whyConditions: string[] = []

  if (conditions.htfAligned) {
    score += CONDITION_WEIGHTS.htfAligned
    whyConditions.push('Higher timeframe aligned')
  }

  if (conditions.structureMet) {
    score += CONDITION_WEIGHTS.structureMet
    whyConditions.push('Structure condition met')
  }

  if (conditions.retestConfirmed) {
    score += CONDITION_WEIGHTS.retestConfirmed
    whyConditions.push('Retest confirmation')
  }

  if (conditions.momentumExpanding) {
    score += CONDITION_WEIGHTS.momentumExpanding
    whyConditions.push('Momentum expansion detected')
  }

  if (conditions.volumeConfirmed) {
    score += CONDITION_WEIGHTS.volumeConfirmed
    whyConditions.push('Volume above average')
  }

  if (conditions.sessionLiquid) {
    score += CONDITION_WEIGHTS.sessionLiquid
    whyConditions.push('Liquid session active')
  }

  // Compression only adds value when other structural conditions are met
  // It improves quality but doesn't trigger alerts by itself
  if (conditions.compressionDetected && conditions.structureMet) {
    score += CONDITION_WEIGHTS.compressionDetected
    whyConditions.push('Compression detected before expansion')
  }

  // Determine quality
  let quality: SetupQuality
  if (score >= QUALITY_THRESHOLDS.elite) {
    quality = 'Elite'
  } else if (score >= QUALITY_THRESHOLDS.strong) {
    quality = 'Strong'
  } else if (score >= QUALITY_THRESHOLDS.developing) {
    quality = 'Developing'
  } else {
    quality = 'NoAlert'
  }

  return {
    score,
    quality,
    conditions,
    whyConditions,
    shouldAlert: score >= QUALITY_THRESHOLDS.developing,
  }
}

/**
 * Get higher timeframe for bias check
 */
export function getHigherTimeframe(timeframe: string): string {
  const mapping: Record<string, string> = {
    '5m': '30m',
    '5 minute': '30m',
    '15m': '1h',
    '15 minute': '1h',
    '1h': '4h',
    '1 hour': '4h',
    '4h': 'D',
    '4 hour': 'D',
  }
  return mapping[timeframe] || '1h'
}

/**
 * Check if current time is within liquid session for stocks
 */
export function isLiquidStockSession(): boolean {
  const now = new Date()
  const etHour = now.getUTCHours() - 5 // Approximate ET offset
  const etMinute = now.getUTCMinutes()
  const etTime = etHour * 60 + etMinute

  // Morning session: 9:30-11:30 ET (570-690 minutes)
  const morningStart = 9 * 60 + 30
  const morningEnd = 11 * 60 + 30

  // Afternoon session: 14:00-16:00 ET (840-960 minutes)
  const afternoonStart = 14 * 60
  const afternoonEnd = 16 * 60

  return (etTime >= morningStart && etTime <= morningEnd) ||
         (etTime >= afternoonStart && etTime <= afternoonEnd)
}

/**
 * Check if there's room to next structure level
 */
export function hasRoomToNextLevel(
  currentPrice: number,
  direction: 'BUY' | 'SELL',
  levels: { price: number; type: 'support' | 'resistance' }[],
  atr: number
): { hasRoom: boolean; nextLevel: number | null; distance: number } {
  const minRoomATR = 1.5 // Require at least 1.5 ATR room

  if (direction === 'BUY') {
    // Find next resistance above current price
    const nextResistance = levels
      .filter(l => l.type === 'resistance' && l.price > currentPrice)
      .sort((a, b) => a.price - b.price)[0]

    if (!nextResistance) {
      return { hasRoom: true, nextLevel: null, distance: Infinity }
    }

    const distance = nextResistance.price - currentPrice
    return {
      hasRoom: distance >= atr * minRoomATR,
      nextLevel: nextResistance.price,
      distance,
    }
  } else {
    // Find next support below current price
    const nextSupport = levels
      .filter(l => l.type === 'support' && l.price < currentPrice)
      .sort((a, b) => b.price - a.price)[0]

    if (!nextSupport) {
      return { hasRoom: true, nextLevel: null, distance: Infinity }
    }

    const distance = currentPrice - nextSupport.price
    return {
      hasRoom: distance >= atr * minRoomATR,
      nextLevel: nextSupport.price,
      distance,
    }
  }
}

/**
 * Check volume confirmation against recent average
 */
export function hasVolumeConfirmation(
  currentVolume: number,
  recentVolumes: number[],
  threshold: number = 1.2
): boolean {
  if (recentVolumes.length === 0) return false
  const avgVolume = recentVolumes.reduce((sum, v) => sum + v, 0) / recentVolumes.length
  return currentVolume >= avgVolume * threshold
}

/**
 * Check momentum expansion (range exceeds recent average)
 */
export function hasMomentumExpansion(
  currentRange: number,
  recentRanges: number[],
  threshold: number = 1.3
): boolean {
  if (recentRanges.length === 0) return false
  const avgRange = recentRanges.reduce((sum, r) => sum + r, 0) / recentRanges.length
  return currentRange >= avgRange * threshold
}

/**
 * Detect compression (volatility contraction before expansion)
 * Compression is identified when:
 * - Multiple candles have decreasing ranges
 * - Tight consolidation pattern
 * - Volatility is contracted compared to recent average
 */
export function hasCompressionDetected(
  candles: { high: number; low: number; open: number; close: number }[],
  lookback: number = 10,
  contractionThreshold: number = 0.6
): boolean {
  if (candles.length < lookback + 5) return false

  // Get recent candles for compression check (excluding last 2 for the breakout)
  const compressionCandles = candles.slice(-(lookback + 2), -2)
  const priorCandles = candles.slice(-(lookback + 12), -(lookback + 2))

  if (compressionCandles.length < lookback || priorCandles.length < 5) return false

  // Calculate ranges
  const compressionRanges = compressionCandles.map(c => c.high - c.low)
  const priorRanges = priorCandles.map(c => c.high - c.low)

  // Average ranges
  const avgCompressionRange = compressionRanges.reduce((sum, r) => sum + r, 0) / compressionRanges.length
  const avgPriorRange = priorRanges.reduce((sum, r) => sum + r, 0) / priorRanges.length

  // Check if compression range is significantly smaller than prior range
  const isContracted = avgCompressionRange <= avgPriorRange * contractionThreshold

  // Check for decreasing ranges (narrowing pattern)
  let decreasingCount = 0
  for (let i = 1; i < compressionRanges.length; i++) {
    if (compressionRanges[i] <= compressionRanges[i - 1]) {
      decreasingCount++
    }
  }
  const hasDecreasingRanges = decreasingCount >= compressionRanges.length * 0.5

  // Check for tight consolidation (price staying within a narrow band)
  const highs = compressionCandles.map(c => c.high)
  const lows = compressionCandles.map(c => c.low)
  const consolidationHigh = Math.max(...highs)
  const consolidationLow = Math.min(...lows)
  const consolidationRange = consolidationHigh - consolidationLow
  const avgPrice = (consolidationHigh + consolidationLow) / 2
  const isTightConsolidation = (consolidationRange / avgPrice) < 0.02 // Within 2% range

  // Compression detected if any two of the three conditions are met
  const conditionsMet = [isContracted, hasDecreasingRanges, isTightConsolidation].filter(Boolean).length
  return conditionsMet >= 2
}

/**
 * Check if price has retested/reclaimed a level
 */
export function hasRetestConfirmation(
  candles: { high: number; low: number; close: number }[],
  level: number,
  direction: 'BUY' | 'SELL',
  tolerance: number = 0.002
): boolean {
  if (candles.length < 3) return false

  const recentCandles = candles.slice(-5)
  const currentCandle = recentCandles[recentCandles.length - 1]

  if (direction === 'BUY') {
    // For bullish: price should have returned to level from above and bounced
    const touchedLevel = recentCandles.some(c => 
      c.low <= level * (1 + tolerance) && c.low >= level * (1 - tolerance)
    )
    const holdingAbove = currentCandle.close > level
    return touchedLevel && holdingAbove
  } else {
    // For bearish: price should have returned to level from below and rejected
    const touchedLevel = recentCandles.some(c => 
      c.high >= level * (1 - tolerance) && c.high <= level * (1 + tolerance)
    )
    const holdingBelow = currentCandle.close < level
    return touchedLevel && holdingBelow
  }
}

/**
 * Trend Exhaustion Filter
 * Prevents alerts from firing after a move is already extended
 * Applies to: Momentum Breakout, Volatility Expansion, Opening Range
 * 
 * Returns whether the move is exhausted and should be suppressed/downgraded
 */
export interface TrendExhaustionResult {
  isExhausted: boolean
  extensionRatio: number // How many ATRs extended from structure
  recentStructureLevel: number
  recommendation: 'suppress' | 'downgrade' | 'allow'
}

export function checkTrendExhaustion(
  currentPrice: number,
  direction: 'BUY' | 'SELL',
  recentConsolidationLevel: number,
  atr: number,
  exhaustionThreshold: number = 1.8
): TrendExhaustionResult {
  // Calculate distance from recent consolidation/structure
  const distance = direction === 'BUY' 
    ? currentPrice - recentConsolidationLevel
    : recentConsolidationLevel - currentPrice

  const extensionRatio = distance / atr

  // Determine if exhausted and recommendation
  let isExhausted = false
  let recommendation: 'suppress' | 'downgrade' | 'allow' = 'allow'

  if (extensionRatio >= exhaustionThreshold * 1.5) {
    // Severely extended (2.7+ ATR) - suppress entirely
    isExhausted = true
    recommendation = 'suppress'
  } else if (extensionRatio >= exhaustionThreshold) {
    // Extended (1.8+ ATR) - downgrade quality
    isExhausted = true
    recommendation = 'downgrade'
  }

  return {
    isExhausted,
    extensionRatio,
    recentStructureLevel: recentConsolidationLevel,
    recommendation,
  }
}

/**
 * Find recent consolidation/structure level from candles
 * Looks for areas where price consolidated before the current move
 */
export function findRecentConsolidation(
  candles: { high: number; low: number; open: number; close: number }[],
  lookback: number = 20
): { level: number; found: boolean } {
  if (candles.length < lookback) {
    return { level: 0, found: false }
  }

  const recentCandles = candles.slice(-lookback, -3) // Exclude last 3 candles (current move)
  
  if (recentCandles.length < 5) {
    return { level: 0, found: false }
  }

  // Calculate ranges to find low volatility periods (consolidation)
  const ranges = recentCandles.map(c => c.high - c.low)
  const avgRange = ranges.reduce((sum, r) => sum + r, 0) / ranges.length

  // Find candles with below-average range (consolidation candles)
  const consolidationCandles = recentCandles.filter((c, i) => ranges[i] < avgRange * 0.8)

  if (consolidationCandles.length < 3) {
    // No clear consolidation, use midpoint of recent range
    const highs = recentCandles.map(c => c.high)
    const lows = recentCandles.map(c => c.low)
    const midpoint = (Math.max(...highs) + Math.min(...lows)) / 2
    return { level: midpoint, found: true }
  }

  // Return the midpoint of consolidation zone
  const consolidationHighs = consolidationCandles.map(c => c.high)
  const consolidationLows = consolidationCandles.map(c => c.low)
  const consolidationMid = (Math.max(...consolidationHighs) + Math.min(...consolidationLows)) / 2

  return { level: consolidationMid, found: true }
}

/**
 * Apply trend exhaustion filter to setup score result
 * Only applies to momentum-based frameworks
 */
export function applyTrendExhaustionFilter(
  scoreResult: SetupScoreResult,
  exhaustionResult: TrendExhaustionResult,
  framework: string
): SetupScoreResult {
  // Only apply to momentum-based frameworks
  const momentumFrameworks = [
    'MOMENTUM_BREAKOUT',
    'VOLATILITY_EXPANSION', 
    'OPENING_RANGE'
  ]

  if (!momentumFrameworks.includes(framework)) {
    return scoreResult
  }

  if (!exhaustionResult.isExhausted) {
    return scoreResult
  }

  // Apply the recommendation
  if (exhaustionResult.recommendation === 'suppress') {
    return {
      ...scoreResult,
      quality: 'NoAlert',
      shouldAlert: false,
      whyConditions: [...scoreResult.whyConditions, `Move exhausted (${exhaustionResult.extensionRatio.toFixed(1)}x ATR extended)`],
    }
  }

  if (exhaustionResult.recommendation === 'downgrade') {
    // Downgrade quality by one level
    let downgradedQuality: SetupQuality = scoreResult.quality
    if (scoreResult.quality === 'Elite') {
      downgradedQuality = 'Strong'
    } else if (scoreResult.quality === 'Strong') {
      downgradedQuality = 'Developing'
    } else if (scoreResult.quality === 'Developing') {
      downgradedQuality = 'NoAlert'
    }

    return {
      ...scoreResult,
      quality: downgradedQuality,
      shouldAlert: downgradedQuality !== 'NoAlert',
      whyConditions: [...scoreResult.whyConditions, `Extended move (${exhaustionResult.extensionRatio.toFixed(1)}x ATR) - quality downgraded`],
    }
  }

  return scoreResult
}

/**
 * Generate alert output format
 */
export interface AlertOutput {
  setupQuality: SetupQuality
  whyAppeared: string[]
  watchLevel: number
  exampleEntryZone: { low: number; high: number }
  exampleInvalidation: number
  exampleTargetZone: { target1: number; target2: number }
}

export function formatAlertOutput(
  quality: SetupQuality,
  whyConditions: string[],
  watchLevel: number,
  entry: number,
  stop: number,
  target1: number,
  target2: number,
  atr: number
): AlertOutput {
  return {
    setupQuality: quality,
    whyAppeared: whyConditions,
    watchLevel: Number(watchLevel.toFixed(2)),
    exampleEntryZone: {
      low: Number(entry.toFixed(2)),
      high: Number((entry + atr * 0.3).toFixed(2)),
    },
    exampleInvalidation: Number(stop.toFixed(2)),
    exampleTargetZone: {
      target1: Number(target1.toFixed(2)),
      target2: Number(target2.toFixed(2)),
    },
  }
}
