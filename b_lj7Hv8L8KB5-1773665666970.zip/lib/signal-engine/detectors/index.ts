// Setup Detectors for all 6 supported setup types
// Each detector analyzes market data and returns a SetupDetectionResult if a valid setup is found

import {
  SetupDetector,
  SetupDetectionResult,
  SetupType,
  MarketData,
  SupportResistanceLevel,
  TrendAnalysis,
  UserStrategy,
  OHLCV
} from '../types'

// Helper functions
function calculateRiskReward(entry: number, stop: number, target: number): number {
  const risk = Math.abs(entry - stop)
  const reward = Math.abs(target - entry)
  return risk > 0 ? Number((reward / risk).toFixed(2)) : 0
}

function gradeSetup(confidence: number, rr: number, trendAlignment: boolean): 'A' | 'B' | 'C' {
  let score = confidence
  if (rr >= 3) score += 15
  else if (rr >= 2) score += 10
  if (trendAlignment) score += 10
  
  if (score >= 80) return 'A'
  if (score >= 60) return 'B'
  return 'C'
}

function findNearestLevel(
  levels: SupportResistanceLevel[],
  price: number,
  type: 'support' | 'resistance',
  tolerance: number
): SupportResistanceLevel | null {
  return levels
    .filter(l => l.type === type && Math.abs(l.price - price) / price < tolerance)
    .sort((a, b) => Math.abs(a.price - price) - Math.abs(b.price - price))[0] || null
}

function getATR(candles: OHLCV[], period: number = 14): number {
  if (candles.length < period + 1) return candles[0].high - candles[0].low
  
  let atr = 0
  for (let i = candles.length - period; i < candles.length; i++) {
    const tr = Math.max(
      candles[i].high - candles[i].low,
      Math.abs(candles[i].high - candles[i - 1].close),
      Math.abs(candles[i].low - candles[i - 1].close)
    )
    atr += tr
  }
  return atr / period
}

// ============================================
// BREAKOUT DETECTOR
// ============================================
class BreakoutDetector implements SetupDetector {
  type: SetupType = 'Breakout'
  
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null {
    const { candles, currentPrice } = marketData
    const atr = getATR(candles)
    const recentCandles = candles.slice(-5)
    const currentCandle = recentCandles[recentCandles.length - 1]
    
    // Look for resistance breakout (bullish)
    const resistance = levels.find(l => 
      l.type === 'resistance' && 
      l.strength >= 2 &&
      currentPrice > l.price &&
      candles[candles.length - 2].close <= l.price
    )
    
    if (resistance) {
      const entry = currentPrice
      const stop = resistance.price - (atr * 0.5)
      const target1 = entry + (atr * 2)
      const target2 = entry + (atr * 3.5)
      const rr = calculateRiskReward(entry, stop, target1)
      
      if (rr < 1.5) return null // Minimum R:R threshold
      
      const confidence = 60 + (resistance.strength * 5) + (currentCandle.volume > candles[candles.length - 2].volume ? 10 : 0)
      const trendAligned = trend.direction === 'bullish'
      
      return {
        detected: true,
        setupType: 'Breakout',
        direction: 'BUY',
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: Number(stop.toFixed(2)),
        target1: Number(target1.toFixed(2)),
        target2: Number(target2.toFixed(2)),
        rewardRiskRatio: rr,
        structureBias: trend.direction,
        whyQualifies: [
          `Broke above ${resistance.touches}-touch resistance at ${resistance.price.toFixed(2)}`,
          `Volume ${currentCandle.volume > candles[candles.length - 2].volume ? 'expanding' : 'steady'} on breakout`,
          `Trend structure ${trendAligned ? 'aligned' : 'neutral'}`,
          `${rr.toFixed(1)}R potential to first target`
        ],
        marketCondition: trendAligned ? 'Trending' : 'Range breakout',
        grade: gradeSetup(confidence, rr, trendAligned),
        confidence
      }
    }
    
    // Look for support breakdown (bearish)
    const support = levels.find(l => 
      l.type === 'support' && 
      l.strength >= 2 &&
      currentPrice < l.price &&
      candles[candles.length - 2].close >= l.price
    )
    
    if (support) {
      const entry = currentPrice
      const stop = support.price + (atr * 0.5)
      const target1 = entry - (atr * 2)
      const target2 = entry - (atr * 3.5)
      const rr = calculateRiskReward(entry, stop, target1)
      
      if (rr < 1.5) return null
      
      const confidence = 60 + (support.strength * 5) + (currentCandle.volume > candles[candles.length - 2].volume ? 10 : 0)
      const trendAligned = trend.direction === 'bearish'
      
      return {
        detected: true,
        setupType: 'Breakout',
        direction: 'SELL',
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: Number(stop.toFixed(2)),
        target1: Number(target1.toFixed(2)),
        target2: Number(target2.toFixed(2)),
        rewardRiskRatio: rr,
        structureBias: trend.direction,
        whyQualifies: [
          `Broke below ${support.touches}-touch support at ${support.price.toFixed(2)}`,
          `Volume ${currentCandle.volume > candles[candles.length - 2].volume ? 'expanding' : 'steady'} on breakdown`,
          `Trend structure ${trendAligned ? 'aligned' : 'neutral'}`,
          `${rr.toFixed(1)}R potential to first target`
        ],
        marketCondition: trendAligned ? 'Trending' : 'Range breakdown',
        grade: gradeSetup(confidence, rr, trendAligned),
        confidence
      }
    }
    
    return null
  }
}

// ============================================
// BREAK + RETEST DETECTOR
// ============================================
class BreakRetestDetector implements SetupDetector {
  type: SetupType = 'Break + Retest'
  
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null {
    const { candles, currentPrice } = marketData
    const atr = getATR(candles)
    
    // Look for bullish retest (broke resistance, now retesting it as support)
    for (const level of levels) {
      // Check if price broke above this level recently (within last 10 candles)
      const brokeAbove = candles.slice(-15, -5).some(c => c.close > level.price) &&
                         candles.slice(-20, -15).every(c => c.close <= level.price)
      
      // Check if now retesting from above
      const retesting = currentPrice > level.price &&
                        currentPrice < level.price + (atr * 0.5) &&
                        candles.slice(-3).some(c => c.low <= level.price * 1.002)
      
      if (brokeAbove && retesting && level.type === 'resistance') {
        const entry = level.price + (atr * 0.2)
        const stop = level.price - (atr * 0.5)
        const target1 = entry + (atr * 2.5)
        const target2 = entry + (atr * 4)
        const rr = calculateRiskReward(entry, stop, target1)
        
        if (rr < 2) return null
        
        const confidence = 70 + (level.strength * 3)
        const trendAligned = trend.direction === 'bullish'
        
        return {
          detected: true,
          setupType: 'Break + Retest',
          direction: 'BUY',
          entryPrice: Number(entry.toFixed(2)),
          stopLoss: Number(stop.toFixed(2)),
          target1: Number(target1.toFixed(2)),
          target2: Number(target2.toFixed(2)),
          rewardRiskRatio: rr,
          structureBias: trend.direction,
          whyQualifies: [
            `Broke resistance at ${level.price.toFixed(2)} and retesting as support`,
            `Clean retest with price respecting the level`,
            `Structure flip confirmed`,
            `${rr.toFixed(1)}R setup with tight invalidation`
          ],
          marketCondition: 'Breakout retest',
          grade: gradeSetup(confidence, rr, trendAligned),
          confidence
        }
      }
      
      // Check for bearish retest
      const brokeBelow = candles.slice(-15, -5).some(c => c.close < level.price) &&
                         candles.slice(-20, -15).every(c => c.close >= level.price)
      
      const retestingBelow = currentPrice < level.price &&
                             currentPrice > level.price - (atr * 0.5) &&
                             candles.slice(-3).some(c => c.high >= level.price * 0.998)
      
      if (brokeBelow && retestingBelow && level.type === 'support') {
        const entry = level.price - (atr * 0.2)
        const stop = level.price + (atr * 0.5)
        const target1 = entry - (atr * 2.5)
        const target2 = entry - (atr * 4)
        const rr = calculateRiskReward(entry, stop, target1)
        
        if (rr < 2) return null
        
        const confidence = 70 + (level.strength * 3)
        const trendAligned = trend.direction === 'bearish'
        
        return {
          detected: true,
          setupType: 'Break + Retest',
          direction: 'SELL',
          entryPrice: Number(entry.toFixed(2)),
          stopLoss: Number(stop.toFixed(2)),
          target1: Number(target1.toFixed(2)),
          target2: Number(target2.toFixed(2)),
          rewardRiskRatio: rr,
          structureBias: trend.direction,
          whyQualifies: [
            `Broke support at ${level.price.toFixed(2)} and retesting as resistance`,
            `Clean retest with price rejecting the level`,
            `Structure flip confirmed`,
            `${rr.toFixed(1)}R setup with tight invalidation`
          ],
          marketCondition: 'Breakdown retest',
          grade: gradeSetup(confidence, rr, trendAligned),
          confidence
        }
      }
    }
    
    return null
  }
}

// ============================================
// PULLBACK DETECTOR
// ============================================
class PullbackDetector implements SetupDetector {
  type: SetupType = 'Pullback'
  
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null {
    const { candles, currentPrice } = marketData
    const atr = getATR(candles)
    
    // Only look for pullbacks in trending markets
    if (trend.direction === 'neutral' || trend.strength < 55) return null
    
    // Bullish pullback
    if (trend.direction === 'bullish' && trend.higherLows) {
      const support = findNearestLevel(levels, currentPrice, 'support', 0.02)
      
      if (support && currentPrice < candles[candles.length - 5].close) {
        // Price has pulled back
        const pullbackDepth = (candles[candles.length - 5].high - currentPrice) / atr
        
        if (pullbackDepth > 0.5 && pullbackDepth < 2) {
          const entry = currentPrice
          const stop = support.price - (atr * 0.3)
          const target1 = entry + (atr * 2)
          const target2 = candles.slice(-20).reduce((max, c) => Math.max(max, c.high), 0)
          const rr = calculateRiskReward(entry, stop, target1)
          
          if (rr < 1.5) return null
          
          const confidence = 65 + (pullbackDepth > 1 ? 10 : 0)
          
          return {
            detected: true,
            setupType: 'Pullback',
            direction: 'BUY',
            entryPrice: Number(entry.toFixed(2)),
            stopLoss: Number(stop.toFixed(2)),
            target1: Number(target1.toFixed(2)),
            target2: Number(target2.toFixed(2)),
            rewardRiskRatio: rr,
            structureBias: 'bullish',
            whyQualifies: [
              `Uptrend with higher lows intact`,
              `Pulled back ${(pullbackDepth * 100).toFixed(0)}% of recent move`,
              `Near support at ${support.price.toFixed(2)}`,
              `${rr.toFixed(1)}R to recent structure`
            ],
            marketCondition: 'Uptrend pullback',
            grade: gradeSetup(confidence, rr, true),
            confidence
          }
        }
      }
    }
    
    // Bearish pullback
    if (trend.direction === 'bearish' && trend.lowerHighs) {
      const resistance = findNearestLevel(levels, currentPrice, 'resistance', 0.02)
      
      if (resistance && currentPrice > candles[candles.length - 5].close) {
        const pullbackDepth = (currentPrice - candles[candles.length - 5].low) / atr
        
        if (pullbackDepth > 0.5 && pullbackDepth < 2) {
          const entry = currentPrice
          const stop = resistance.price + (atr * 0.3)
          const target1 = entry - (atr * 2)
          const target2 = candles.slice(-20).reduce((min, c) => Math.min(min, c.low), Infinity)
          const rr = calculateRiskReward(entry, stop, target1)
          
          if (rr < 1.5) return null
          
          const confidence = 65 + (pullbackDepth > 1 ? 10 : 0)
          
          return {
            detected: true,
            setupType: 'Pullback',
            direction: 'SELL',
            entryPrice: Number(entry.toFixed(2)),
            stopLoss: Number(stop.toFixed(2)),
            target1: Number(target1.toFixed(2)),
            target2: Number(target2.toFixed(2)),
            rewardRiskRatio: rr,
            structureBias: 'bearish',
            whyQualifies: [
              `Downtrend with lower highs intact`,
              `Pulled back ${(pullbackDepth * 100).toFixed(0)}% of recent move`,
              `Near resistance at ${resistance.price.toFixed(2)}`,
              `${rr.toFixed(1)}R to recent structure`
            ],
            marketCondition: 'Downtrend pullback',
            grade: gradeSetup(confidence, rr, true),
            confidence
          }
        }
      }
    }
    
    return null
  }
}

// ============================================
// TREND CONTINUATION DETECTOR
// ============================================
class TrendContinuationDetector implements SetupDetector {
  type: SetupType = 'Trend Continuation'
  
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null {
    const { candles, currentPrice } = marketData
    const atr = getATR(candles)
    
    if (trend.strength < 65) return null
    
    const recentCandles = candles.slice(-3)
    const momentum = recentCandles.every((c, i) => 
      i === 0 || (trend.direction === 'bullish' ? c.close > recentCandles[i-1].close : c.close < recentCandles[i-1].close)
    )
    
    if (!momentum) return null
    
    // Bullish continuation
    if (trend.direction === 'bullish' && trend.higherHighs && trend.higherLows) {
      const entry = currentPrice
      const recentLow = Math.min(...candles.slice(-5).map(c => c.low))
      const stop = recentLow - (atr * 0.2)
      const target1 = entry + (atr * 1.5)
      const target2 = entry + (atr * 2.5)
      const rr = calculateRiskReward(entry, stop, target1)
      
      if (rr < 1.5) return null
      
      const confidence = 60 + (trend.strength - 65)
      
      return {
        detected: true,
        setupType: 'Trend Continuation',
        direction: 'BUY',
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: Number(stop.toFixed(2)),
        target1: Number(target1.toFixed(2)),
        target2: Number(target2.toFixed(2)),
        rewardRiskRatio: rr,
        structureBias: 'bullish',
        whyQualifies: [
          `Strong uptrend with HH + HL structure`,
          `Momentum confirming with 3 consecutive higher closes`,
          `Trend strength at ${trend.strength}%`,
          `Stop below recent swing low`
        ],
        marketCondition: 'Strong uptrend',
        grade: gradeSetup(confidence, rr, true),
        confidence
      }
    }
    
    // Bearish continuation
    if (trend.direction === 'bearish' && trend.lowerHighs && trend.lowerLows) {
      const entry = currentPrice
      const recentHigh = Math.max(...candles.slice(-5).map(c => c.high))
      const stop = recentHigh + (atr * 0.2)
      const target1 = entry - (atr * 1.5)
      const target2 = entry - (atr * 2.5)
      const rr = calculateRiskReward(entry, stop, target1)
      
      if (rr < 1.5) return null
      
      const confidence = 60 + (trend.strength - 65)
      
      return {
        detected: true,
        setupType: 'Trend Continuation',
        direction: 'SELL',
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: Number(stop.toFixed(2)),
        target1: Number(target1.toFixed(2)),
        target2: Number(target2.toFixed(2)),
        rewardRiskRatio: rr,
        structureBias: 'bearish',
        whyQualifies: [
          `Strong downtrend with LH + LL structure`,
          `Momentum confirming with 3 consecutive lower closes`,
          `Trend strength at ${trend.strength}%`,
          `Stop above recent swing high`
        ],
        marketCondition: 'Strong downtrend',
        grade: gradeSetup(confidence, rr, true),
        confidence
      }
    }
    
    return null
  }
}

// ============================================
// SUPPORT HOLD DETECTOR
// ============================================
class SupportHoldDetector implements SetupDetector {
  type: SetupType = 'Support Hold'
  
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null {
    const { candles, currentPrice } = marketData
    const atr = getATR(candles)
    
    // Find strong support level near current price
    const support = levels.find(l => 
      l.type === 'support' &&
      l.strength >= 3 &&
      Math.abs(currentPrice - l.price) / l.price < 0.01 // Within 1%
    )
    
    if (!support) return null
    
    // Check for bounce pattern
    const recentCandles = candles.slice(-5)
    const touchedSupport = recentCandles.some(c => c.low <= support.price * 1.005)
    const bouncing = currentPrice > recentCandles[0].close
    const bullishCandle = recentCandles[recentCandles.length - 1].close > recentCandles[recentCandles.length - 1].open
    
    if (touchedSupport && bouncing && bullishCandle) {
      const entry = currentPrice
      const stop = support.price - (atr * 0.3)
      const target1 = entry + (atr * 2)
      const nearestResistance = levels.find(l => l.type === 'resistance' && l.price > currentPrice)
      const target2 = nearestResistance?.price || entry + (atr * 3)
      const rr = calculateRiskReward(entry, stop, target1)
      
      if (rr < 1.5) return null
      
      const confidence = 65 + (support.strength * 4)
      const trendAligned = trend.direction !== 'bearish'
      
      return {
        detected: true,
        setupType: 'Support Hold',
        direction: 'BUY',
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: Number(stop.toFixed(2)),
        target1: Number(target1.toFixed(2)),
        target2: Number(target2.toFixed(2)),
        rewardRiskRatio: rr,
        structureBias: trend.direction,
        whyQualifies: [
          `Strong ${support.touches}-touch support at ${support.price.toFixed(2)}`,
          `Price bouncing with bullish candle`,
          `Support held on retest`,
          `Clear invalidation below support`
        ],
        marketCondition: 'Support bounce',
        grade: gradeSetup(confidence, rr, trendAligned),
        confidence
      }
    }
    
    return null
  }
}

// ============================================
// RESISTANCE REJECTION DETECTOR
// ============================================
class ResistanceRejectionDetector implements SetupDetector {
  type: SetupType = 'Resistance Rejection'
  
  detect(
    marketData: MarketData,
    levels: SupportResistanceLevel[],
    trend: TrendAnalysis,
    strategy: UserStrategy
  ): SetupDetectionResult | null {
    const { candles, currentPrice } = marketData
    const atr = getATR(candles)
    
    // Find strong resistance level near current price
    const resistance = levels.find(l => 
      l.type === 'resistance' &&
      l.strength >= 3 &&
      Math.abs(currentPrice - l.price) / l.price < 0.01
    )
    
    if (!resistance) return null
    
    // Check for rejection pattern
    const recentCandles = candles.slice(-5)
    const touchedResistance = recentCandles.some(c => c.high >= resistance.price * 0.995)
    const rejecting = currentPrice < recentCandles[0].close
    const bearishCandle = recentCandles[recentCandles.length - 1].close < recentCandles[recentCandles.length - 1].open
    
    if (touchedResistance && rejecting && bearishCandle) {
      const entry = currentPrice
      const stop = resistance.price + (atr * 0.3)
      const target1 = entry - (atr * 2)
      const nearestSupport = levels.find(l => l.type === 'support' && l.price < currentPrice)
      const target2 = nearestSupport?.price || entry - (atr * 3)
      const rr = calculateRiskReward(entry, stop, target1)
      
      if (rr < 1.5) return null
      
      const confidence = 65 + (resistance.strength * 4)
      const trendAligned = trend.direction !== 'bullish'
      
      return {
        detected: true,
        setupType: 'Resistance Rejection',
        direction: 'SELL',
        entryPrice: Number(entry.toFixed(2)),
        stopLoss: Number(stop.toFixed(2)),
        target1: Number(target1.toFixed(2)),
        target2: Number(target2.toFixed(2)),
        rewardRiskRatio: rr,
        structureBias: trend.direction,
        whyQualifies: [
          `Strong ${resistance.touches}-touch resistance at ${resistance.price.toFixed(2)}`,
          `Price rejecting with bearish candle`,
          `Resistance held on test`,
          `Clear invalidation above resistance`
        ],
        marketCondition: 'Resistance rejection',
        grade: gradeSetup(confidence, rr, trendAligned),
        confidence
      }
    }
    
    return null
  }
}

// Export all detectors
export const detectors: SetupDetector[] = [
  new BreakoutDetector(),
  new BreakRetestDetector(),
  new PullbackDetector(),
  new TrendContinuationDetector(),
  new SupportHoldDetector(),
  new ResistanceRejectionDetector()
]

// Get detector by type
export function getDetector(type: SetupType): SetupDetector | undefined {
  return detectors.find(d => d.type === type)
}

// Get detectors matching user preference
export function getDetectorsForPreference(preference: string): SetupDetector[] {
  const preferenceMap: Record<string, SetupType[]> = {
    'Breakouts': ['Breakout', 'Break + Retest'],
    'Pullbacks': ['Pullback', 'Support Hold'],
    'Trend continuation': ['Trend Continuation', 'Pullback'],
    'Reversals': ['Support Hold', 'Resistance Rejection'],
    'All setups': ['Breakout', 'Break + Retest', 'Pullback', 'Trend Continuation', 'Support Hold', 'Resistance Rejection']
  }
  
  const types = preferenceMap[preference] || preferenceMap['All setups']
  return detectors.filter(d => types.includes(d.type))
}
