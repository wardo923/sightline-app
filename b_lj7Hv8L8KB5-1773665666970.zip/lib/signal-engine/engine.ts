// Signal Engine Core
// Orchestrates the scanning process and signal generation

import { createClient } from '@/lib/supabase/server'
import { MarketDataAdapter } from './market-data/adapter'
import { getDetectorsForPreference, detectors } from './detectors'
import { 
  UserStrategy, 
  UserSubscription, 
  SignalRecord, 
  SetupDetectionResult,
  SetupType,
  getAssetClass,
  isAssetSupported
} from './types'
import { 
  getModelConfig, 
  validateSetupForModel, 
  calculateGrade,
  generateQualificationReasons 
} from './models'

// Timeframe to session mapping
const SESSION_TIMEFRAMES: Record<string, string[]> = {
  'US Session': ['9:30 AM - 4:00 PM ET'],
  'London Session': ['3:00 AM - 12:00 PM ET'],
  'Asian Session': ['7:00 PM - 4:00 AM ET'],
  'All Sessions': ['24 hours']
}

// Map user timeframe to actual timeframe string
const TIMEFRAME_MAP: Record<string, string> = {
  '15 minute': '15m',
  '30 minute': '30m',
  '1 hour': '1h',
  '4 hour': '4h',
  'Daily': 'Daily',
  '15m': '15m',
  '30m': '30m',
  '1h': '1h',
  '4h': '4h'
}

// Minimum R:R thresholds by signal frequency preference
const MIN_RR_THRESHOLDS: Record<string, number> = {
  'Selective': 2.5,
  'Balanced': 2.0,
  'Active': 1.5
}

// Minimum grade by signal frequency preference
const MIN_GRADE_THRESHOLDS: Record<string, string[]> = {
  'Selective': ['A'],
  'Balanced': ['A', 'B'],
  'Active': ['A', 'B', 'C']
}

// Duplicate check window in milliseconds (4 hours)
const DUPLICATE_WINDOW_MS = 4 * 60 * 60 * 1000

export class SignalEngine {
  private marketData: MarketDataAdapter
  
  constructor() {
    this.marketData = new MarketDataAdapter()
  }
  
  // Check if current time matches user's session preference
  // Now handled per-asset in scanForUser via marketData.isPreferredSession()
  private isWithinSession(timeOfDay: string): boolean {
    // Always return true here - session filtering is now done per-asset
    // This allows crypto to trade 24/7 while stocks respect market hours
    return true
  }
  
  // Check for duplicate signals
  private async checkDuplicate(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    asset: string,
    setupType: SetupType,
    direction: string
  ): Promise<boolean> {
    const windowStart = new Date(Date.now() - DUPLICATE_WINDOW_MS).toISOString()
    
    const { data } = await supabase
      .from('signals')
      .select('id')
      .eq('user_id', userId)
      .eq('asset', asset)
      .eq('setup_type', setupType)
      .eq('direction', direction)
      .gte('created_at', windowStart)
      .limit(1)
    
    return (data?.length || 0) > 0
  }
  
  // Create signal record in database
  private async createSignal(
    supabase: Awaited<ReturnType<typeof createClient>>,
    signal: SignalRecord
  ): Promise<string | null> {
    const { data, error } = await supabase
      .from('signals')
      .insert({
        user_id: signal.user_id,
        strategy_id: signal.strategy_id,
        asset: signal.asset,
        timeframe: signal.timeframe,
        direction: signal.direction,
        setup_type: signal.setup_type,
        entry_price: signal.entry_price,
        stop_loss: signal.stop_loss,
        target_1: signal.target_1,
        target_2: signal.target_2,
        reward_risk_ratio: signal.reward_risk_ratio,
        signal_grade: signal.signal_grade,
        structure_bias: signal.structure_bias,
        market_condition: signal.market_condition,
        why_qualifies: signal.why_qualifies,
        status: 'pending'
      })
      .select('id')
      .single()
    
    if (error) {
      console.error('Error creating signal:', error)
      return null
    }
    
    return data?.id || null
  }
  
  // Create signal event
  private async createSignalEvent(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    signalId: string,
    eventType: string,
    priceAtEvent?: number,
    notes?: string
  ): Promise<void> {
    await supabase
      .from('signal_events')
      .insert({
        user_id: userId,
        signal_id: signalId,
        event_type: eventType,
        price_at_event: priceAtEvent,
        notes
      })
  }
  
  // Scan for signals for a specific user
  async scanForUser(strategy: UserStrategy): Promise<SignalRecord[]> {
    const supabase = await createClient()
    const signals: SignalRecord[] = []
    
    // Check session timing
    if (!this.isWithinSession(strategy.time_of_day)) {
      return signals
    }
    
    // Get detectors based on user preference
    const detectors = getDetectorsForPreference(strategy.setup_preference)
    
    // Get timeframe
    const timeframe = TIMEFRAME_MAP[strategy.timeframe] || '1h'
    
    // Get thresholds based on frequency preference
    const minRR = MIN_RR_THRESHOLDS[strategy.signal_frequency] || 2.0
    const allowedGrades = MIN_GRADE_THRESHOLDS[strategy.signal_frequency] || ['A', 'B']
    
    // Scan each market
    for (const market of strategy.markets) {
      try {
        // Check if asset is supported
        if (!isAssetSupported(market)) {
          console.log(`Skipping unsupported asset: ${market}`)
          continue
        }
        
        // Get asset class for logging
        const assetClass = getAssetClass(market)
        
        // Check if market is open (stocks respect hours, crypto always open)
        const isOpen = await this.marketData.isMarketOpen(market)
        if (!isOpen) {
          console.log(`Skipping ${market} (${assetClass}) - market closed`)
          continue
        }
        
        // Check if this is a preferred session for the user
        const isPreferredSession = await this.marketData.isPreferredSession(market, strategy.time_of_day)
        if (!isPreferredSession && strategy.time_of_day !== 'any') {
          // Skip but don't log for every asset
          continue
        }
        
        // Get full market analysis (routes to correct provider based on asset class)
        const { marketData, levels, trend, currentSession } = await this.marketData.getFullAnalysis(market, timeframe)
        
        // Run each detector
        for (const detector of detectors) {
          const result = detector.detect(marketData, levels, trend, strategy)
          
          if (result && result.detected) {
            // Apply user filters
            if (result.rewardRiskRatio < minRR) continue
            if (!allowedGrades.includes(result.grade)) continue
            
            // Check for duplicates
            const isDuplicate = await this.checkDuplicate(
              supabase,
              strategy.user_id,
              market,
              result.setupType,
              result.direction
            )
            if (isDuplicate) continue
            
            // Apply confirmation style filter
            if (!this.passesConfirmationFilter(result, strategy.confirmation_style)) continue
            
            // Create signal record
            const signalRecord: SignalRecord = {
              user_id: strategy.user_id,
              strategy_id: strategy.id,
              asset: market,
              timeframe,
              direction: result.direction,
              setup_type: result.setupType,
              entry_price: result.entryPrice,
              stop_loss: result.stopLoss,
              target_1: result.target1,
              target_2: result.target2,
              reward_risk_ratio: result.rewardRiskRatio,
              signal_grade: result.grade,
              structure_bias: result.structureBias,
              market_condition: result.marketCondition,
              why_qualifies: result.whyQualifies,
              status: 'pending'
            }
            
            // Save to database
            const signalId = await this.createSignal(supabase, signalRecord)
            
            if (signalId) {
              signalRecord.id = signalId
              signals.push(signalRecord)
              
              // Create signal_created event
              await this.createSignalEvent(
                supabase,
                strategy.user_id,
                signalId,
                'signal_created',
                result.entryPrice,
                `${result.setupType} setup detected on ${market} ${timeframe}`
              )
            }
          }
        }
      } catch (error) {
        console.error(`Error scanning ${market}:`, error)
      }
    }
    
    return signals
  }
  
  // Check if setup passes confirmation style filter
  private passesConfirmationFilter(result: SetupDetectionResult, confirmationStyle: string): boolean {
    switch (confirmationStyle) {
      case 'Structure only':
        // Always passes - just needs basic structure
        return true
      
      case 'Structure + volume':
        // Needs volume confirmation - check if mentioned in whyQualifies
        return result.whyQualifies.some(r => 
          r.toLowerCase().includes('volume') || result.confidence >= 70
        )
      
      case 'Structure + momentum':
        // Needs momentum confirmation
        return result.whyQualifies.some(r => 
          r.toLowerCase().includes('momentum') || 
          r.toLowerCase().includes('trend') ||
          result.confidence >= 70
        )
      
      case 'Multi-confirmation':
        // Needs multiple confirmations - higher confidence threshold
        return result.confidence >= 75 && result.grade !== 'C'
      
      default:
        return true
    }
  }
  
  // Scan all active users
  async scanAllUsers(): Promise<{ userId: string; signals: SignalRecord[] }[]> {
    const supabase = await createClient()
    const results: { userId: string; signals: SignalRecord[] }[] = []
    
    // Get all active strategies
    const { data: strategies, error } = await supabase
      .from('strategies')
      .select('*')
      .eq('is_active', true)
    
    if (error || !strategies) {
      console.error('Error fetching strategies:', error)
      return results
    }
    
    // Scan for each user based on their strategy type
    for (const strategy of strategies) {
      let signals: SignalRecord[]
      
      // If user has a model_name, use model-based scanning
      if (strategy.model_name) {
        signals = await this.scanWithModel(strategy)
      } else {
        // Legacy: use old custom scanning
        signals = await this.scanForUser(strategy as UserStrategy)
      }
      
      if (signals.length > 0) {
        results.push({ userId: strategy.user_id, signals })
      }
    }
    
    return results
  }
  
  // NEW: Model-based scanning with locked parameters
  async scanWithModel(strategy: {
    id: string
    user_id: string
    model_name: string
    asset: string
    market_type: string
    alert_frequency: string
  }): Promise<SignalRecord[]> {
    const supabase = await createClient()
    const signals: SignalRecord[] = []
    
    // Get the model configuration
    const model = getModelConfig(strategy.model_name)
    if (!model) {
      console.error(`Model not found: ${strategy.model_name}`)
      return signals
    }
    
    const asset = strategy.asset
    
    // Check if asset is supported
    if (!isAssetSupported(asset)) {
      console.log(`Skipping unsupported asset: ${asset}`)
      return signals
    }
    
    // Check if market is open
    const isOpen = await this.marketData.isMarketOpen(asset)
    if (!isOpen) {
      console.log(`Skipping ${asset} - market closed`)
      return signals
    }
    
    // Scan each timeframe defined in the model
    for (const timeframe of model.timeframes) {
      try {
        // Get full market analysis
        const { marketData, levels, trend } = await this.marketData.getFullAnalysis(asset, timeframe)
        
        // Run detectors for each setup type in the model
        for (const setupType of model.setupTypes) {
          const detector = detectors[setupType]
          if (!detector) continue
          
          const result = detector.detect(marketData, levels, trend, {
            confirmation_style: model.confirmationStyle
          } as UserStrategy)
          
          if (result && result.detected) {
            // Validate against model parameters
            const validation = validateSetupForModel(strategy.model_name, {
              setupType: result.setupType,
              timeframe,
              riskReward: result.rewardRiskRatio,
              grade: result.grade,
              hasVolumeConfirmation: result.whyQualifies.some(r => r.toLowerCase().includes('volume')),
              alignsWithTrend: trend.direction !== 'neutral' && (
                (result.direction === 'BUY' && trend.direction === 'bullish') ||
                (result.direction === 'SELL' && trend.direction === 'bearish')
              )
            })
            
            if (!validation.valid) {
              console.log(`Setup rejected: ${validation.reason}`)
              continue
            }
            
            // Check for duplicates
            const isDuplicate = await this.checkDuplicate(
              supabase,
              strategy.user_id,
              asset,
              result.setupType,
              result.direction
            )
            if (isDuplicate) continue
            
            // Check cooldown
            const lastSignalTime = await this.getLastSignalTime(supabase, strategy.user_id, asset)
            if (lastSignalTime) {
              const cooldownMs = model.cooldownMinutes * 60 * 1000
              if (Date.now() - lastSignalTime.getTime() < cooldownMs) {
                console.log(`Asset ${asset} in cooldown`)
                continue
              }
            }
            
            // Check daily signal limit
            const todayCount = await this.getTodaySignalCount(supabase, strategy.user_id, strategy.model_name)
            if (todayCount >= model.maxSignalsPerDay) {
              console.log(`Daily signal limit reached for model ${model.name}`)
              continue
            }
            
            // Generate qualification reasons using model helper
            const qualificationReasons = generateQualificationReasons(strategy.model_name, {
              setupType: result.setupType,
              riskReward: result.rewardRiskRatio,
              levelStrength: levels.keyLevels[0]?.strength || 0.5,
              volumeConfirmation: result.whyQualifies.some(r => r.toLowerCase().includes('volume')),
              trendAlignment: trend.direction !== 'neutral',
              priceAction: result.whyQualifies[0] || '',
              levelType: levels.keyLevels[0]?.type || 'key level'
            })
            
            // Create signal record
            const signalRecord: SignalRecord = {
              user_id: strategy.user_id,
              strategy_id: strategy.id,
              asset,
              timeframe,
              direction: result.direction,
              setup_type: result.setupType,
              entry_price: result.entryPrice,
              stop_loss: result.stopLoss,
              target_1: result.target1,
              target_2: result.target2,
              reward_risk_ratio: result.rewardRiskRatio,
              signal_grade: result.grade,
              structure_bias: result.structureBias,
              market_condition: result.marketCondition,
              why_qualifies: qualificationReasons,
              status: 'pending'
            }
            
            // Save to database
            const signalId = await this.createSignal(supabase, signalRecord)
            
            if (signalId) {
              signalRecord.id = signalId
              signals.push(signalRecord)
              
              // Create signal_created event
              await this.createSignalEvent(
                supabase,
                strategy.user_id,
                signalId,
                'signal_created',
                result.entryPrice,
                `${model.name}: ${result.setupType} on ${asset} ${timeframe}`
              )
            }
          }
        }
      } catch (error) {
        console.error(`Error scanning ${asset} ${timeframe}:`, error)
      }
    }
    
    return signals
  }
  
  // Get last signal time for an asset
  private async getLastSignalTime(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    asset: string
  ): Promise<Date | null> {
    const { data } = await supabase
      .from('signals')
      .select('created_at')
      .eq('user_id', userId)
      .eq('symbol', asset)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    
    return data ? new Date(data.created_at) : null
  }
  
  // Get today's signal count for a model
  private async getTodaySignalCount(
    supabase: Awaited<ReturnType<typeof createClient>>,
    userId: string,
    modelName: string
  ): Promise<number> {
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const { count } = await supabase
      .from('signals')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .gte('created_at', today.toISOString())
    
    return count || 0
  }
}

// Export singleton
export const signalEngine = new SignalEngine()
