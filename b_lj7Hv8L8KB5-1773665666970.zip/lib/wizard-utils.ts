import { WizardAnswers, MarketType, AlertStrength } from "@/types/strategy"

export function normalizeMarketType(value?: string): MarketType {
  if (value === "Crypto") return "CRYPTO"
  return "STOCKS"
}

export function normalizeAlertStrength(value?: string): AlertStrength {
  if (value === "Balanced") return "BALANCED"
  if (value === "Early Opportunities") return "EARLY_OPPORTUNITY"
  return "HIGH_CONFIRMATION"
}

export function getDefaultStrategyName(answers: WizardAnswers, bundleName: string) {
  const asset = answers.asset || "Custom"
  return `${asset} ${bundleName}`
}

export function getAnswerLabel(value?: string) {
  return value || "—"
}
