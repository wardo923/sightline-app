import { StrategyBundle } from "@/types/strategy"
import { ScoreMap } from "@/lib/strategy-matrix"

export type RankedStrategy = {
  strategy: StrategyBundle
  score: number
}

export function rankStrategies(scores: ScoreMap): RankedStrategy[] {
  return Object.entries(scores)
    .map(([strategy, score]) => ({
      strategy: strategy as StrategyBundle,
      score,
    }))
    .sort((a, b) => b.score - a.score)
}

export function calculateConfidence(scores: ScoreMap) {
  const ranked = rankStrategies(scores)
  const top = ranked[0]
  const second = ranked[1]

  // Calculate raw confidence based on top score strength and separation from second
  const maxReasonableScore = 32 // Adjusted for higher weights
  const rawStrength = Math.min(top.score / maxReasonableScore, 1)
  const separation = second ? Math.min((top.score - second.score) / 6, 1) : 1

  // Combine strength (60%) and separation (40%) for raw confidence
  const rawConfidence = Math.round((rawStrength * 0.6 + separation * 0.4) * 100)

  // Include secondary match if within 3 points of the top score
  const includeSecondary = second && (top.score - second.score) <= 3

  return {
    confidence: rawConfidence,
    topStrategy: top.strategy,
    topScore: top.score,
    secondStrategy: includeSecondary ? second.strategy : null,
    secondScore: second?.score ?? 0,
    ranked,
  }
}
