import { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"
import { Target, Shield, BarChart3 } from "lucide-react"

export const metadata: Metadata = {
  title: "About - SightLine",
  description: "SightLine was created to help traders approach markets with greater structure and clarity.",
}

const values = [
  {
    icon: Target,
    title: "Structure Over Prediction",
    description: "We believe in structured analysis rather than trying to predict market movements.",
  },
  {
    icon: Shield,
    title: "Risk-First Approach",
    description: "Every setup should have defined risk parameters before considering potential reward.",
  },
  {
    icon: BarChart3,
    title: "Disciplined Framework",
    description: "Consistent application of a trading framework leads to better decision-making over time.",
  },
]

export default function AboutPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <p className="mb-4 text-xs font-semibold tracking-widest text-primary uppercase">
            About
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            About SightLine
          </h1>
        </div>
      </section>

      {/* Mission */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-4 md:px-6">
          <div className="rounded-2xl border border-border bg-card p-8 md:p-12">
            <p className="text-lg text-foreground leading-relaxed mb-6">
              SightLine was created to help traders approach markets with greater structure and clarity.
            </p>
            <p className="text-base text-muted-foreground leading-relaxed mb-6">
              By focusing on market structure and risk management, the platform helps traders evaluate opportunities within a disciplined analytical framework.
            </p>
            <p className="text-base text-muted-foreground leading-relaxed">
              We believe that better structure leads to better trading decisions. SightLine was built to make that structure accessible to traders of all experience levels.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="section-glow-top grid-bg py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              Our Approach
            </h2>
          </div>

          <div className="grid gap-6 md:grid-cols-3">
            {values.map((value) => (
              <div
                key={value.title}
                className="rounded-xl border border-border/50 bg-card/50 p-6 text-center card-glow"
              >
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <value.icon className="h-7 w-7" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  {value.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* What We Are Not */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              What SightLine Is Not
            </h2>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-6">
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Not a broker.</strong> SightLine does not execute trades or connect to brokerage accounts.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Not financial advice.</strong> We provide analytical tools, not investment recommendations.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <p className="text-sm text-muted-foreground">
                <strong className="text-foreground">Not a guarantee.</strong> Trading involves substantial risk. Past performance does not guarantee future results.
              </p>
            </div>
          </div>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
