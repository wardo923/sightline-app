import { Navbar } from "@/components/navbar"
import Link from "next/link"
import { Shield, Lock, Server, Globe } from "lucide-react"

export const metadata = {
  title: "Company - SightLine Advanced Trading Analytics",
  description: "About SightLine Advanced Trading Analytics - our mission, security practices, and company information",
}

export default function CompanyPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <div className="mx-auto max-w-4xl px-5 py-32">
        <div className="text-center mb-16">
          <p className="text-xs font-semibold tracking-widest text-primary uppercase mb-3">
            About SightLine
          </p>
          <h1 className="text-3xl font-bold text-foreground md:text-4xl mb-4">
            Building Better Trading Tools
          </h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            SightLine Advanced Trading Analytics is a market analysis platform designed to help traders make more structured, risk-aware decisions.
          </p>
        </div>

        {/* Mission */}
        <section className="mb-16">
          <h2 className="text-xl font-semibold text-foreground mb-4">Our Mission</h2>
          <div className="rounded-xl border border-border bg-card p-6">
            <p className="text-muted-foreground leading-relaxed">
              We believe that disciplined trading starts with structure. Our mission is to provide traders with clear, risk-defined market analysis that cuts through the noise and supports consistent decision-making.
            </p>
          </div>
        </section>

        {/* Security & Compliance */}
        <section className="mb-16">
          <h2 className="text-xl font-semibold text-foreground mb-6">Security & Infrastructure</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Lock className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">Data Encryption</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                All data is encrypted in transit (TLS 1.3) and at rest (AES-256). We never store plaintext passwords or sensitive credentials.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Shield className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">Privacy First</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                We do not sell user data to third parties. Your trading preferences and profile information remain private.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Server className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">Secure Infrastructure</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                Hosted on enterprise-grade cloud infrastructure with SOC 2 compliance, automatic backups, and 99.9% uptime SLA.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex items-center gap-3 mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Globe className="h-5 w-5 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground">No Broker Access</h3>
              </div>
              <p className="text-sm text-muted-foreground">
                SightLine never connects to your brokerage account. We provide analysis only — all trading decisions and execution remain with you.
              </p>
            </div>
          </div>
        </section>

        {/* Platform Details */}
        <section className="mb-16">
          <h2 className="text-xl font-semibold text-foreground mb-6">Platform Overview</h2>
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Product</h3>
                <p className="text-sm text-muted-foreground">SaaS Market Analysis Platform</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Founded</h3>
                <p className="text-sm text-muted-foreground">2025</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Target Users</h3>
                <p className="text-sm text-muted-foreground">Retail traders seeking structured market analysis</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Markets Covered</h3>
                <p className="text-sm text-muted-foreground">Crypto, Equities, ETFs, Forex</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Revenue Model</h3>
                <p className="text-sm text-muted-foreground">Subscription-based SaaS (monthly recurring)</p>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground mb-2">Technology Stack</h3>
                <p className="text-sm text-muted-foreground">Next.js, React, TypeScript, Vercel</p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section className="mb-16">
          <h2 className="text-xl font-semibold text-foreground mb-4">Contact</h2>
          <div className="rounded-xl border border-border bg-card p-6">
            <div className="space-y-3 text-sm text-muted-foreground">
              <p>
                <span className="font-medium text-foreground">General Inquiries:</span>{" "}
                <a href="mailto:hello@sightline.io" className="text-primary hover:underline">hello@sightline.io</a>
              </p>
              <p>
                <span className="font-medium text-foreground">Support:</span>{" "}
                <a href="mailto:support@sightline.io" className="text-primary hover:underline">support@sightline.io</a>
              </p>
              <p>
                <span className="font-medium text-foreground">Business Development:</span>{" "}
                <a href="mailto:partnerships@sightline.io" className="text-primary hover:underline">partnerships@sightline.io</a>
              </p>
            </div>
          </div>
        </section>

        <div className="pt-8 border-t border-border">
          <Link href="/" className="text-sm text-primary hover:underline">
            ← Back to Home
          </Link>
        </div>
      </div>
    </main>
  )
}
