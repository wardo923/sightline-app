import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"
import { 
  generateDemoSignal, 
  generateDemoSignalBatch,
  getBestFrameworksForAsset 
} from "@/lib/signal-engine/demo-generator"
import { StrategyBundle } from "@/types/strategy"

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    const { data: { user } } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { 
      asset, 
      framework, 
      quality,
      count = 1,
      mode = 'single' // 'single', 'batch', 'preview'
    } = body

    // Get user's most recent strategy to determine framework
    const { data: activeStrategy } = await supabase
      .from('strategies')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()

    const targetFramework = framework || activeStrategy?.bundle_name || 'MOMENTUM_BREAKOUT'
    const targetAsset = asset || activeStrategy?.asset || 'SPY'

    if (mode === 'preview') {
      // Generate preview signals without saving to database
      const assets = ['SPY', 'QQQ', 'BTC', 'ETH']
      const previewSignals = assets.flatMap(a => {
        const frameworks = getBestFrameworksForAsset(a)
        const primaryFramework = frameworks[0] || 'MOMENTUM_BREAKOUT'
        return [generateDemoSignal(a, primaryFramework as StrategyBundle, 'Strong')]
      })

      return NextResponse.json({ 
        success: true, 
        mode: 'preview',
        signals: previewSignals 
      })
    }

    // Generate signals
    let generatedSignals
    if (mode === 'batch') {
      const assets = Array.isArray(targetAsset) ? targetAsset : [targetAsset]
      generatedSignals = generateDemoSignalBatch(
        assets, 
        targetFramework as StrategyBundle, 
        count
      )
    } else {
      generatedSignals = [generateDemoSignal(
        targetAsset, 
        targetFramework as StrategyBundle, 
        quality || 'Strong'
      )]
    }

    // Save signals to database (use correct column names)
    const signalsToInsert = generatedSignals.map(signal => ({
      user_id: user.id,
      asset: signal.symbol,
      timeframe: signal.timeframe,
      direction: signal.direction,
      entry_price: signal.entry_price,
      stop_loss: signal.stop_loss,
      target_1: signal.target_1,
      target_2: signal.target_2,
      reward_risk_ratio: parseFloat(signal.risk_reward),
      setup_type: signal.setup_type,
      setup_quality: signal.setup_quality,
      watch_level: signal.watch_level,
      v1_score: signal.v1_score,
      market_condition: signal.market_condition,
      signal_grade: signal.grade || 'B',
      why_qualifies: signal.reasons,
      status: 'pending',
    }))

    const { data: savedSignals, error } = await supabase
      .from('signals')
      .insert(signalsToInsert)
      .select()

    if (error) {
      console.error('Error saving signals:', error)
      return NextResponse.json({ error: error.message }, { status: 500 })
    }

    return NextResponse.json({ 
      success: true, 
      mode,
      count: savedSignals.length,
      signals: savedSignals 
    })
  } catch (error) {
    console.error('Signal generation error:', error)
    return NextResponse.json(
      { error: "Failed to generate signals" },
      { status: 500 }
    )
  }
}

// GET: Preview signals without auth (for demo page)
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const assets = searchParams.get('assets')?.split(',') || ['SPY', 'QQQ', 'BTC', 'ETH']

  // Generate quality signals that pass V1 filters
  const qualitySignals = assets.flatMap(asset => {
    const frameworks = getBestFrameworksForAsset(asset)
    const primaryFramework = frameworks[0] || 'MOMENTUM_BREAKOUT'
    
    // Conservative V1 distribution: 15% Elite, 40% Strong, 30% Developing, 15% suppressed
    const rand = Math.random()
    const quality = rand < 0.15 ? 'Elite' : rand < 0.55 ? 'Strong' : rand < 0.85 ? 'Developing' : 'NoAlert'
    
    return generateDemoSignal(asset, primaryFramework as StrategyBundle, quality as any)
  })

  // Add suppressed signal examples to demonstrate V1 filtering
  const suppressedExamples = [
    {
      symbol: 'SPY',
      timeframe: '5m',
      direction: 'BUY' as const,
      setup_type: 'MOMENTUM_BREAKOUT',
      setup_quality: 'NoAlert' as const,
      entry_price: 587.50,
      stop_loss: 586.20,
      target_1: 589.10,
      target_2: 590.50,
      risk_reward: '1.2',
      watch_level: 587.00,
      v1_score: 3,
      reasons: ['Structure break detected', 'No retest confirmation', 'Weak session volume', 'Midday liquidity filter applied'],
      market_condition: 'Ranging',
      grade: 'C',
      suppressed: true,
      suppressReason: 'Midday session (11:30-14:00) - reduced liquidity period'
    },
    {
      symbol: 'QQQ',
      timeframe: '15m',
      direction: 'BUY' as const,
      setup_type: 'VOLATILITY_EXPANSION',
      setup_quality: 'NoAlert' as const,
      entry_price: 512.80,
      stop_loss: 510.50,
      target_1: 515.20,
      target_2: 517.00,
      risk_reward: '1.0',
      watch_level: 512.00,
      v1_score: 3,
      reasons: ['Range expansion detected', 'Move already 2.1x ATR extended', 'Approaching resistance', 'Trend exhaustion filter applied'],
      market_condition: 'Trending',
      grade: 'C',
      suppressed: true,
      suppressReason: 'Move exhausted - price extended 2.1x ATR from consolidation'
    },
    {
      symbol: 'BTC',
      timeframe: '1h',
      direction: 'SELL' as const,
      setup_type: 'STRUCTURE_REACTION',
      setup_quality: 'NoAlert' as const,
      entry_price: 103250,
      stop_loss: 104100,
      target_1: 102100,
      target_2: 101200,
      risk_reward: '1.4',
      watch_level: 103500,
      v1_score: 3,
      reasons: ['Price at structure level', 'No clear rejection candle', 'Momentum not confirmed', 'Volume below threshold'],
      market_condition: 'Consolidating',
      grade: 'C',
      suppressed: true,
      suppressReason: 'Incomplete setup - no rejection confirmation at level'
    }
  ]

  const allSignals = [...qualitySignals, ...suppressedExamples]
  
  // Calculate stats
  const stats = {
    total: allSignals.length,
    elite: allSignals.filter(s => s.setup_quality === 'Elite').length,
    strong: allSignals.filter(s => s.setup_quality === 'Strong').length,
    developing: allSignals.filter(s => s.setup_quality === 'Developing').length,
    suppressed: allSignals.filter(s => (s as any).suppressed || s.setup_quality === 'NoAlert').length,
    passRate: Math.round((allSignals.filter(s => s.setup_quality !== 'NoAlert' && !(s as any).suppressed).length / allSignals.length) * 100)
  }

  return NextResponse.json({ signals: allSignals, stats })
}
