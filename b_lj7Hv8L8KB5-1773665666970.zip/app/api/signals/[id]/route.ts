import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  
  const { data: signal, error } = await supabase
    .from("signals")
    .select("*, signal_events(*)")
    .eq("id", id)
    .eq("user_id", user.id)
    .single()
  
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 404 })
  }
  
  return NextResponse.json({ signal })
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  
  const body = await request.json()
  
  const { data: signal, error } = await supabase
    .from("signals")
    .update({
      status: body.status,
      outcome: body.outcome || null,
      exit_price: body.exitPrice || null,
      reward_achieved: body.rewardAchieved || null,
      closed_at: body.closedAt || null,
      read_at: body.readAt || null,
    })
    .eq("id", id)
    .eq("user_id", user.id)
    .select()
    .single()
  
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
  
  // Log status change event
  if (body.status) {
    await supabase.from("signal_events").insert({
      signal_id: id,
      event_type: "status_change",
      details: { 
        new_status: body.status,
        outcome: body.outcome,
        exit_price: body.exitPrice,
      },
    })
  }
  
  return NextResponse.json({ signal })
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const supabase = await createClient()
  
  const { data: { user } } = await supabase.auth.getUser()
  
  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }
  
  const { error } = await supabase
    .from("signals")
    .delete()
    .eq("id", id)
    .eq("user_id", user.id)
  
  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
  
  return NextResponse.json({ success: true })
}
