import { NextRequest, NextResponse } from "next/server"
import { scoreSignal, passesStrictnessFilter, SignalType } from "@/lib/signal-scoring"
import { isSignalAllowed, MarketCondition } from "@/lib/market-condition"

// Webhook endpoint for TradingView alerts
// TradingView sends POST requests with JSON payload

const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || "sightline-webhook-secret-2024"

// Map TradingView setup types to our signal types
const SETUP_TYPE_MAP: Record<string, SignalType> = {
  "breakout": "breakout",
  "break_retest": "break_retest",
  "break+retest": "break_retest",
  "support": "support_hold",
  "support_hold": "support_hold",
  "resistance": "resistance_rejection",
  "resistance_rejection": "resistance_rejection",
  "trend": "trend_continuation",
  "trend_continuation": "trend_continuation",
  "vwap_reclaim": "vwap_reclaim",
  "vwap_rejection": "vwap_rejection",
  "liquidity": "liquidity_sweep",
  "liquidity_sweep": "liquidity_sweep",
  "orb": "opening_range_breakout",
  "opening_range": "opening_range_breakout",
  "range": "range_bounce",
  "range_bounce": "range_bounce",
  "compression": "compression_breakout",
  "compression_breakout": "compression_breakout",
  "failed_breakout": "failed_breakout",
  "trap": "failed_breakout",
}

// Map market condition strings
const MARKET_CONDITION_MAP: Record<string, MarketCondition> = {
  "trending": "trending_up",
  "trending_up": "trending_up",
  "uptrend": "trending_up",
  "trending_down": "trending_down",
  "downtrend": "trending_down",
  "ranging": "ranging",
  "range": "ranging",
  "compression": "compression",
  "consolidation": "compression",
  "volatile": "volatile",
  "high_volatility": "volatile",
}

export async function POST(request: NextRequest) {
  try {
    // Validate webhook secret
    const authHeader = request.headers.get("authorization")
    const urlSecret = request.nextUrl.searchParams.get("secret")
    const providedSecret = authHeader?.replace("Bearer ", "") || urlSecret
    
    if (providedSecret !== WEBHOOK_SECRET) {
      return NextResponse.json(
        { error: "Unauthorized", message: "Invalid or missing webhook secret" },
        { status: 401 }
      )
    }
    
    // Parse request body
    const body = await request.json()
    console.log("[Webhook] Received signal:", JSON.stringify(body, null, 2))
    
    // Validate required fields
    const requiredFields = ["symbol", "timeframe", "direction", "entry", "stopLoss", "target1"]
    const missingFields = requiredFields.filter(field => !(field in body))
    
    if (missingFields.length > 0) {
      return NextResponse.json(
        { error: "Invalid signal", message: `Missing fields: ${missingFields.join(", ")}` },
        { status: 400 }
      )
    }
    
    // Normalize direction
    const dirRaw = String(body.direction).toUpperCase()
    const direction: "LONG" | "SHORT" = ["BUY", "LONG"].includes(dirRaw) ? "LONG" : "SHORT"
    
    // Parse numeric values
    const entry = Number(body.entry)
    const stopLoss = Number(body.stopLoss)
    const target1 = Number(body.target1)
    const target2 = body.target2 ? Number(body.target2) : undefined
    const currentPrice = body.currentPrice ? Number(body.currentPrice) : entry
    
    // Get signal type
    const rawSetupType = String(body.setupType || "breakout").toLowerCase().replace(/ /g, "_")
    const signalType: SignalType = SETUP_TYPE_MAP[rawSetupType] || "breakout"
    
    // Get market condition
    const rawCondition = String(body.marketCondition || "ranging").toLowerCase().replace(/ /g, "_")
    const marketCondition: MarketCondition = MARKET_CONDITION_MAP[rawCondition] || "ranging"
    
    // Check if signal type is allowed in current market condition
    if (!isSignalAllowed(signalType, marketCondition)) {
      return NextResponse.json({
        success: false,
        message: `Signal type "${signalType}" is not allowed in "${marketCondition}" market conditions`,
        signalType,
        marketCondition,
        allowedInCondition: false,
      }, { status: 200 })
    }
    
    // Score the signal
    const scoreInput = {
      signalType,
      direction,
      entry,
      stopLoss,
      target1,
      target2,
      currentPrice,
      marketCondition,
      // Optional confirmations from TradingView
      trendAligned: body.trendAligned ?? body.trend_aligned ?? false,
      htfAligned: body.htfAligned ?? body.htf_aligned ?? false,
      volumeExpansion: body.volumeExpansion ?? body.volume_expansion ?? body.volume ?? false,
      cleanBreak: body.cleanBreak ?? body.clean_break ?? body.breakConfirmed ?? true,
      retestHeld: body.retestHeld ?? body.retest_held ?? false,
      rejectionCandle: body.rejectionCandle ?? body.rejection_candle ?? body.rejection ?? false,
      momentumStrong: body.momentumStrong ?? body.momentum_strong ?? body.momentum ?? false,
      vwapReclaimed: body.vwapReclaimed ?? body.vwap_reclaimed ?? false,
      liquiditySweep: body.liquiditySweep ?? body.liquidity_sweep ?? false,
      compressionDetected: body.compressionDetected ?? body.compression_detected ?? false,
    }
    
    const signalScore = scoreSignal(scoreInput)
    
    // Check if signal meets minimum grade threshold
    if (signalScore.grade === "NONE") {
      return NextResponse.json({
        success: false,
        message: "Signal did not meet minimum quality threshold (score below 4)",
        score: signalScore.totalScore,
        maxScore: signalScore.maxScore,
        grade: signalScore.grade,
        confirmations: signalScore.confirmations,
      }, { status: 200 })
    }
    
    // Calculate risk-reward
    const risk = Math.abs(entry - stopLoss)
    const reward = direction === "LONG" ? target1 - entry : entry - target1
    const riskReward = risk > 0 ? (reward / risk).toFixed(1) : "0"
    
    // Build the processed signal
    const processedSignal = {
      symbol: String(body.symbol),
      timeframe: String(body.timeframe),
      direction: direction === "LONG" ? "BUY" : "SELL",
      signalType: signalScore.signalTypeDisplay,
      grade: signalScore.grade,
      score: signalScore.totalScore,
      maxScore: signalScore.maxScore,
      entry,
      stopLoss,
      target1,
      target2,
      riskReward: `${riskReward}R`,
      marketCondition,
      qualifyingReasons: signalScore.qualifyingReasons,
      confirmations: signalScore.confirmations,
      timestamp: new Date().toISOString(),
      webhookId: `wh_${Date.now()}`,
    }
    
    console.log("[Webhook] Processed signal:", JSON.stringify(processedSignal, null, 2))
    
    return NextResponse.json({
      success: true,
      message: `Signal processed - Grade ${signalScore.grade} (${signalScore.totalScore}/${signalScore.maxScore})`,
      signal: processedSignal,
    })
    
  } catch (error) {
    console.error("[Webhook] Error processing signal:", error)
    return NextResponse.json(
      { error: "Server error", message: "Failed to process signal" },
      { status: 500 }
    )
  }
}

// GET endpoint for testing webhook connectivity
export async function GET() {
  return NextResponse.json({
    status: "ok",
    message: "SightLine TradingView Webhook is active",
    version: "2.0 - Signal Quality Scoring",
    instructions: {
      method: "POST",
      contentType: "application/json",
      authentication: "Add ?secret=YOUR_SECRET or Authorization: Bearer YOUR_SECRET header",
      examplePayload: {
        symbol: "BTCUSD",
        timeframe: "15",
        direction: "BUY",
        entry: 64200,
        stopLoss: 63700,
        target1: 65300,
        target2: 66000,
        setupType: "break_retest",
        marketCondition: "trending_up",
        trendAligned: true,
        htfAligned: true,
        volumeExpansion: true,
        cleanBreak: true,
        retestHeld: true,
      },
      setupTypes: Object.keys(SETUP_TYPE_MAP),
      marketConditions: Object.keys(MARKET_CONDITION_MAP),
    },
  })
}
