// Signal Scanner API Route
// Triggers signal scanning for the authenticated user or all users (admin/cron)

import { NextRequest, NextResponse } from 'next/server'
import { createClient } from '@/lib/supabase/server'
import { SignalEngine } from '@/lib/signal-engine/engine'
import { notificationService } from '@/lib/signal-engine/notifications'
import { UserStrategy } from '@/lib/signal-engine/types'
import { checkUsageLimits, logScan } from '@/lib/usage-limits'
import { getPlanTier, getPlanLimits } from '@/lib/plan-limits'

// POST /api/signals/scan
// Scans for signals for the authenticated user
export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    
    // Check authentication
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    // Get user's subscription to determine tier
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select('plan')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single()
    
    const tier = getPlanTier(subscription?.plan)
    const limits = getPlanLimits(tier)
    
    // Check usage limits
    const usageCheck = await checkUsageLimits(user.id, tier)
    
    if (!usageCheck.canScan) {
      return NextResponse.json(
        { 
          error: 'Daily scan limit reached',
          limit: limits.maxScansPerDay,
          used: usageCheck.usage.scansToday,
          upgradeUrl: '/pricing'
        },
        { status: 429 }
      )
    }
    
    // Get user's active strategy
    const { data: strategy, error: strategyError } = await supabase
      .from('strategies')
      .select('*')
      .eq('user_id', user.id)
      .single()
    
    if (strategyError || !strategy) {
      return NextResponse.json(
        { error: 'No strategy found. Complete the onboarding wizard first.' },
        { status: 400 }
      )
    }
    
    // Enforce asset limits based on tier
    const assets = strategy.wizard_answers?.assets || []
    const limitedAssets = assets.slice(0, limits.maxMonitoredAssets)
    const strategyWithLimits = {
      ...strategy,
      wizard_answers: {
        ...strategy.wizard_answers,
        assets: limitedAssets
      }
    }
    
    // Log the scan
    await logScan(user.id)
    
    // Run the scanner with tier-limited strategy
    const engine = new SignalEngine()
    let signals = await engine.scanForUser(strategyWithLimits as UserStrategy)
    
    // Enforce signal limit based on tier
    if (signals.length > 0 && usageCheck.usage.signalsToday + signals.length > limits.maxSignalsPerDay) {
      const remaining = Math.max(0, limits.maxSignalsPerDay - usageCheck.usage.signalsToday)
      signals = signals.slice(0, remaining)
    }
    
    // Send notifications for each signal
    const notificationResults = await notificationService.notifyForSignals(signals)
    
    return NextResponse.json({
      success: true,
      signalsGenerated: signals.length,
      signals: signals.map(s => ({
        id: s.id,
        asset: s.asset,
        direction: s.direction,
        setup_type: s.setup_type,
        grade: s.signal_grade,
        entry: s.entry_price,
        rr: s.reward_risk_ratio
      })),
      notifications: Object.fromEntries(notificationResults)
    })
    
  } catch (error) {
    console.error('Scan error:', error)
    return NextResponse.json(
      { error: 'Failed to scan for signals' },
      { status: 500 }
    )
  }
}

// GET /api/signals/scan
// Returns scanner status and last scan info
export async function GET(request: NextRequest) {
  try {
    const supabase = await createClient()
    
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    
    if (authError || !user) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 }
      )
    }
    
    // Get user's subscription to determine tier
    const { data: subscription } = await supabase
      .from('subscriptions')
      .select('plan')
      .eq('user_id', user.id)
      .eq('status', 'active')
      .single()
    
    const tier = getPlanTier(subscription?.plan)
    const limits = getPlanLimits(tier)
    
    // Check current usage
    const usageCheck = await checkUsageLimits(user.id, tier)
    
    // Get last signal for this user
    const { data: lastSignal } = await supabase
      .from('signals')
      .select('created_at, asset, setup_type')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(1)
      .single()
    
    // Get signal counts
    const { count: totalSignals } = await supabase
      .from('signals')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
    
    return NextResponse.json({
      status: 'ready',
      tier,
      lastScan: lastSignal?.created_at || null,
      lastSignal: lastSignal ? {
        asset: lastSignal.asset,
        setup_type: lastSignal.setup_type,
        created_at: lastSignal.created_at
      } : null,
      usage: {
        signalsToday: usageCheck.usage.signalsToday,
        signalsLimit: limits.maxSignalsPerDay,
        alertsToday: usageCheck.usage.alertsToday,
        alertsLimit: limits.maxAlertsPerDay,
        scansToday: usageCheck.usage.scansToday,
        scansLimit: limits.maxScansPerDay,
        assetsMonitored: usageCheck.usage.assetsMonitored || 0,
        assetsLimit: limits.maxMonitoredAssets
      },
      stats: {
        totalSignals: totalSignals || 0,
        todaySignals: usageCheck.usage.signalsToday
      },
      limits: {
        canScan: usageCheck.canScan,
        canGenerateSignal: usageCheck.canGenerateSignal,
        canSendAlert: usageCheck.canSendAlert
      }
    })
    
  } catch (error) {
    console.error('Status error:', error)
    return NextResponse.json(
      { error: 'Failed to get scanner status' },
      { status: 500 }
    )
  }
}
