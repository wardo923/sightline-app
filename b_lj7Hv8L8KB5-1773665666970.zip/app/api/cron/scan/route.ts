// Cron Scanner API Route
// Runs the signal scanner for all active users every 5 minutes
// Only scans supported live assets: SPY, QQQ, NVDA, BTC, ETH

import { NextRequest, NextResponse } from 'next/server'
import { SignalEngine } from '@/lib/signal-engine/engine'
import { notificationService } from '@/lib/signal-engine/notifications'
import { checkUsageLimits, logScan } from '@/lib/usage-limits'
import { getPlanTier, getPlanLimits } from '@/lib/plan-limits'
import { createClient } from '@/lib/supabase/server'

// Live assets currently supported
const LIVE_ASSETS = ['SPY', 'QQQ', 'NVDA', 'BTC', 'ETH']

// Verify cron secret to prevent unauthorized access
function verifyCronSecret(request: NextRequest): boolean {
  const authHeader = request.headers.get('authorization')
  const cronSecret = process.env.CRON_SECRET
  
  // If no CRON_SECRET is set, allow in development
  if (!cronSecret && process.env.NODE_ENV === 'development') {
    return true
  }
  
  // Vercel Cron jobs include this header
  const isVercelCron = request.headers.get('x-vercel-cron') === '1'
  if (isVercelCron) {
    return true
  }
  
  if (!cronSecret || !authHeader) {
    return false
  }
  
  return authHeader === `Bearer ${cronSecret}`
}

// GET /api/cron/scan
// Scans all users for signals (called by cron every 5 minutes)
export async function GET(request: NextRequest) {
  // Verify authorization
  if (!verifyCronSecret(request)) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    )
  }
  
  const startTime = Date.now()
  
  try {
    console.log('[Cron] Starting signal scan...')
    console.log('[Cron] Live assets:', LIVE_ASSETS.join(', '))
    
    const supabase = await createClient()
    const engine = new SignalEngine()
    
    // Scan all users but filter to only those with supported assets
    const results = await engine.scanAllUsers()
    
    // Filter results to only include signals for live assets and respect tier limits
    const filteredResults: Array<{ userId: string; signals: typeof results[0]['signals'] }> = []
    
    for (const { userId, signals } of results) {
      // Get user's subscription tier
      const { data: subscription } = await supabase
        .from('subscriptions')
        .select('plan')
        .eq('user_id', userId)
        .eq('status', 'active')
        .single()
      
      const tier = getPlanTier(subscription?.plan)
      const limits = getPlanLimits(tier)
      
      // Check usage limits for this user
      const usageCheck = await checkUsageLimits(userId, tier)
      
      // Skip if user has reached their scan limit
      if (!usageCheck.canScan) {
        console.log(`[Cron] User ${userId.slice(0, 8)}... skipped - scan limit reached`)
        continue
      }
      
      // Log the scan
      await logScan(userId)
      
      // Filter to live assets
      let userSignals = signals.filter(signal => LIVE_ASSETS.includes(signal.asset))
      
      // Enforce signal limit based on tier
      if (userSignals.length > 0 && usageCheck.usage.signalsToday + userSignals.length > limits.maxSignalsPerDay) {
        const remaining = Math.max(0, limits.maxSignalsPerDay - usageCheck.usage.signalsToday)
        userSignals = userSignals.slice(0, remaining)
        console.log(`[Cron] User ${userId.slice(0, 8)}... limited to ${remaining} signals (tier: ${tier})`)
      }
      
      if (userSignals.length > 0) {
        filteredResults.push({ userId, signals: userSignals })
      }
    }
    
    let totalSignals = 0
    let totalNotifications = 0
    const signalsByAsset: Record<string, number> = {}
    
    // Send notifications for each user's signals (respecting alert limits)
    for (const { userId, signals } of filteredResults) {
      totalSignals += signals.length
      
      // Track signals by asset
      for (const signal of signals) {
        signalsByAsset[signal.asset] = (signalsByAsset[signal.asset] || 0) + 1
      }
      
      if (signals.length > 0) {
        // Check alert limits before sending notifications
        const { data: subscription } = await supabase
          .from('subscriptions')
          .select('plan')
          .eq('user_id', userId)
          .eq('status', 'active')
          .single()
        
        const tier = getPlanTier(subscription?.plan)
        const usageCheck = await checkUsageLimits(userId, tier)
        
        if (usageCheck.canSendAlert) {
          const notificationResults = await notificationService.notifyForSignals(signals)
          totalNotifications += notificationResults.size
          console.log(`[Cron] User ${userId.slice(0, 8)}...: ${signals.length} signals, ${notificationResults.size} notifications (tier: ${tier})`)
        } else {
          console.log(`[Cron] User ${userId.slice(0, 8)}...: ${signals.length} signals, alerts limit reached (tier: ${tier})`)
        }
      }
    }
    
    const duration = Date.now() - startTime
    
    console.log(`[Cron] Scan complete in ${duration}ms`)
    console.log(`[Cron] Results: ${filteredResults.length} users, ${totalSignals} signals, ${totalNotifications} notifications`)
    
    return NextResponse.json({
      success: true,
      liveAssets: LIVE_ASSETS,
      usersScanned: filteredResults.length,
      totalSignals,
      signalsByAsset,
      totalNotifications,
      durationMs: duration,
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    console.error('[Cron] Scan error:', error)
    return NextResponse.json(
      { 
        error: 'Scan failed', 
        details: error instanceof Error ? error.message : String(error),
        timestamp: new Date().toISOString()
      },
      { status: 500 }
    )
  }
}

// POST also allowed for manual triggering
export async function POST(request: NextRequest) {
  return GET(request)
}
