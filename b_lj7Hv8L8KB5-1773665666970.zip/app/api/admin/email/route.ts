import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

// Admin email functionality
// Uses Supabase's built-in email service or can be extended with Resend/SendGrid

export async function POST(request: Request) {
  try {
    const supabase = await createClient()
    
    // Check if user is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
    
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single()
    
    if (!profile || profile.role !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }
    
    const body = await request.json()
    const { to, subject, message, userId } = body
    
    if (!subject || !message) {
      return NextResponse.json({ error: "Subject and message are required" }, { status: 400 })
    }
    
    // Get recipient email if userId is provided
    let recipientEmail = to
    if (userId && !to) {
      const { data: recipientProfile } = await supabase
        .from("profiles")
        .select("email")
        .eq("id", userId)
        .single()
      
      recipientEmail = recipientProfile?.email
    }
    
    if (!recipientEmail) {
      return NextResponse.json({ error: "Recipient email not found" }, { status: 400 })
    }
    
    // Log the email attempt (in production, you'd integrate with an email service)
    // For now, we'll use Supabase's auth.admin.inviteUserByEmail as a workaround
    // or store the message in a notifications table
    
    // Store notification in database
    const { error: notifyError } = await supabase
      .from("notifications")
      .insert({
        user_id: userId || null,
        email: recipientEmail,
        subject,
        message,
        type: "admin_email",
        status: "pending",
        created_by: user.id,
      })
    
    if (notifyError) {
      // If notifications table doesn't exist, just log
      console.log("Email to send:", { to: recipientEmail, subject, message })
    }
    
    // In production, integrate with email service:
    // await sendEmail({ to: recipientEmail, subject, html: message })
    
    return NextResponse.json({ 
      success: true, 
      message: `Email queued for ${recipientEmail}`,
      note: "Configure email service (Resend/SendGrid) for actual delivery"
    })
  } catch (error) {
    console.error("Admin email error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to send email" },
      { status: 500 }
    )
  }
}

// Get email history
export async function GET() {
  try {
    const supabase = await createClient()
    
    // Check if user is admin
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }
    
    const { data: profile } = await supabase
      .from("profiles")
      .select("role")
      .eq("id", user.id)
      .single()
    
    if (!profile || profile.role !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }
    
    // Try to fetch from notifications table
    const { data: notifications } = await supabase
      .from("notifications")
      .select("*")
      .eq("type", "admin_email")
      .order("created_at", { ascending: false })
      .limit(50)
    
    return NextResponse.json({ emails: notifications || [] })
  } catch (error) {
    console.error("Get emails error:", error)
    return NextResponse.json({ emails: [] })
  }
}
