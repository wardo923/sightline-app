import { NextRequest, NextResponse } from "next/server"
import { marketDataAdapter } from "@/lib/signal-engine/market-data/adapter"
import { getAssetClass, isAssetSupported } from "@/lib/signal-engine/types"

export const dynamic = "force-dynamic"

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ symbol: string }> }
) {
  try {
    const { symbol } = await params
    const upperSymbol = symbol.toUpperCase()

    // Validate asset
    if (!isAssetSupported(upperSymbol)) {
      return NextResponse.json(
        { error: `Asset ${upperSymbol} is not supported` },
        { status: 400 }
      )
    }

    const assetClass = getAssetClass(upperSymbol)

    // Check if market is open
    const isMarketOpen = await marketDataAdapter.isMarketOpen(upperSymbol)

    // Get latest price data
    const latestBar = await marketDataAdapter.getLatestBar(upperSymbol)

    if (!latestBar) {
      return NextResponse.json(
        { error: "Unable to fetch market data" },
        { status: 503 }
      )
    }

    // Calculate change (simplified - in real app would compare to previous close)
    const change = latestBar.close - latestBar.open
    const changePercent = (change / latestBar.open) * 100

    return NextResponse.json({
      symbol: upperSymbol,
      assetClass,
      price: latestBar.close,
      open: latestBar.open,
      high: latestBar.high,
      low: latestBar.low,
      volume: latestBar.volume,
      change,
      changePercent,
      isMarketOpen,
      lastUpdated: new Date().toISOString(),
    })
  } catch (error) {
    console.error("Market data error:", error)
    return NextResponse.json(
      { error: "Failed to fetch market data" },
      { status: 500 }
    )
  }
}
