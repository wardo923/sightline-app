import { NextResponse } from "next/server"
import { getSnapshots, getBars, isMarketOpen, convertBarsToCandles } from "@/lib/alpaca"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const symbol = searchParams.get("symbol") || "SPY"
    const action = searchParams.get("action") || "snapshot"
    const timeframe = searchParams.get("timeframe") || "1Hour"
    const limit = parseInt(searchParams.get("limit") || "100")
    
    // Determine if crypto
    const cryptoSymbols = ["BTC", "ETH", "SOL", "DOGE", "AVAX", "LINK", "MATIC"]
    const isCrypto = cryptoSymbols.some(c => symbol.toUpperCase().includes(c))
    
    // Adjust symbol format for Alpaca
    const alpacaSymbol = isCrypto 
      ? symbol.toUpperCase().replace("/USD", "") + "/USD"
      : symbol.toUpperCase()
    
    switch (action) {
      case "snapshot": {
        const [snapshots, marketStatus] = await Promise.all([
          getSnapshots([alpacaSymbol], isCrypto),
          isMarketOpen()
        ])
        
        const snapshot = snapshots[alpacaSymbol]
        
        return NextResponse.json({
          symbol: symbol.toUpperCase(),
          price: snapshot?.latestTrade?.price || null,
          change: snapshot?.dailyBar && snapshot?.previousDailyBar
            ? ((snapshot.dailyBar.close - snapshot.previousDailyBar.close) / snapshot.previousDailyBar.close) * 100
            : null,
          high: snapshot?.dailyBar?.high || null,
          low: snapshot?.dailyBar?.low || null,
          volume: snapshot?.dailyBar?.volume || null,
          bid: snapshot?.latestQuote?.bidPrice || null,
          ask: snapshot?.latestQuote?.askPrice || null,
          isMarketOpen: isCrypto ? true : marketStatus.isOpen,
          nextOpen: marketStatus.nextOpen,
          nextClose: marketStatus.nextClose,
          timestamp: new Date().toISOString(),
        })
      }
      
      case "bars": {
        const bars = await getBars(alpacaSymbol, timeframe, limit, isCrypto)
        const candles = convertBarsToCandles(bars)
        
        return NextResponse.json({
          symbol: symbol.toUpperCase(),
          timeframe,
          candles,
          count: candles.length,
        })
      }
      
      case "status": {
        const marketStatus = await isMarketOpen()
        return NextResponse.json(marketStatus)
      }
      
      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    console.error("Market API error:", error)
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to fetch market data" },
      { status: 500 }
    )
  }
}
