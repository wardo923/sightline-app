import { NextResponse } from "next/server"

export async function GET() {
  const resendConfigured = !!process.env.RESEND_API_KEY
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  
  // Check if running on Vercel (production-like)
  const isProduction = !!process.env.VERCEL

  return NextResponse.json({
    resendConfigured,
    supabaseConfigured: !!supabaseUrl,
    isProduction,
    setupInstructions: !resendConfigured ? {
      title: "Email Service Setup Required",
      steps: [
        "1. Create a Resend account at https://resend.com",
        "2. Get your API key from https://resend.com/api-keys",
        "3. Add RESEND_API_KEY to your environment variables in Vercel",
        "4. Configure Supabase to use Resend as SMTP provider:",
        "   - Go to your Supabase project dashboard",
        "   - Navigate to Authentication > Email Templates",
        "   - Click on SMTP Settings",
        "   - Enable 'Use Custom SMTP'",
        "   - Enter Resend SMTP settings:",
        "     Host: smtp.resend.com",
        "     Port: 465",
        "     Username: resend",
        "     Password: [Your Resend API Key]",
        "5. Save and test the configuration"
      ],
      resendDocsUrl: "https://resend.com/docs/send-with-supabase-smtp",
      supabaseDocsUrl: "https://supabase.com/docs/guides/auth/auth-smtp"
    } : null
  })
}
