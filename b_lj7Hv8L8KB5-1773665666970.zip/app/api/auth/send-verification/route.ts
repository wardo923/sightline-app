import { NextRequest, NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"
import { sendVerificationEmail, isEmailConfigured } from "@/lib/email"

export async function POST(request: NextRequest) {
  try {
    // Check if email is configured
    if (!isEmailConfigured()) {
      return NextResponse.json(
        { 
          error: "Email service not configured",
          setupRequired: true,
          setupSteps: [
            "1. Go to https://resend.com and create an account",
            "2. Create an API key at https://resend.com/api-keys",
            "3. Add RESEND_API_KEY to your environment variables",
            "4. (Optional) Add a verified domain and set RESEND_FROM_EMAIL"
          ]
        },
        { status: 503 }
      )
    }

    const { email, name, token, redirectTo } = await request.json()

    if (!email || !token) {
      return NextResponse.json(
        { error: "Email and token are required" },
        { status: 400 }
      )
    }

    // Build verification URL
    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 
                    process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 
                    "http://localhost:3000"
    
    const verificationUrl = `${baseUrl}/auth/confirm?token=${token}&type=signup&redirect_to=${encodeURIComponent(redirectTo || "/auth/post-login")}`

    // Send the verification email
    const result = await sendVerificationEmail(email, verificationUrl, name)

    if (!result.success) {
      return NextResponse.json(
        { error: result.error || "Failed to send verification email" },
        { status: 500 }
      )
    }

    return NextResponse.json({ 
      success: true, 
      message: "Verification email sent",
      messageId: result.messageId 
    })
  } catch (error) {
    console.error("[v0] Send verification error:", error)
    return NextResponse.json(
      { error: "Failed to send verification email" },
      { status: 500 }
    )
  }
}

// Resend verification email
export async function PUT(request: NextRequest) {
  try {
    if (!isEmailConfigured()) {
      return NextResponse.json(
        { error: "Email service not configured", setupRequired: true },
        { status: 503 }
      )
    }

    const { email } = await request.json()

    if (!email) {
      return NextResponse.json(
        { error: "Email is required" },
        { status: 400 }
      )
    }

    // Use Supabase to resend the confirmation email
    const supabase = await createClient()
    
    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 
                    process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : 
                    "http://localhost:3000"

    const { error } = await supabase.auth.resend({
      type: "signup",
      email,
      options: {
        emailRedirectTo: `${baseUrl}/auth/callback`,
      },
    })

    if (error) {
      // If Supabase resend fails, it might be because the user is already confirmed
      // or there's a rate limit
      return NextResponse.json(
        { error: error.message },
        { status: 400 }
      )
    }

    return NextResponse.json({ 
      success: true, 
      message: "Verification email resent" 
    })
  } catch (error) {
    console.error("[v0] Resend verification error:", error)
    return NextResponse.json(
      { error: "Failed to resend verification email" },
      { status: 500 }
    )
  }
}
