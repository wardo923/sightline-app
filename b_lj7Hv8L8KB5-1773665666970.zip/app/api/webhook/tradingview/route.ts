import { NextRequest, NextResponse } from "next/server"

// TradingView webhook payload structure
interface TradingViewSignal {
  symbol: string           // e.g., "SPY", "QQQ", "BTCUSD"
  action: "BUY" | "SELL"
  entry: number
  stop: number
  target: number
  timeframe: string        // e.g., "15m", "1h", "4h", "1D"
  pattern: string          // e.g., "Break & Retest", "Momentum Breakout", "Reversal"
  timestamp: string
  secret?: string          // Optional secret for verification
}

// This would come from Supabase in production
// For now, we'll use localStorage data passed from client
interface UserProfile {
  id: string
  email: string
  phone?: string
  name: string
  preferences: {
    markets: string[]           // ["SPY", "QQQ", "BTC", "ETH", "SOL"]
    behavior: string            // "Stable", "Balanced", "High Momentum"
    patterns: string[]          // ["Break & Retest", "Momentum Breakout", "Reversal"]
    activityLevel: string       // "Conservative", "Balanced", "Aggressive"
    timeframe: string           // "15m", "1h", "4h", "Daily"
    alertHours: string          // "Market Hours", "24/7"
    riskPreference: string      // "Standard", "Tighter Stops", "Wider Stops"
  }
  notifications: {
    email: boolean
    sms: boolean
    push: boolean
    inApp: boolean
  }
}

// Verify the webhook secret (set this in TradingView alert message)
const WEBHOOK_SECRET = process.env.TRADINGVIEW_WEBHOOK_SECRET || "your-secret-key"

export async function POST(request: NextRequest) {
  try {
    const signal: TradingViewSignal = await request.json()
    
    // Verify webhook secret
    if (signal.secret !== WEBHOOK_SECRET) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    console.log("[v0] Received TradingView signal:", signal)

    // TODO: Fetch users from Supabase whose preferences match this signal
    // For now, this is a placeholder that shows the matching logic
    
    // Example: Fetch matching users from Supabase
    // const { data: users } = await supabase
    //   .from('user_profiles')
    //   .select('*')
    //   .contains('preferences->markets', [normalizeSymbol(signal.symbol)])
    
    // For demonstration, we'll return the signal processing result
    const processedSignal = {
      ...signal,
      riskReward: calculateRiskReward(signal),
      normalizedSymbol: normalizeSymbol(signal.symbol),
      processedAt: new Date().toISOString(),
    }

    // TODO: Send notifications to matching users
    // await sendNotifications(matchingUsers, processedSignal)

    return NextResponse.json({ 
      success: true, 
      message: "Signal received and processed",
      signal: processedSignal 
    })

  } catch (error) {
    console.error("[v0] Webhook error:", error)
    return NextResponse.json({ error: "Failed to process signal" }, { status: 500 })
  }
}

// Normalize symbol (BTCUSD -> BTC, ETHUSD -> ETH, etc.)
function normalizeSymbol(symbol: string): string {
  const mapping: Record<string, string> = {
    "BTCUSD": "BTC",
    "ETHUSD": "ETH",
    "SOLUSD": "SOL",
    "BTCUSDT": "BTC",
    "ETHUSDT": "ETH",
    "SOLUSDT": "SOL",
  }
  return mapping[symbol.toUpperCase()] || symbol.toUpperCase()
}

// Calculate risk/reward ratio
function calculateRiskReward(signal: TradingViewSignal): string {
  const risk = Math.abs(signal.entry - signal.stop)
  const reward = Math.abs(signal.target - signal.entry)
  const ratio = reward / risk
  return `1:${ratio.toFixed(1)}`
}
