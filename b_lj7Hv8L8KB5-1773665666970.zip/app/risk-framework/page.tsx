import { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"
import { Shield, Scale, BarChart2, Target, TrendingUp } from "lucide-react"

export const metadata: Metadata = {
  title: "Risk Framework - SightLine",
  description: "SightLine emphasizes structured setups with defined risk rather than prediction.",
}

const riskPrinciples = [
  {
    icon: Shield,
    title: "Risk-First Mindset",
    description: "Evaluate downside risk before considering potential reward.",
  },
  {
    icon: Scale,
    title: "Risk-to-Reward Ratio",
    description: "Assess setups based on reward relative to defined risk.",
  },
  {
    icon: BarChart2,
    title: "Probability, Not Certainty",
    description: "Trading outcomes are probabilistic rather than guaranteed.",
  },
  {
    icon: Target,
    title: "Disciplined Execution",
    description: "Follow structured risk parameters when managing positions.",
  },
  {
    icon: TrendingUp,
    title: "Statistical Edge",
    description: "Seek consistency through structured setups over time.",
  },
]

const riskScenarios = [
  { winRate: "40%", riskReward: "2R", scenario: "Illustrative positive expectancy scenario" },
  { winRate: "45%", riskReward: "2R", scenario: "Illustrative positive expectancy scenario" },
  { winRate: "50%", riskReward: "2R", scenario: "Illustrative positive expectancy scenario" },
]

export default function RiskFrameworkPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <p className="mb-4 text-xs font-semibold tracking-widest text-primary uppercase">
            Risk Management
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            Risk-Reward Framework
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground text-pretty">
            SightLine emphasizes structured setups with defined risk rather than prediction.
          </p>
        </div>
      </section>

      {/* Risk Principles */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {riskPrinciples.map((principle) => (
              <div
                key={principle.title}
                className="rounded-2xl border border-border/50 bg-card/50 p-6 text-center card-glow transition-all hover:border-primary/30"
              >
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <principle.icon className="h-7 w-7" />
                </div>
                <h2 className="text-lg font-semibold text-foreground mb-2">
                  {principle.title}
                </h2>
                <p className="text-sm text-muted-foreground">
                  {principle.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Risk-Reward Scenarios */}
      <section className="section-glow-top grid-bg py-20 md:py-28">
        <div className="mx-auto max-w-4xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              Illustrative Risk-Reward Scenarios
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-base text-muted-foreground text-pretty">
              Understanding how win rate and risk-reward interact over time.
            </p>
          </div>

          <div className="rounded-2xl border border-border bg-card overflow-hidden">
            <div className="grid grid-cols-3 gap-4 p-4 border-b border-border bg-muted/30">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Win Rate</span>
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Risk-Reward</span>
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Scenario</span>
            </div>
            {riskScenarios.map((scenario, idx) => (
              <div 
                key={idx} 
                className={`grid grid-cols-3 gap-4 p-4 ${idx < riskScenarios.length - 1 ? "border-b border-border" : ""}`}
              >
                <span className="text-base font-semibold text-foreground">{scenario.winRate}</span>
                <span className="text-base font-semibold text-primary">{scenario.riskReward}</span>
                <span className="text-sm text-muted-foreground">{scenario.scenario}</span>
              </div>
            ))}
          </div>

          <p className="mt-8 text-center text-xs text-muted-foreground/70">
            Illustrative scenarios shown for educational purposes only and do not represent actual trading performance or guaranteed outcomes.
          </p>
        </div>
      </section>

      {/* How Risk Management Works */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-4xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              How SightLine Approaches Risk
            </h2>
          </div>

          <div className="space-y-6">
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-lg font-semibold text-foreground mb-3">Define Before You Trade</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Every setup highlighted by SightLine includes defined entry, stop loss, and target levels. This allows you to understand your potential risk before entering any position.
              </p>
            </div>
            
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-lg font-semibold text-foreground mb-3">Position Sizing Awareness</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Understanding the distance to your stop loss helps inform appropriate position sizing based on your personal risk tolerance.
              </p>
            </div>
            
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-lg font-semibold text-foreground mb-3">No Guaranteed Outcomes</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Trading involves substantial risk. SightLine provides structured analysis tools but cannot guarantee profitable outcomes. All trading decisions are your responsibility.
              </p>
            </div>
          </div>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
