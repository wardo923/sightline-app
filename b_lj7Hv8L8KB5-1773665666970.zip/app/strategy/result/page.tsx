"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import Link from "next/link"
import { 
  TrendingUp, 
  ArrowDownUp, 
  Target, 
  Clock, 
  Zap,
  Layers,
  ChevronRight,
  Shield,
  CheckCircle2,
  BarChart3
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { STRATEGY_INFO, StrategyKey } from "@/lib/strategies"

// Strategy icons mapping
const STRATEGY_ICONS: Record<StrategyKey, typeof TrendingUp> = {
  MOMENTUM_BREAKOUT: TrendingUp,
  LIQUIDITY_REVERSAL: ArrowDownUp,
  STRUCTURE_REACTION: Target,
  OPENING_RANGE: Clock,
  VOLATILITY_EXPANSION: Zap,
  SESSION_STRUCTURE: Layers
}

interface StrategyData {
  bundle_name: string
  secondary_bundle: string | null
  confidence_score: number
  asset: string
  market_type: string
  timeframe: string
  wizard_answers: Record<string, string>
}

export default function StrategyResultPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const strategyId = searchParams.get("id")
  
  const [strategy, setStrategy] = useState<StrategyData | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [showContent, setShowContent] = useState(false)

  useEffect(() => {
    async function loadStrategy() {
      if (!strategyId) {
        router.push("/strategy-wizard")
        return
      }

      const supabase = createClient()
      const { data, error } = await supabase
        .from("strategies")
        .select("bundle_name, secondary_bundle, confidence_score, asset, market_type, timeframe, wizard_answers")
        .eq("id", strategyId)
        .single()

      if (error || !data) {
        router.push("/strategy-wizard")
        return
      }

      setStrategy(data)
      setIsLoading(false)
      
      // Delay showing content for animation
      setTimeout(() => setShowContent(true), 100)
    }

    loadStrategy()
  }, [strategyId, router])

  if (isLoading || !strategy) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="h-12 w-12 mx-auto rounded-full border-2 border-primary border-t-transparent animate-spin" />
          <p className="text-muted-foreground">Loading your strategy...</p>
        </div>
      </div>
    )
  }

  const strategyKey = strategy.bundle_name as StrategyKey
  const info = STRATEGY_INFO[strategyKey]
  const Icon = STRATEGY_ICONS[strategyKey] || TrendingUp
  const secondaryInfo = strategy.secondary_bundle ? STRATEGY_INFO[strategy.secondary_bundle as StrategyKey] : null
  const SecondaryIcon = strategy.secondary_bundle ? STRATEGY_ICONS[strategy.secondary_bundle as StrategyKey] : null

  // Calculate Strategy Fit (72-96% display range)
  // Maps raw confidence (0-100) to display range (72-96)
  // Higher raw scores = higher Strategy Fit
  const rawScore = strategy.confidence_score
  const strategyFit = Math.min(96, Math.max(72, Math.round(72 + (rawScore / 100) * 24)))
  
  // Determine fit level for display
  // 72-81% = Moderate Fit, 82-90% = Strong Fit, 91-96% = Very Strong Fit
  const fitLevel = strategyFit >= 91 ? "Very Strong Fit" : strategyFit >= 82 ? "Strong Fit" : "Moderate Fit"

  // Generate "Why this strategy" reasons based on wizard answers
  const whyReasons = generateWhyReasons(strategy.wizard_answers, strategyKey)

  return (
    <div className="min-h-screen bg-background pb-safe">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 pt-safe">
        <div className="flex h-14 items-center justify-between px-4">
          <Link href="/" className="text-lg font-bold text-foreground">
            SightLine
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-2xl px-4 py-8">
        {/* Success Badge */}
        <div className={`text-center mb-8 transition-all duration-500 ${showContent ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
          <div className="inline-flex items-center gap-2 rounded-full bg-primary/10 border border-primary/20 px-4 py-2 text-sm font-medium text-primary">
            <CheckCircle2 className="h-4 w-4" />
            Strategy Generated
          </div>
        </div>

        {/* Main Strategy Card */}
        <div className={`rounded-2xl border border-border bg-card p-6 mb-6 transition-all duration-700 delay-100 ${showContent ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
          {/* Primary Match Label */}
          <p className="text-xs text-muted-foreground mb-2">Primary Match</p>
          
          <div className="flex items-start gap-4 mb-6">
            <div className="rounded-xl bg-primary/10 p-3">
              <Icon className="h-8 w-8 text-primary" />
            </div>
            <div className="flex-1">
              <h1 className="text-2xl font-bold text-foreground">{info.name}</h1>
              <p className="text-sm text-muted-foreground mt-1">{info.description}</p>
            </div>
          </div>

          {/* Strategy Fit */}
          <div className="rounded-xl bg-muted/50 p-4 mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-foreground">Strategy Fit</span>
              <div className="text-right">
                <span className="text-lg font-bold text-primary">{strategyFit}%</span>
                <span className="text-xs text-muted-foreground ml-2">{fitLevel}</span>
              </div>
            </div>
            <div className="h-2 rounded-full bg-muted overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full transition-all duration-1000 delay-500"
                style={{ width: showContent ? `${strategyFit}%` : "0%" }}
              />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Strategy Fit reflects how strongly your profile aligned with this framework based on your responses.
            </p>
          </div>

          {/* Why This Strategy */}
          <div className="space-y-3 mb-6">
            <h3 className="text-sm font-semibold text-foreground">Why This Strategy</h3>
            <ul className="space-y-2">
              {whyReasons.map((reason, i) => (
                <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <CheckCircle2 className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                  {reason}
                </li>
              ))}
            </ul>
          </div>

          {/* Strategy Parameters */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            <div className="rounded-xl bg-muted/50 p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Asset</p>
              <p className="text-sm font-semibold text-foreground">{strategy.asset}</p>
            </div>
            <div className="rounded-xl bg-muted/50 p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Timeframe</p>
              <p className="text-sm font-semibold text-foreground">{strategy.timeframe}</p>
            </div>
            <div className="rounded-xl bg-muted/50 p-3 text-center">
              <p className="text-xs text-muted-foreground mb-1">Market</p>
              <p className="text-sm font-semibold text-foreground">{strategy.market_type}</p>
            </div>
          </div>

          {/* Best For */}
          <div className="rounded-xl border border-border p-4">
            <h3 className="text-sm font-semibold text-foreground mb-2">Best For</h3>
            <p className="text-sm text-muted-foreground">{info.bestFor}</p>
          </div>
        </div>

        {/* Secondary Match */}
        {secondaryInfo && SecondaryIcon && (
          <div className={`rounded-2xl border border-border bg-card/50 p-5 mb-6 transition-all duration-700 delay-300 ${showContent ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
            <p className="text-xs text-muted-foreground mb-3">Secondary Match</p>
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-muted p-2">
                <SecondaryIcon className="h-5 w-5 text-muted-foreground" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">{secondaryInfo.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{secondaryInfo.description}</p>
              </div>
            </div>
          </div>
        )}

        {/* Disclaimer */}
        <div className={`rounded-xl bg-amber-500/10 border border-amber-500/20 p-4 mb-8 transition-all duration-700 delay-400 ${showContent ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
          <div className="flex items-start gap-3">
            <Shield className="h-5 w-5 text-amber-500 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-medium text-amber-500 mb-1">Educational Only</p>
              <p className="text-xs text-muted-foreground">
                SightLine strategies are analytical frameworks, not investment advice. 
                Always do your own research and manage your own risk.
              </p>
            </div>
          </div>
        </div>

        {/* CTA */}
        <div className={`space-y-3 transition-all duration-700 delay-500 ${showContent ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"}`}>
          <Link
            href="/dashboard"
            className="flex items-center justify-center gap-2 w-full rounded-xl bg-primary py-4 text-base font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
          >
            Go to Dashboard
            <ChevronRight className="h-5 w-5" />
          </Link>
          <Link
            href="/strategy-wizard"
            className="flex items-center justify-center w-full rounded-xl border border-border py-3 text-sm font-medium text-muted-foreground hover:text-foreground hover:border-foreground/20 transition-colors"
          >
            Retake Wizard
          </Link>
        </div>
      </main>
    </div>
  )
}

// Generate "Why this strategy" reasons based on wizard answers
function generateWhyReasons(answers: Record<string, string>, strategy: StrategyKey): string[] {
  const reasons: string[] = []
  
  const styleMap: Record<string, string> = {
    "Breakouts and momentum moves": "You prefer breakout and momentum trading",
    "Reversals after failed moves": "You look for reversal opportunities after failed moves",
    "Support and resistance reactions": "You trade reactions at key support/resistance levels",
    "Session structure and level interactions": "You focus on session-based structure and levels"
  }
  
  if (answers.style && styleMap[answers.style]) {
    reasons.push(styleMap[answers.style])
  }
  
  if (answers.timeframe) {
    reasons.push(`Your ${answers.timeframe} timeframe aligns with this strategy's optimal range`)
  }
  
  if (answers.trade_frequency) {
    const freqMap: Record<string, string> = {
      "Selective (fewer, higher quality)": "Selective trading matches the strategy's quality-over-quantity approach",
      "Moderate activity": "Moderate activity suits this strategy's signal frequency",
      "More active opportunities": "Active trading matches this strategy's signal generation"
    }
    if (freqMap[answers.trade_frequency]) {
      reasons.push(freqMap[answers.trade_frequency])
    }
  }
  
  if (answers.decision_style) {
    reasons.push(`Your decision style aligns with how this strategy identifies entries`)
  }
  
  // Add strategy-specific reason
  const strategyReasons: Record<StrategyKey, string> = {
    MOMENTUM_BREAKOUT: "This strategy excels at capturing momentum expansion moves",
    LIQUIDITY_REVERSAL: "This strategy specializes in identifying liquidity grabs and reversals",
    STRUCTURE_REACTION: "This strategy focuses on high-probability reactions at structure levels",
    OPENING_RANGE: "This strategy leverages opening range dynamics for intraday setups",
    VOLATILITY_EXPANSION: "This strategy captures volatility expansion after consolidation",
    SESSION_STRUCTURE: "This strategy uses session-based levels for structured entries"
  }
  
  if (strategyReasons[strategy]) {
    reasons.push(strategyReasons[strategy])
  }
  
  return reasons.slice(0, 5)
}
