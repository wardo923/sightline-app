"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import {
  Crosshair,
  Users,
  CreditCard,
  BarChart3,
  TrendingUp,
  Activity,
  ChevronRight,
  Search,
  ArrowUpDown,
  X,
  Calendar,
  Target,
  Zap,
  Mail,
  Send,
  Loader2,
} from "lucide-react"

interface User {
  id: string
  full_name: string | null
  email: string
  role: string
  created_at: string
  strategies_count: number
  signals_count: number
  subscription?: {
    plan: string
    status: string
    stripe_customer_id: string | null
    stripe_subscription_id: string | null
  }
}

interface Subscription {
  id: string
  user_id: string
  plan: string
  status: string
  stripe_customer_id: string | null
  stripe_subscription_id: string | null
  created_at: string
  user?: {
    full_name: string | null
    email: string
  }
}

interface Stats {
  totalUsers: number
  activeSubscriptions: number
  starterPlanUsers: number
  proPlanUsers: number
  elitePlanUsers: number
  totalSignals: number
  signalsToday: number
  activeSignals: number
  signalsThisWeek: number
  signalsBySetupType: { setup_type: string; count: number }[]
}

export default function AdminDashboard() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [isAdmin, setIsAdmin] = useState(false)
  const [stats, setStats] = useState<Stats | null>(null)
  const [users, setUsers] = useState<User[]>([])
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([])
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [searchQuery, setSearchQuery] = useState("")
  const [sortBy, setSortBy] = useState<"newest" | "plan" | "signals">("newest")
  const [activeTab, setActiveTab] = useState<"overview" | "users" | "subscriptions" | "signals" | "email">("overview")
  const [emailSubject, setEmailSubject] = useState("")
  const [emailMessage, setEmailMessage] = useState("")
  const [emailRecipient, setEmailRecipient] = useState("")
  const [isSendingEmail, setIsSendingEmail] = useState(false)
  const [emailStatus, setEmailStatus] = useState<{ type: "success" | "error"; message: string } | null>(null)

  useEffect(() => {
    async function loadAdminData() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      // Check admin role
      const { data: profile } = await supabase
        .from("profiles")
        .select("role")
        .eq("id", user.id)
        .single()

      if (!profile || profile.role !== "admin") {
        router.push("/dashboard")
        return
      }

      setIsAdmin(true)

      // Fetch all data
      await Promise.all([
        fetchStats(supabase),
        fetchUsers(supabase),
        fetchSubscriptions(supabase),
      ])

      setIsLoading(false)
    }

    loadAdminData()
  }, [router])

  async function fetchStats(supabase: ReturnType<typeof createClient>) {
    // Get total users
    const { count: totalUsers } = await supabase
      .from("profiles")
      .select("*", { count: "exact", head: true })

    // Get subscriptions by plan
    const { data: subs } = await supabase
      .from("subscriptions")
      .select("plan, status")

    const activeSubs = subs?.filter(s => s.status === "active") || []
    const starterPlanUsers = activeSubs.filter(s => s.plan === "starter").length
    const proPlanUsers = activeSubs.filter(s => s.plan === "pro").length
    const elitePlanUsers = activeSubs.filter(s => s.plan === "elite").length

    // Get signal counts
    const { count: totalSignals } = await supabase
      .from("signals")
      .select("*", { count: "exact", head: true })

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const { count: signalsToday } = await supabase
      .from("signals")
      .select("*", { count: "exact", head: true })
      .gte("created_at", today.toISOString())

    const { count: activeSignals } = await supabase
      .from("signals")
      .select("*", { count: "exact", head: true })
      .in("status", ["pending", "active"])

    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)
    
    const { count: signalsThisWeek } = await supabase
      .from("signals")
      .select("*", { count: "exact", head: true })
      .gte("created_at", weekAgo.toISOString())

    // Get signals by setup type
    const { data: signalsByType } = await supabase
      .from("signals")
      .select("setup_type")

    const setupTypeCounts: Record<string, number> = {}
    signalsByType?.forEach(s => {
      const type = s.setup_type || "Unknown"
      setupTypeCounts[type] = (setupTypeCounts[type] || 0) + 1
    })

    const signalsBySetupType = Object.entries(setupTypeCounts).map(([setup_type, count]) => ({
      setup_type,
      count,
    })).sort((a, b) => b.count - a.count)

    setStats({
      totalUsers: totalUsers || 0,
      activeSubscriptions: activeSubs.length,
      starterPlanUsers,
      proPlanUsers,
      elitePlanUsers,
      totalSignals: totalSignals || 0,
      signalsToday: signalsToday || 0,
      activeSignals: activeSignals || 0,
      signalsThisWeek: signalsThisWeek || 0,
      signalsBySetupType,
    })
  }

  async function fetchUsers(supabase: ReturnType<typeof createClient>) {
    // Get all users with their auth emails
    const { data: profiles } = await supabase
      .from("profiles")
      .select("*")
      .order("created_at", { ascending: false })

    if (!profiles) return

    // Get strategies count per user
    const { data: strategies } = await supabase
      .from("strategies")
      .select("user_id")

    // Get signals count per user
    const { data: signals } = await supabase
      .from("signals")
      .select("user_id")

    // Get subscriptions
    const { data: subs } = await supabase
      .from("subscriptions")
      .select("*")

    const strategiesByUser: Record<string, number> = {}
    strategies?.forEach(s => {
      strategiesByUser[s.user_id] = (strategiesByUser[s.user_id] || 0) + 1
    })

    const signalsByUser: Record<string, number> = {}
    signals?.forEach(s => {
      signalsByUser[s.user_id] = (signalsByUser[s.user_id] || 0) + 1
    })

    const subsByUser: Record<string, Subscription> = {}
    subs?.forEach(s => {
      subsByUser[s.user_id] = s
    })

    const usersData: User[] = profiles.map(p => ({
      id: p.id,
      full_name: p.full_name,
      email: p.email || "No email",
      role: p.role || "user",
      created_at: p.created_at,
      strategies_count: strategiesByUser[p.id] || 0,
      signals_count: signalsByUser[p.id] || 0,
      subscription: subsByUser[p.id] ? {
        plan: subsByUser[p.id].plan,
        status: subsByUser[p.id].status,
        stripe_customer_id: subsByUser[p.id].stripe_customer_id,
        stripe_subscription_id: subsByUser[p.id].stripe_subscription_id,
      } : undefined,
    }))

    setUsers(usersData)
  }

  async function fetchSubscriptions(supabase: ReturnType<typeof createClient>) {
    const { data: subs } = await supabase
      .from("subscriptions")
      .select("*")
      .order("created_at", { ascending: false })

    if (!subs) return

    // Get user info for subscriptions
    const { data: profiles } = await supabase
      .from("profiles")
      .select("id, full_name, email")

    const profilesById: Record<string, { full_name: string | null; email: string }> = {}
    profiles?.forEach(p => {
      profilesById[p.id] = { full_name: p.full_name, email: p.email || "No email" }
    })

    const subsWithUsers: Subscription[] = subs.map(s => ({
      ...s,
      user: profilesById[s.user_id],
    }))

    setSubscriptions(subsWithUsers)
  }

  const filteredUsers = users
    .filter(user => {
      if (!searchQuery) return true
      const query = searchQuery.toLowerCase()
      return (
        user.full_name?.toLowerCase().includes(query) ||
        user.email.toLowerCase().includes(query)
      )
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "newest":
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        case "plan":
          const planOrder = { elite: 0, pro: 1, starter: 2, none: 3 }
          const aPlan = a.subscription?.plan || "none"
          const bPlan = b.subscription?.plan || "none"
          return (planOrder[aPlan as keyof typeof planOrder] || 3) - (planOrder[bPlan as keyof typeof planOrder] || 3)
        case "signals":
          return b.signals_count - a.signals_count
        default:
          return 0
      }
    })

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  if (!isAdmin) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-6">
          <div className="flex items-center gap-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Crosshair className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="text-lg font-bold text-foreground">SightLine</span>
            </Link>
            <span className="rounded-md bg-primary/10 px-2 py-1 text-xs font-semibold text-primary">
              Admin
            </span>
          </div>
          <Link
            href="/dashboard"
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Back to Dashboard
          </Link>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="hidden lg:block w-64 border-r border-border min-h-[calc(100vh-4rem)] p-4">
          <nav className="space-y-1">
            {[
              { id: "overview", label: "Overview", icon: BarChart3 },
              { id: "users", label: "Users", icon: Users },
              { id: "subscriptions", label: "Subscriptions", icon: CreditCard },
              { id: "signals", label: "Signal Activity", icon: Activity },
              { id: "email", label: "Email Users", icon: Mail },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as typeof activeTab)}
                className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  activeTab === item.id
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                }`}
              >
                <item.icon className="h-4 w-4" />
                {item.label}
              </button>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Mobile Tabs */}
          <div className="lg:hidden flex gap-2 mb-6 overflow-x-auto pb-2">
            {[
              { id: "overview", label: "Overview" },
              { id: "users", label: "Users" },
              { id: "subscriptions", label: "Subs" },
              { id: "signals", label: "Signals" },
              { id: "email", label: "Email" },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id as typeof activeTab)}
                className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                  activeTab === item.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-card text-muted-foreground border border-border"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Overview Tab */}
          {activeTab === "overview" && stats && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-foreground">Platform Overview</h1>

              {/* User Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
                <StatCard
                  label="Total Users"
                  value={stats.totalUsers}
                  icon={Users}
                />
                <StatCard
                  label="Active Subs"
                  value={stats.activeSubscriptions}
                  icon={CreditCard}
                  variant="success"
                />
                <StatCard
                  label="Starter Plan"
                  value={stats.starterPlanUsers}
                  icon={Zap}
                />
                <StatCard
                  label="Pro Plan"
                  value={stats.proPlanUsers}
                  icon={TrendingUp}
                  variant="primary"
                />
                <StatCard
                  label="Elite Plan"
                  value={stats.elitePlanUsers}
                  icon={Target}
                  variant="warning"
                />
              </div>

              {/* Signal Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard
                  label="Total Signals"
                  value={stats.totalSignals}
                  icon={Activity}
                />
                <StatCard
                  label="Signals Today"
                  value={stats.signalsToday}
                  icon={Calendar}
                  variant="primary"
                />
                <StatCard
                  label="Active Signals"
                  value={stats.activeSignals}
                  icon={Zap}
                  variant="success"
                />
                <StatCard
                  label="This Week"
                  value={stats.signalsThisWeek}
                  icon={BarChart3}
                />
              </div>

              {/* Signals by Setup Type */}
              {stats.signalsBySetupType.length > 0 && (
                <div className="rounded-xl border border-border bg-card p-5">
                  <h3 className="text-sm font-semibold text-foreground mb-4">Signals by Setup Type</h3>
                  <div className="space-y-3">
                    {stats.signalsBySetupType.map((item) => (
                      <div key={item.setup_type} className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">{item.setup_type}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-primary rounded-full"
                              style={{
                                width: `${Math.min((item.count / stats.totalSignals) * 100, 100)}%`,
                              }}
                            />
                          </div>
                          <span className="text-sm font-medium text-foreground w-12 text-right">
                            {item.count}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Users Tab */}
          {activeTab === "users" && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <h1 className="text-2xl font-bold text-foreground">Users</h1>
                <div className="flex items-center gap-3">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <input
                      type="text"
                      placeholder="Search users..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="h-10 pl-10 pr-4 rounded-lg border border-border bg-card text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
                    className="h-10 px-3 rounded-lg border border-border bg-card text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  >
                    <option value="newest">Newest</option>
                    <option value="plan">By Plan</option>
                    <option value="signals">By Signals</option>
                  </select>
                </div>
              </div>

              {/* Users Table */}
              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Name</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Email</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Plan</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Created</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Strategies</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Signals</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {filteredUsers.map((user) => (
                        <tr
                          key={user.id}
                          onClick={() => setSelectedUser(user)}
                          className="hover:bg-muted/30 cursor-pointer transition-colors"
                        >
                          <td className="px-4 py-3">
                            <span className="text-sm font-medium text-foreground">
                              {user.full_name || "No name"}
                            </span>
                            {user.role === "admin" && (
                              <span className="ml-2 text-[10px] font-semibold text-primary bg-primary/10 px-1.5 py-0.5 rounded">
                                ADMIN
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">{user.email}</td>
                          <td className="px-4 py-3">
                            <PlanBadge plan={user.subscription?.plan} />
                          </td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">
                            {new Date(user.created_at).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 text-sm text-foreground">{user.strategies_count}</td>
                          <td className="px-4 py-3 text-sm text-foreground">{user.signals_count}</td>
                          <td className="px-4 py-3">
                            <StatusBadge status={user.subscription?.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Subscriptions Tab */}
          {activeTab === "subscriptions" && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-foreground">Subscriptions</h1>

              <div className="rounded-xl border border-border bg-card overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border bg-muted/30">
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">User</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Plan</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Status</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Stripe Customer</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Subscription ID</th>
                        <th className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wider">Created</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {subscriptions.map((sub) => (
                        <tr key={sub.id} className="hover:bg-muted/30">
                          <td className="px-4 py-3">
                            <div>
                              <p className="text-sm font-medium text-foreground">
                                {sub.user?.full_name || "No name"}
                              </p>
                              <p className="text-xs text-muted-foreground">{sub.user?.email}</p>
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <PlanBadge plan={sub.plan} />
                          </td>
                          <td className="px-4 py-3">
                            <StatusBadge status={sub.status} />
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground font-mono">
                            {sub.stripe_customer_id || "-"}
                          </td>
                          <td className="px-4 py-3 text-xs text-muted-foreground font-mono">
                            {sub.stripe_subscription_id || "-"}
                          </td>
                          <td className="px-4 py-3 text-sm text-muted-foreground">
                            {new Date(sub.created_at).toLocaleDateString()}
                          </td>
                        </tr>
                      ))}
                      {subscriptions.length === 0 && (
                        <tr>
                          <td colSpan={6} className="px-4 py-8 text-center text-sm text-muted-foreground">
                            No subscriptions yet
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Signals Tab */}
          {activeTab === "signals" && stats && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-foreground">Signal Activity</h1>

              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard
                  label="Signals Today"
                  value={stats.signalsToday}
                  icon={Calendar}
                  variant="primary"
                />
                <StatCard
                  label="This Week"
                  value={stats.signalsThisWeek}
                  icon={BarChart3}
                />
                <StatCard
                  label="Active Signals"
                  value={stats.activeSignals}
                  icon={Zap}
                  variant="success"
                />
                <StatCard
                  label="Total Generated"
                  value={stats.totalSignals}
                  icon={Activity}
                />
              </div>

              {/* Signals by Setup Type */}
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-4">Signals by Setup Type</h3>
                {stats.signalsBySetupType.length > 0 ? (
                  <div className="space-y-3">
                    {stats.signalsBySetupType.map((item) => (
                      <div key={item.setup_type} className="flex items-center justify-between">
                        <span className="text-sm text-muted-foreground">{item.setup_type}</span>
                        <div className="flex items-center gap-3">
                          <div className="w-48 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-primary rounded-full"
                              style={{
                                width: `${Math.min((item.count / stats.totalSignals) * 100, 100)}%`,
                              }}
                            />
                          </div>
                          <span className="text-sm font-medium text-foreground w-16 text-right">
                            {item.count} ({Math.round((item.count / stats.totalSignals) * 100)}%)
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">No signals generated yet</p>
                )}
              </div>
            </div>
          )}

          {/* Email Tab */}
          {activeTab === "email" && (
            <div className="space-y-6">
              <h1 className="text-2xl font-bold text-foreground">Email Users</h1>

              <div className="grid lg:grid-cols-2 gap-6">
                {/* Compose Email */}
                <div className="rounded-xl border border-border bg-card p-5">
                  <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Compose Email
                  </h3>
                  
                  <form
                    onSubmit={async (e) => {
                      e.preventDefault()
                      setIsSendingEmail(true)
                      setEmailStatus(null)
                      
                      try {
                        const res = await fetch("/api/admin/email", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({
                            to: emailRecipient,
                            subject: emailSubject,
                            message: emailMessage,
                          }),
                        })
                        
                        const data = await res.json()
                        
                        if (res.ok) {
                          setEmailStatus({ type: "success", message: data.message })
                          setEmailSubject("")
                          setEmailMessage("")
                          setEmailRecipient("")
                        } else {
                          setEmailStatus({ type: "error", message: data.error })
                        }
                      } catch {
                        setEmailStatus({ type: "error", message: "Failed to send email" })
                      } finally {
                        setIsSendingEmail(false)
                      }
                    }}
                    className="space-y-4"
                  >
                    <div>
                      <label className="text-xs text-muted-foreground block mb-1.5">Recipient Email</label>
                      <input
                        type="email"
                        value={emailRecipient}
                        onChange={(e) => setEmailRecipient(e.target.value)}
                        placeholder="user@example.com"
                        className="w-full h-10 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="text-xs text-muted-foreground block mb-1.5">Subject</label>
                      <input
                        type="text"
                        value={emailSubject}
                        onChange={(e) => setEmailSubject(e.target.value)}
                        placeholder="Email subject"
                        className="w-full h-10 px-3 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        required
                      />
                    </div>
                    
                    <div>
                      <label className="text-xs text-muted-foreground block mb-1.5">Message</label>
                      <textarea
                        value={emailMessage}
                        onChange={(e) => setEmailMessage(e.target.value)}
                        placeholder="Type your message here..."
                        rows={6}
                        className="w-full px-3 py-2 rounded-lg border border-border bg-background text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
                        required
                      />
                    </div>
                    
                    {emailStatus && (
                      <div
                        className={`p-3 rounded-lg text-sm ${
                          emailStatus.type === "success"
                            ? "bg-green-500/10 text-green-500"
                            : "bg-red-500/10 text-red-500"
                        }`}
                      >
                        {emailStatus.message}
                      </div>
                    )}
                    
                    <button
                      type="submit"
                      disabled={isSendingEmail}
                      className="w-full h-10 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                    >
                      {isSendingEmail ? (
                        <>
                          <Loader2 className="h-4 w-4 animate-spin" />
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="h-4 w-4" />
                          Send Email
                        </>
                      )}
                    </button>
                  </form>
                </div>

                {/* Quick Actions */}
                <div className="space-y-4">
                  <div className="rounded-xl border border-border bg-card p-5">
                    <h3 className="text-sm font-semibold text-foreground mb-4">Quick Send to User</h3>
                    <p className="text-xs text-muted-foreground mb-3">
                      Click on a user from the list to pre-fill their email address.
                    </p>
                    <div className="max-h-64 overflow-y-auto space-y-2">
                      {users.slice(0, 10).map((user) => (
                        <button
                          key={user.id}
                          onClick={() => {
                            setEmailRecipient(user.email)
                          }}
                          className="w-full flex items-center justify-between p-3 rounded-lg border border-border hover:bg-muted/30 transition-colors text-left"
                        >
                          <div>
                            <p className="text-sm font-medium text-foreground">
                              {user.full_name || "No name"}
                            </p>
                            <p className="text-xs text-muted-foreground">{user.email}</p>
                          </div>
                          <Mail className="h-4 w-4 text-muted-foreground" />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="rounded-xl border border-border bg-card p-5">
                    <h3 className="text-sm font-semibold text-foreground mb-2">Email Integration Note</h3>
                    <p className="text-xs text-muted-foreground">
                      To enable actual email delivery, integrate with an email service like Resend or SendGrid.
                      Currently, emails are logged and stored for reference.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* User Detail Panel */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSelectedUser(null)} />
          <div className="relative w-full max-w-md bg-card border-l border-border h-full overflow-y-auto">
            <div className="sticky top-0 bg-card border-b border-border p-4 flex items-center justify-between">
              <h2 className="text-lg font-semibold text-foreground">User Details</h2>
              <button
                onClick={() => setSelectedUser(null)}
                className="p-2 rounded-lg hover:bg-muted transition-colors"
              >
                <X className="h-5 w-5 text-muted-foreground" />
              </button>
            </div>
            <div className="p-6 space-y-6">
              <div>
                <p className="text-sm text-muted-foreground">Name</p>
                <p className="text-lg font-semibold text-foreground mt-1">
                  {selectedUser.full_name || "No name"}
                </p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="text-base text-foreground mt-1">{selectedUser.email}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Current Plan</p>
                <div className="mt-1">
                  <PlanBadge plan={selectedUser.subscription?.plan} />
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Subscription Status</p>
                <div className="mt-1">
                  <StatusBadge status={selectedUser.subscription?.status} />
                </div>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Account Created</p>
                <p className="text-base text-foreground mt-1">
                  {new Date(selectedUser.created_at).toLocaleDateString("en-US", {
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-xl border border-border bg-muted/30 p-4">
                  <p className="text-xs text-muted-foreground">Strategies</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {selectedUser.strategies_count}
                  </p>
                </div>
                <div className="rounded-xl border border-border bg-muted/30 p-4">
                  <p className="text-xs text-muted-foreground">Signals</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {selectedUser.signals_count}
                  </p>
                </div>
              </div>
              {selectedUser.subscription?.stripe_customer_id && (
                <div>
                  <p className="text-sm text-muted-foreground">Stripe Customer ID</p>
                  <p className="text-xs text-muted-foreground font-mono mt-1">
                    {selectedUser.subscription.stripe_customer_id}
                  </p>
                </div>
              )}
              
              {/* Quick Actions */}
              <div className="pt-4 border-t border-border space-y-3">
                <p className="text-sm font-medium text-foreground">Quick Actions</p>
                <button
                  onClick={() => {
                    setEmailRecipient(selectedUser.email)
                    setActiveTab("email")
                    setSelectedUser(null)
                  }}
                  className="w-full flex items-center justify-center gap-2 h-10 rounded-lg border border-border text-sm font-medium text-foreground hover:bg-muted transition-colors"
                >
                  <Mail className="h-4 w-4" />
                  Send Email to User
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function StatCard({
  label,
  value,
  icon: Icon,
  variant = "default",
}: {
  label: string
  value: number
  icon: React.ComponentType<{ className?: string }>
  variant?: "default" | "primary" | "success" | "warning"
}) {
  const variants = {
    default: "bg-card border-border",
    primary: "bg-primary/5 border-primary/20",
    success: "bg-green-500/5 border-green-500/20",
    warning: "bg-amber-500/5 border-amber-500/20",
  }

  const iconVariants = {
    default: "text-muted-foreground",
    primary: "text-primary",
    success: "text-green-500",
    warning: "text-amber-500",
  }

  return (
    <div className={`rounded-xl border p-4 ${variants[variant]}`}>
      <div className="flex items-center justify-between mb-2">
        <Icon className={`h-5 w-5 ${iconVariants[variant]}`} />
      </div>
      <p className="text-2xl font-bold text-foreground">{value.toLocaleString()}</p>
      <p className="text-xs text-muted-foreground mt-1">{label}</p>
    </div>
  )
}

function PlanBadge({ plan }: { plan?: string }) {
  if (!plan) {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-muted text-muted-foreground">
        Free
      </span>
    )
  }

  const planStyles = {
    starter: "bg-blue-500/10 text-blue-500",
    pro: "bg-primary/10 text-primary",
    elite: "bg-amber-500/10 text-amber-500",
  }

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium capitalize ${
        planStyles[plan as keyof typeof planStyles] || "bg-muted text-muted-foreground"
      }`}
    >
      {plan}
    </span>
  )
}

function StatusBadge({ status }: { status?: string }) {
  if (!status) {
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-muted text-muted-foreground">
        None
      </span>
    )
  }

  const statusStyles = {
    active: "bg-green-500/10 text-green-500",
    trialing: "bg-blue-500/10 text-blue-500",
    canceled: "bg-red-500/10 text-red-500",
    past_due: "bg-amber-500/10 text-amber-500",
  }

  return (
    <span
      className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium capitalize ${
        statusStyles[status as keyof typeof statusStyles] || "bg-muted text-muted-foreground"
      }`}
    >
      {status.replace("_", " ")}
    </span>
  )
}
