"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Crosshair, ArrowRight, Sparkles, Pencil, Check } from "lucide-react"

const templates = [
  {
    id: "intraday-breakout",
    name: "Intraday Breakout Trader",
    markets: ["BTC", "ETH", "SPY"],
    timeframe: "15m",
    setup: "Breakouts",
    risk: "1%",
    style: "Intraday",
    frequency: "Balanced",
  },
  {
    id: "swing-trend",
    name: "Swing Trend Trader",
    markets: ["SPY", "NVDA", "QQQ"],
    timeframe: "Daily",
    setup: "Trend continuation",
    risk: "1%",
    style: "Swing",
    frequency: "Selective",
  },
  {
    id: "crypto-momentum",
    name: "Crypto Momentum Trader",
    markets: ["BTC", "ETH", "SOL"],
    timeframe: "15m",
    setup: "Breakouts",
    risk: "1%",
    style: "Intraday",
    frequency: "Active",
  },
]

export default function GetStartedPage() {
  const router = useRouter()
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null)

  const handleBuildOwn = () => {
    localStorage.removeItem("sightline_template")
    router.push("/strategy-wizard")
  }

  const handleUseTemplate = () => {
    if (!selectedTemplate) return
    const template = templates.find((t) => t.id === selectedTemplate)
    if (template) {
      localStorage.setItem("sightline_template", JSON.stringify(template))
      router.push("/strategy-wizard")
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border px-5 py-4">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Crosshair className="h-4 w-4 text-primary-foreground" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-sm font-bold text-foreground">SightLine</span>
            <span className="text-[9px] font-medium tracking-widest text-primary uppercase">Advanced Trading Analytics</span>
          </div>
        </Link>
      </header>

      {/* Content */}
      <div className="flex-1 px-5 py-8">
        <div className="mx-auto max-w-2xl">
          <h1 className="text-2xl font-bold text-foreground text-center md:text-3xl">
            Choose How to Start
          </h1>
          <p className="mt-3 text-sm text-muted-foreground text-center">
            Build your own trading profile from scratch, or start with a template.
          </p>

          {/* Options */}
          <div className="mt-10 grid gap-4 md:grid-cols-2">
            {/* Build Own */}
            <button
              onClick={handleBuildOwn}
              className="group flex flex-col items-center rounded-2xl border border-border bg-card p-8 text-center transition-all hover:border-primary/30"
            >
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary transition-colors group-hover:bg-primary/15">
                <Pencil className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Build My Own Profile</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Answer a few questions to create a personalized trading profile.
              </p>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary">
                Start from scratch
                <ArrowRight className="h-4 w-4" />
              </span>
            </button>

            {/* Use Template */}
            <div className="flex flex-col rounded-2xl border border-border bg-card p-8 text-center">
              <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-primary/10 text-primary mx-auto">
                <Sparkles className="h-6 w-6" />
              </div>
              <h3 className="text-lg font-semibold text-foreground">Start With a Template</h3>
              <p className="mt-2 text-sm text-muted-foreground">
                Choose a pre-built profile and customize it to your needs.
              </p>
            </div>
          </div>

          {/* Templates */}
          <div className="mt-8">
            <h3 className="text-sm font-semibold text-foreground mb-4">Popular Templates</h3>
            <div className="grid gap-3">
              {templates.map((template) => (
                <button
                  key={template.id}
                  onClick={() => setSelectedTemplate(template.id)}
                  className={`relative flex flex-col rounded-xl border p-5 text-left transition-all ${
                    selectedTemplate === template.id
                      ? "border-primary/40 bg-primary/[0.06]"
                      : "border-border bg-card hover:border-primary/20"
                  }`}
                >
                  {selectedTemplate === template.id && (
                    <div className="absolute top-4 right-4 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground">
                      <Check className="h-4 w-4" />
                    </div>
                  )}
                  <h4 className="font-semibold text-foreground">{template.name}</h4>
                  <div className="mt-3 grid grid-cols-2 gap-x-6 gap-y-2 text-xs">
                    <div>
                      <span className="text-muted-foreground">Markets: </span>
                      <span className="font-medium text-foreground">{template.markets.join(", ")}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Timeframe: </span>
                      <span className="font-medium text-foreground">{template.timeframe}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Setup: </span>
                      <span className="font-medium text-foreground">{template.setup}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Risk: </span>
                      <span className="font-medium text-foreground">{template.risk}</span>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {selectedTemplate && (
              <button
                onClick={handleUseTemplate}
                className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 glow-green"
              >
                Use This Template
                <ArrowRight className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
