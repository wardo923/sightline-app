"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { createClient } from "@/lib/supabase/client"
import {
  Crosshair,
  TrendingUp,
  TrendingDown,
  Target,
  BarChart3,
  Activity,
  Calendar,
  ChevronLeft,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  Percent,
  DollarSign,
  Zap,
} from "lucide-react"

interface Signal {
  id: string
  symbol: string
  direction: "BUY" | "SELL"
  setup_type: string
  timeframe: string
  grade: string
  entry_price: string
  stop_loss: string
  target_1: string
  target_2: string | null
  risk_reward: string
  status: string
  outcome: string | null
  actual_result: string | null
  created_at: string
}

interface PerformanceStats {
  totalSignals: number
  completedSignals: number
  winningSignals: number
  losingSignals: number
  pendingSignals: number
  winRate: number
  avgRiskReward: number
  bySetupType: { type: string; total: number; wins: number; winRate: number }[]
  byTimeframe: { timeframe: string; total: number; wins: number; winRate: number }[]
  byGrade: { grade: string; total: number; wins: number; winRate: number }[]
  recentSignals: Signal[]
}

export default function PerformancePage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [stats, setStats] = useState<PerformanceStats | null>(null)
  const [timeFilter, setTimeFilter] = useState<"all" | "30d" | "7d">("all")
  const [setupFilter, setSetupFilter] = useState<string>("all")
  const [availableSetups, setAvailableSetups] = useState<string[]>([])

  useEffect(() => {
    async function loadPerformanceData() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      await fetchStats(supabase, user.id)
      setIsLoading(false)
    }

    loadPerformanceData()
  }, [router, timeFilter, setupFilter])

  async function fetchStats(supabase: ReturnType<typeof createClient>, userId: string) {
    let query = supabase
      .from("signals")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })

    // Apply time filter
    if (timeFilter !== "all") {
      const daysAgo = timeFilter === "30d" ? 30 : 7
      const dateFilter = new Date()
      dateFilter.setDate(dateFilter.getDate() - daysAgo)
      query = query.gte("created_at", dateFilter.toISOString())
    }

    // Apply setup filter
    if (setupFilter !== "all") {
      query = query.eq("setup_type", setupFilter)
    }

    const { data: signals } = await query

    if (!signals) {
      setStats(null)
      return
    }

    // Get unique setup types
    const setups = [...new Set(signals.map(s => s.setup_type).filter(Boolean))]
    setAvailableSetups(setups)

    // Calculate stats
    const completed = signals.filter(s => s.status === "completed" || s.outcome)
    const wins = completed.filter(s => s.outcome === "win" || s.outcome === "target_hit")
    const losses = completed.filter(s => s.outcome === "loss" || s.outcome === "stopped_out")
    const pending = signals.filter(s => s.status === "pending" || s.status === "active")

    // Calculate average R:R
    const rrValues = signals
      .map(s => parseFloat(s.risk_reward?.replace("R", "").replace(":", "") || "0"))
      .filter(v => !isNaN(v) && v > 0)
    const avgRR = rrValues.length > 0 
      ? rrValues.reduce((a, b) => a + b, 0) / rrValues.length 
      : 0

    // Group by setup type
    const bySetupType: Record<string, { total: number; wins: number }> = {}
    signals.forEach(s => {
      const type = s.setup_type || "Unknown"
      if (!bySetupType[type]) bySetupType[type] = { total: 0, wins: 0 }
      bySetupType[type].total++
      if (s.outcome === "win" || s.outcome === "target_hit") {
        bySetupType[type].wins++
      }
    })

    // Group by timeframe
    const byTimeframe: Record<string, { total: number; wins: number }> = {}
    signals.forEach(s => {
      const tf = s.timeframe || "Unknown"
      if (!byTimeframe[tf]) byTimeframe[tf] = { total: 0, wins: 0 }
      byTimeframe[tf].total++
      if (s.outcome === "win" || s.outcome === "target_hit") {
        byTimeframe[tf].wins++
      }
    })

    // Group by grade
    const byGrade: Record<string, { total: number; wins: number }> = {}
    signals.forEach(s => {
      const grade = s.grade || "Unknown"
      if (!byGrade[grade]) byGrade[grade] = { total: 0, wins: 0 }
      byGrade[grade].total++
      if (s.outcome === "win" || s.outcome === "target_hit") {
        byGrade[grade].wins++
      }
    })

    setStats({
      totalSignals: signals.length,
      completedSignals: completed.length,
      winningSignals: wins.length,
      losingSignals: losses.length,
      pendingSignals: pending.length,
      winRate: completed.length > 0 ? (wins.length / completed.length) * 100 : 0,
      avgRiskReward: avgRR,
      bySetupType: Object.entries(bySetupType).map(([type, data]) => ({
        type,
        total: data.total,
        wins: data.wins,
        winRate: data.total > 0 ? (data.wins / data.total) * 100 : 0,
      })).sort((a, b) => b.total - a.total),
      byTimeframe: Object.entries(byTimeframe).map(([timeframe, data]) => ({
        timeframe,
        total: data.total,
        wins: data.wins,
        winRate: data.total > 0 ? (data.wins / data.total) * 100 : 0,
      })).sort((a, b) => b.total - a.total),
      byGrade: Object.entries(byGrade).map(([grade, data]) => ({
        grade,
        total: data.total,
        wins: data.wins,
        winRate: data.total > 0 ? (data.wins / data.total) * 100 : 0,
      })).sort((a, b) => {
        const order = { A: 0, B: 1, C: 2, Unknown: 3 }
        return (order[a.grade as keyof typeof order] || 3) - (order[b.grade as keyof typeof order] || 3)
      }),
      recentSignals: signals.slice(0, 10),
    })
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="flex h-16 items-center justify-between px-5">
          <div className="flex items-center gap-3">
            <Link
              href="/dashboard"
              className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
            >
              <ChevronLeft className="h-5 w-5" />
            </Link>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
                <Crosshair className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="text-lg font-bold text-foreground">Strategy Insights</span>
            </div>
          </div>
        </div>
      </header>

      <main className="p-5 max-w-4xl mx-auto">
        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            <select
              value={timeFilter}
              onChange={(e) => setTimeFilter(e.target.value as typeof timeFilter)}
              className="h-9 px-3 rounded-lg border border-border bg-card text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
            >
              <option value="all">All Time</option>
              <option value="30d">Last 30 Days</option>
              <option value="7d">Last 7 Days</option>
            </select>
          </div>
          <select
            value={setupFilter}
            onChange={(e) => setSetupFilter(e.target.value)}
            className="h-9 px-3 rounded-lg border border-border bg-card text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="all">All Setups</option>
            {availableSetups.map(setup => (
              <option key={setup} value={setup}>{setup}</option>
            ))}
          </select>
        </div>

        {!stats || stats.totalSignals === 0 ? (
          <div className="rounded-xl border border-border bg-card p-8 text-center">
            <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No signals yet</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Start trading to see your performance metrics here.
            </p>
            <Link
              href="/dashboard"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
            >
              Go to Dashboard
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Overview Stats */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              <StatCard
                label="Win Rate"
                value={`${stats.winRate.toFixed(1)}%`}
                icon={Percent}
                variant={stats.winRate >= 50 ? "success" : "default"}
              />
              <StatCard
                label="Avg R:R"
                value={`${stats.avgRiskReward.toFixed(1)}R`}
                icon={Target}
                variant="primary"
              />
              <StatCard
                label="Winning"
                value={stats.winningSignals.toString()}
                icon={CheckCircle2}
                variant="success"
              />
              <StatCard
                label="Losing"
                value={stats.losingSignals.toString()}
                icon={XCircle}
                variant="danger"
              />
            </div>

            {/* Signal Counts */}
            <div className="grid grid-cols-3 gap-4">
              <div className="rounded-xl border border-border bg-card p-4">
                <p className="text-xs text-muted-foreground">Total Signals</p>
                <p className="text-2xl font-bold text-foreground mt-1">{stats.totalSignals}</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <p className="text-xs text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold text-foreground mt-1">{stats.completedSignals}</p>
              </div>
              <div className="rounded-xl border border-border bg-card p-4">
                <p className="text-xs text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-primary mt-1">{stats.pendingSignals}</p>
              </div>
            </div>

            {/* Performance by Setup Type */}
            {stats.bySetupType.length > 0 && (
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-4">Performance by Setup Type</h3>
                <div className="space-y-4">
                  {stats.bySetupType.map((item) => (
                    <div key={item.type}>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm text-foreground">{item.type}</span>
                        <div className="flex items-center gap-3">
                          <span className="text-xs text-muted-foreground">
                            {item.wins}/{item.total} wins
                          </span>
                          <span className={`text-sm font-medium ${item.winRate >= 50 ? "text-green-500" : "text-muted-foreground"}`}>
                            {item.winRate.toFixed(0)}%
                          </span>
                        </div>
                      </div>
                      <div className="h-2 bg-muted rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${item.winRate >= 50 ? "bg-green-500" : "bg-muted-foreground"}`}
                          style={{ width: `${item.winRate}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Performance by Timeframe */}
            {stats.byTimeframe.length > 0 && (
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-4">Performance by Timeframe</h3>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                  {stats.byTimeframe.map((item) => (
                    <div
                      key={item.timeframe}
                      className="rounded-lg border border-border bg-muted/30 p-3"
                    >
                      <p className="text-xs text-muted-foreground">{item.timeframe}</p>
                      <p className={`text-lg font-bold mt-1 ${item.winRate >= 50 ? "text-green-500" : "text-foreground"}`}>
                        {item.winRate.toFixed(0)}%
                      </p>
                      <p className="text-[10px] text-muted-foreground">
                        {item.wins}/{item.total} wins
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Performance by Grade */}
            {stats.byGrade.length > 0 && (
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-4">Performance by Signal Grade</h3>
                <div className="grid grid-cols-3 gap-3">
                  {stats.byGrade.map((item) => {
                    const gradeColors = {
                      A: "border-primary/30 bg-primary/5",
                      B: "border-amber-500/30 bg-amber-500/5",
                      C: "border-border bg-muted/30",
                    }
                    return (
                      <div
                        key={item.grade}
                        className={`rounded-lg border p-3 ${gradeColors[item.grade as keyof typeof gradeColors] || "border-border"}`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-lg font-bold text-foreground">Grade {item.grade}</span>
                          <span className={`text-sm font-medium ${item.winRate >= 50 ? "text-green-500" : "text-muted-foreground"}`}>
                            {item.winRate.toFixed(0)}%
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          {item.wins}/{item.total} wins
                        </p>
                      </div>
                    )
                  })}
                </div>
              </div>
            )}

            {/* Recent Signals */}
            {stats.recentSignals.length > 0 && (
              <div className="rounded-xl border border-border bg-card p-5">
                <h3 className="text-sm font-semibold text-foreground mb-4">Recent Signals</h3>
                <div className="space-y-3">
                  {stats.recentSignals.map((signal) => (
                    <Link
                      key={signal.id}
                      href={`/signals/${signal.id}`}
                      className="flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary/30 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                          signal.direction === "BUY" ? "bg-green-500/10" : "bg-red-500/10"
                        }`}>
                          {signal.direction === "BUY" ? (
                            <TrendingUp className="h-4 w-4 text-green-500" />
                          ) : (
                            <TrendingDown className="h-4 w-4 text-red-500" />
                          )}
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{signal.symbol}</p>
                          <p className="text-xs text-muted-foreground">{signal.setup_type}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <OutcomeBadge outcome={signal.outcome} status={signal.status} />
                        <span className="text-xs text-muted-foreground">
                          {new Date(signal.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  )
}

function StatCard({
  label,
  value,
  icon: Icon,
  variant = "default",
}: {
  label: string
  value: string
  icon: React.ComponentType<{ className?: string }>
  variant?: "default" | "primary" | "success" | "danger"
}) {
  const variants = {
    default: "bg-card border-border",
    primary: "bg-primary/5 border-primary/20",
    success: "bg-green-500/5 border-green-500/20",
    danger: "bg-red-500/5 border-red-500/20",
  }

  const iconVariants = {
    default: "text-muted-foreground",
    primary: "text-primary",
    success: "text-green-500",
    danger: "text-red-500",
  }

  return (
    <div className={`rounded-xl border p-4 ${variants[variant]}`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className={`h-4 w-4 ${iconVariants[variant]}`} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <p className="text-2xl font-bold text-foreground">{value}</p>
    </div>
  )
}

function OutcomeBadge({ outcome, status }: { outcome: string | null; status: string }) {
  if (!outcome && (status === "pending" || status === "active")) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-blue-500/10 text-blue-500">
        <Clock className="h-3 w-3" />
        Active
      </span>
    )
  }

  if (outcome === "win" || outcome === "target_hit") {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-green-500/10 text-green-500">
        <CheckCircle2 className="h-3 w-3" />
        Win
      </span>
    )
  }

  if (outcome === "loss" || outcome === "stopped_out") {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs font-medium bg-red-500/10 text-red-500">
        <XCircle className="h-3 w-3" />
        Loss
      </span>
    )
  }

  return (
    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-muted text-muted-foreground">
      {outcome || status}
    </span>
  )
}
