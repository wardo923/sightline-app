import { Navbar } from "@/components/navbar"
import Link from "next/link"

export const metadata = {
  title: "Terms of Service - SightLine Advanced Trading Analytics",
  description: "Terms of service for SightLine Advanced Trading Analytics",
}

export default function TermsPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <div className="mx-auto max-w-3xl px-5 py-32">
        <h1 className="text-3xl font-bold text-foreground mb-8">Terms of Service</h1>
        
        <div className="prose prose-invert prose-sm max-w-none">
          <p className="text-muted-foreground mb-6">
            Last updated: January 2026
          </p>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Acceptance of Terms</h2>
            <p className="text-muted-foreground mb-4">
              By accessing or using SightLine Advanced Trading Analytics, you agree to be bound by these Terms of Service.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Description of Service</h2>
            <p className="text-muted-foreground mb-4">
              SightLine provides analytical tools and market observations for informational purposes only. Our service includes:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Strategy profile creation tools</li>
              <li>Market structure analysis</li>
              <li>Trade setup alerts with entry, stop loss, and target levels</li>
              <li>Trade validity monitoring</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Important Disclaimers</h2>
            <p className="text-muted-foreground mb-4">
              <strong className="text-foreground">SightLine does not provide investment advice, trade recommendations, or portfolio management services.</strong>
            </p>
            <p className="text-muted-foreground mb-4">
              Any setups, alerts, or insights provided are informational only and should not be interpreted as a recommendation to buy or sell any financial instrument.
            </p>
            <p className="text-muted-foreground mb-4">
              Users are solely responsible for their own trading decisions and financial outcomes.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">User Responsibilities</h2>
            <p className="text-muted-foreground mb-4">
              You agree to:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Provide accurate information when creating your account</li>
              <li>Maintain the security of your account credentials</li>
              <li>Use the service in compliance with all applicable laws</li>
              <li>Make your own independent trading decisions</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Limitation of Liability</h2>
            <p className="text-muted-foreground mb-4">
              SightLine shall not be liable for any losses, damages, or costs arising from your use of the service or reliance on any information provided.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Contact</h2>
            <p className="text-muted-foreground">
              For questions about these Terms, contact us at legal@sightline.io
            </p>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-border">
          <Link href="/" className="text-sm text-primary hover:underline">
            ← Back to Home
          </Link>
        </div>
      </div>
    </main>
  )
}
