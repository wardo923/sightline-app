"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  Crosshair,
  ArrowLeft,
  TrendingUp,
  TrendingDown,
  Target,
  BarChart3,
  Zap,
  AlertTriangle,
  Lightbulb,
  Award,
  PieChart,
  Activity,
} from "lucide-react"
import { 
  generatePerformanceReport, 
  generateDemoReport,
  PerformanceReport,
  StrategyInsight,
} from "@/lib/strategy-insights"
import { getCompletedAlerts } from "@/lib/storage"

export default function StrategyInsightsPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)
  const [report, setReport] = useState<PerformanceReport | null>(null)
  const [useDemo, setUseDemo] = useState(false)

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("sightline_logged_in")
    if (!isLoggedIn) {
      router.push("/login")
      return
    }
    
    // Check if we have real data
    const completedTrades = getCompletedAlerts()
    if (completedTrades.length >= 5) {
      setReport(generatePerformanceReport())
      setUseDemo(false)
    } else {
      // Use demo data for display
      setReport(generateDemoReport())
      setUseDemo(true)
    }
    setIsLoading(false)
  }, [router])

  if (isLoading || !report) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur">
        <div className="flex h-14 items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-5 w-5" />
            </Link>
            <div className="flex items-center gap-2">
              <Crosshair className="h-5 w-5 text-primary" />
              <span className="font-semibold text-foreground">Strategy Insights</span>
            </div>
          </div>
        </div>
      </header>

      <main className="p-4 pb-24 max-w-4xl mx-auto">
        {/* Demo Notice */}
        {useDemo && (
          <div className="mb-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4">
            <p className="text-sm text-amber-500">
              Showing demo data. Complete at least 5 trades to see your actual strategy performance.
            </p>
          </div>
        )}

        {/* Overall Performance */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">Performance Overview</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            <StatCard 
              label="Total Signals" 
              value={report.totalSignals.toString()} 
              icon={Activity}
            />
            <StatCard 
              label="Win Rate" 
              value={`${report.overallWinRate}%`} 
              icon={Target}
              highlight={report.overallWinRate >= 50}
            />
            <StatCard 
              label="Avg R:R" 
              value={`${report.overallAverageRR}R`} 
              icon={BarChart3}
              highlight={report.overallAverageRR >= 1.5}
            />
            <StatCard 
              label="Total R Gained" 
              value={`${report.totalRGained > 0 ? "+" : ""}${report.totalRGained}R`} 
              icon={TrendingUp}
              highlight={report.totalRGained > 0}
            />
          </div>
        </section>

        {/* Strategy Insights */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">Key Insights</h2>
          <div className="space-y-3">
            {report.insights.map((insight, i) => (
              <InsightCard key={i} insight={insight} />
            ))}
          </div>
        </section>

        {/* Performance by Setup Type */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">Performance by Setup Type</h2>
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <div className="grid grid-cols-5 gap-2 p-3 border-b border-border bg-muted/30 text-xs font-medium text-muted-foreground">
              <span>Setup Type</span>
              <span className="text-center">Trades</span>
              <span className="text-center">Win Rate</span>
              <span className="text-center">Avg R:R</span>
              <span className="text-center">Total R</span>
            </div>
            {report.bySetupType.map((setup, i) => (
              <div key={i} className="grid grid-cols-5 gap-2 p-3 border-b border-border last:border-0 text-sm">
                <span className="font-medium text-foreground truncate">{setup.setupType}</span>
                <span className="text-center text-muted-foreground">{setup.totalTrades}</span>
                <span className={`text-center font-medium ${setup.winRate >= 50 ? "text-primary" : "text-destructive"}`}>
                  {setup.winRate}%
                </span>
                <span className="text-center text-muted-foreground">{setup.averageRR}R</span>
                <span className={`text-center font-medium ${setup.totalR >= 0 ? "text-primary" : "text-destructive"}`}>
                  {setup.totalR > 0 ? "+" : ""}{setup.totalR}R
                </span>
              </div>
            ))}
          </div>
        </section>

        {/* Performance by Asset */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">Performance by Asset</h2>
          <div className="grid gap-3 md:grid-cols-2">
            {report.byAsset.map((asset, i) => (
              <div key={i} className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-foreground">{asset.symbol}</span>
                  <span className={`text-sm font-medium px-2 py-0.5 rounded-full ${
                    asset.winRate >= 50 ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
                  }`}>
                    {asset.winRate}% win rate
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  <div>
                    <p className="text-muted-foreground">Trades</p>
                    <p className="font-medium text-foreground">{asset.totalTrades}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Avg R:R</p>
                    <p className="font-medium text-foreground">{asset.averageRR}R</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Best Setup</p>
                    <p className="font-medium text-foreground truncate">{asset.bestSetupType}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Performance by Market Condition */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">Performance by Market Condition</h2>
          <div className="space-y-3">
            {report.byCondition.map((condition, i) => (
              <div key={i} className="rounded-xl border border-border bg-card p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-semibold text-foreground capitalize">{condition.condition}</span>
                  <span className={`text-sm font-medium ${
                    condition.winRate >= 60 ? "text-primary" : condition.winRate >= 40 ? "text-foreground" : "text-destructive"
                  }`}>
                    {condition.winRate}% win rate
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{condition.totalTrades} trades • {condition.averageRR}R avg</span>
                  {condition.bestPerformingSetups.length > 0 && (
                    <span>Best: {condition.bestPerformingSetups.slice(0, 2).join(", ")}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Performance by Timeframe */}
        <section className="mb-6">
          <h2 className="text-lg font-semibold text-foreground mb-3">Performance by Timeframe</h2>
          <div className="grid gap-3 grid-cols-3">
            {report.byTimeframe.map((tf, i) => (
              <div key={i} className="rounded-xl border border-border bg-card p-4 text-center">
                <p className="text-lg font-bold text-foreground">{tf.timeframe}</p>
                <p className={`text-sm font-medium ${tf.winRate >= 50 ? "text-primary" : "text-muted-foreground"}`}>
                  {tf.winRate}% win
                </p>
                <p className="text-xs text-muted-foreground">{tf.totalTrades} trades</p>
              </div>
            ))}
          </div>
        </section>

        {/* Disclaimer */}
        <section className="mt-8 rounded-xl border border-border bg-card/50 p-4">
          <p className="text-xs text-muted-foreground text-center">
            Past signal performance does not guarantee future results. SightLine is designed to identify 
            high-probability opportunities, not certainty. All trading involves risk.
          </p>
        </section>
      </main>
    </div>
  )
}

function StatCard({ 
  label, 
  value, 
  icon: Icon, 
  highlight = false 
}: { 
  label: string
  value: string
  icon: React.ElementType
  highlight?: boolean
}) {
  return (
    <div className={`rounded-xl border p-4 ${highlight ? "border-primary/30 bg-primary/5" : "border-border bg-card"}`}>
      <div className="flex items-center gap-2 mb-1">
        <Icon className={`h-4 w-4 ${highlight ? "text-primary" : "text-muted-foreground"}`} />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <p className={`text-xl font-bold ${highlight ? "text-primary" : "text-foreground"}`}>{value}</p>
    </div>
  )
}

function InsightCard({ insight }: { insight: StrategyInsight }) {
  const config = {
    strength: { icon: Award, color: "text-primary", bg: "bg-primary/10 border-primary/30" },
    weakness: { icon: AlertTriangle, color: "text-amber-500", bg: "bg-amber-500/10 border-amber-500/30" },
    opportunity: { icon: Zap, color: "text-blue-500", bg: "bg-blue-500/10 border-blue-500/30" },
    tip: { icon: Lightbulb, color: "text-purple-500", bg: "bg-purple-500/10 border-purple-500/30" },
  }
  
  const { icon: Icon, color, bg } = config[insight.type]
  
  return (
    <div className={`rounded-xl border p-4 ${bg}`}>
      <div className="flex items-start gap-3">
        <div className={`mt-0.5 ${color}`}>
          <Icon className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <p className="font-semibold text-foreground">{insight.title}</p>
          <p className="text-sm text-muted-foreground mt-1">{insight.description}</p>
          {insight.metric && (
            <span className={`inline-block mt-2 text-xs font-medium px-2 py-0.5 rounded-full ${bg}`}>
              {insight.metric}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
