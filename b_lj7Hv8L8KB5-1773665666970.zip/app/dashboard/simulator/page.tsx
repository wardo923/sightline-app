"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, TrendingUp, TrendingDown, RefreshCw, Info } from "lucide-react"

// Sample trade data for simulation
const sampleTrades = [
  { asset: "BTC", setup: "Breakout", entry: 64200, stop: 63700, target: 65700, direction: "BUY" as const },
  { asset: "ETH", setup: "Pullback", entry: 3450, stop: 3380, target: 3590, direction: "BUY" as const },
  { asset: "SPY", setup: "Range Break", entry: 512.50, stop: 509.00, target: 519.50, direction: "BUY" as const },
  { asset: "SOL", setup: "Liquidity Sweep", entry: 142.00, stop: 138.50, target: 149.00, direction: "BUY" as const },
  { asset: "NVDA", setup: "Momentum", entry: 875.00, stop: 860.00, target: 905.00, direction: "BUY" as const },
]

// Generate random sequence outcome
function generateSequenceOutcome(winRate: number = 0.45): { result: number; isWin: boolean }[] {
  const outcomes: { result: number; isWin: boolean }[] = []
  for (let i = 0; i < 10; i++) {
    const isWin = Math.random() < winRate
    const result = isWin ? +(1.8 + Math.random() * 1.5).toFixed(1) : -1
    outcomes.push({ result, isWin })
  }
  return outcomes
}

export default function SimulatorPage() {
  const [selectedTrade, setSelectedTrade] = useState(sampleTrades[0])
  const [sequence, setSequence] = useState(generateSequenceOutcome())
  const [isSimulating, setIsSimulating] = useState(false)

  // Calculate R:R for selected trade
  const risk = Math.abs(selectedTrade.entry - selectedTrade.stop)
  const reward = Math.abs(selectedTrade.target - selectedTrade.entry)
  const riskReward = (reward / risk).toFixed(1)

  // Calculate sequence totals
  const totalR = sequence.reduce((sum, t) => sum + t.result, 0)
  const wins = sequence.filter(t => t.isWin).length
  const winRate = ((wins / sequence.length) * 100).toFixed(0)

  const runNewSequence = () => {
    setIsSimulating(true)
    setTimeout(() => {
      setSequence(generateSequenceOutcome())
      setIsSimulating(false)
    }, 500)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
          <div className="flex items-center gap-3">
            <Link href="/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" />
              <span className="text-sm">Back to Dashboard</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-4 py-8">
        {/* Page Title */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground">Trade Outcome Simulator</h1>
          <p className="mt-2 text-muted-foreground">
            Understand how structured risk/reward works before taking real trades.
          </p>
        </div>

        {/* Simulated Trade Panel */}
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
            Simulated Trade
          </h2>
          
          {/* Trade Selector */}
          <div className="flex flex-wrap gap-2 mb-4">
            {sampleTrades.map((trade) => (
              <button
                key={trade.asset}
                onClick={() => setSelectedTrade(trade)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  selectedTrade.asset === trade.asset
                    ? "bg-primary text-primary-foreground"
                    : "bg-card border border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {trade.asset}
              </button>
            ))}
          </div>

          {/* Trade Details */}
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="text-lg font-bold text-foreground">{selectedTrade.asset}</span>
                <span className={`flex items-center gap-1 rounded-md px-2 py-0.5 text-xs font-semibold ${
                  selectedTrade.direction === "BUY" 
                    ? "bg-primary/10 text-primary" 
                    : "bg-destructive/10 text-destructive"
                }`}>
                  {selectedTrade.direction === "BUY" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {selectedTrade.direction}
                </span>
              </div>
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded">
                {selectedTrade.setup}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="rounded-lg border border-border bg-background/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">Entry</p>
                <p className="text-base font-semibold text-foreground">
                  {selectedTrade.entry.toLocaleString()}
                </p>
              </div>
              <div className="rounded-lg border border-border bg-background/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">Stop Loss</p>
                <p className="text-base font-semibold text-destructive">
                  {selectedTrade.stop.toLocaleString()}
                </p>
              </div>
              <div className="rounded-lg border border-border bg-background/50 p-3">
                <p className="text-xs text-muted-foreground mb-1">Target</p>
                <p className="text-base font-semibold text-primary">
                  {selectedTrade.target.toLocaleString()}
                </p>
              </div>
            </div>

            {/* Possible Outcomes */}
            <div className="border-t border-border pt-4">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Possible Outcomes
              </p>
              <div className="grid grid-cols-2 gap-4">
                <div className="rounded-lg border border-destructive/20 bg-destructive/5 p-4">
                  <p className="text-xs text-muted-foreground mb-1">If Stop Is Hit</p>
                  <p className="text-xl font-bold text-destructive">-1R</p>
                  <p className="text-xs text-muted-foreground mt-1">Maximum defined loss</p>
                </div>
                <div className="rounded-lg border border-primary/20 bg-primary/5 p-4">
                  <p className="text-xs text-muted-foreground mb-1">If Target Is Hit</p>
                  <p className="text-xl font-bold text-primary">+{riskReward}R</p>
                  <p className="text-xs text-muted-foreground mt-1">Potential reward</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Sequence Simulation */}
        <section className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
              10-Trade Sequence Simulation
            </h2>
            <button
              onClick={runNewSequence}
              disabled={isSimulating}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium bg-card border border-border text-muted-foreground hover:text-foreground transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`h-3 w-3 ${isSimulating ? "animate-spin" : ""}`} />
              Run New Sequence
            </button>
          </div>

          <div className="rounded-xl border border-border bg-card p-5">
            {/* Trade Results Grid */}
            <div className="grid grid-cols-5 gap-2 mb-6">
              {sequence.map((trade, i) => (
                <div
                  key={i}
                  className={`rounded-lg border p-3 text-center ${
                    trade.isWin
                      ? "border-primary/20 bg-primary/5"
                      : "border-destructive/20 bg-destructive/5"
                  }`}
                >
                  <p className="text-[10px] text-muted-foreground mb-1">Trade {i + 1}</p>
                  <p className={`text-sm font-bold ${trade.isWin ? "text-primary" : "text-destructive"}`}>
                    {trade.result > 0 ? "+" : ""}{trade.result}R
                  </p>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="border-t border-border pt-4">
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-xs text-muted-foreground mb-1">Win Rate</p>
                  <p className="text-lg font-bold text-foreground">{winRate}%</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground mb-1">Total Trades</p>
                  <p className="text-lg font-bold text-foreground">10</p>
                </div>
                <div className="text-center">
                  <p className="text-xs text-muted-foreground mb-1">Net Result</p>
                  <p className={`text-lg font-bold ${totalR >= 0 ? "text-primary" : "text-destructive"}`}>
                    {totalR >= 0 ? "+" : ""}{totalR.toFixed(1)}R
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Education Panel */}
        <section className="mb-8">
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
            Understanding Risk/Reward
          </h2>
          
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex gap-3 mb-4">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                <Info className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-sm text-foreground leading-relaxed">
                  Trading success is not about winning every trade.
                </p>
              </div>
            </div>
            
            <div className="space-y-3 text-sm text-muted-foreground leading-relaxed">
              <p>
                SightLine strategies are built around risk/reward discipline. Each setup defines a clear entry, stop loss, and target before the trade is taken.
              </p>
              <p>
                Even with a moderate win rate of 40-50%, consistent reward-to-risk ratios of 2:1 or higher can produce profitable outcomes over time.
              </p>
              <p>
                The key is consistency: taking the same types of setups, with the same risk parameters, over a meaningful sample size.
              </p>
            </div>

            {/* Simple Math Example */}
            <div className="mt-5 p-4 rounded-lg border border-border bg-background/50">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                Example Math
              </p>
              <div className="space-y-2 text-sm">
                <p className="text-muted-foreground">
                  <span className="text-foreground font-medium">Win Rate:</span> 45%
                </p>
                <p className="text-muted-foreground">
                  <span className="text-foreground font-medium">Average Win:</span> +2.2R
                </p>
                <p className="text-muted-foreground">
                  <span className="text-foreground font-medium">Average Loss:</span> -1R
                </p>
                <div className="pt-2 border-t border-border mt-2">
                  <p className="text-muted-foreground">
                    <span className="text-foreground font-medium">10 Trades:</span> 4.5 wins × 2.2R = +9.9R | 5.5 losses × 1R = -5.5R
                  </p>
                  <p className="text-primary font-semibold mt-1">
                    Net Result: +4.4R
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Disclaimer */}
        <section className="rounded-xl border border-border bg-muted/30 p-5">
          <p className="text-xs text-muted-foreground leading-relaxed">
            <span className="font-semibold text-foreground/80">Important:</span> No strategy wins on every trade. SightLine identifies structured opportunities with defined risk, but outcomes can vary depending on execution and market conditions. Past simulated performance does not guarantee future results. Always trade with capital you can afford to lose.
          </p>
        </section>
      </main>
    </div>
  )
}
