"use client"

import { Settings, Bell, Shield, User, CreditCard, LogOut, Target, Check } from "lucide-react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { SignalStrictness } from "@/lib/storage"

const STRICTNESS_OPTIONS: { value: SignalStrictness; label: string; description: string; grades: string }[] = [
  {
    value: "conservative",
    label: "Conservative",
    description: "Only the highest quality setups",
    grades: "Grade A only",
  },
  {
    value: "balanced",
    label: "Balanced",
    description: "High quality with some flexibility",
    grades: "Grade A + B",
  },
  {
    value: "active",
    label: "Active",
    description: "More signals, wider range of setups",
    grades: "Grade A + B + C",
  },
]

export default function SettingsPage() {
  const router = useRouter()
  const [notifications, setNotifications] = useState({
    email: true,
    push: true,
    sms: false,
    telegram: false,
  })
  const [strictness, setStrictness] = useState<SignalStrictness>("balanced")
  const [minimumRR, setMinimumRR] = useState(2)
  const [requireHTF, setRequireHTF] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    // Load settings from localStorage
    const settings = localStorage.getItem("sightline_settings")
    if (settings) {
      const parsed = JSON.parse(settings)
      setStrictness(parsed.signalStrictness || "balanced")
      setMinimumRR(parsed.minimumRiskReward || 2)
      setRequireHTF(parsed.requireHigherTimeframeConfirmation || false)
    }
  }, [])

  const handleSaveSignalSettings = () => {
    const settings = {
      signalStrictness: strictness,
      minimumRiskReward: minimumRR,
      requireHigherTimeframeConfirmation: requireHTF,
    }
    localStorage.setItem("sightline_settings", JSON.stringify(settings))
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleLogout = () => {
    localStorage.removeItem("sightline_logged_in")
    router.push("/")
  }

  return (
    <div className="min-h-screen bg-background p-4 lg:p-6 pb-24">
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Link
          href="/dashboard"
          className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary"
        >
          <Settings className="h-5 w-5" />
        </Link>
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Settings</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage your account and signal preferences
          </p>
        </div>
      </div>

      <div className="space-y-6 max-w-2xl">
        {/* Signal Quality Section - NEW */}
        <div className="rounded-xl border border-primary/30 bg-card p-5">
          <div className="flex items-center gap-3 mb-4">
            <Target className="h-5 w-5 text-primary" />
            <h2 className="font-semibold text-foreground">Signal Quality Filter</h2>
          </div>
          <p className="text-xs text-muted-foreground mb-4">
            Choose how strict you want signal filtering to be. Conservative mode shows fewer but higher quality signals.
          </p>
          <div className="space-y-3 mb-6">
            {STRICTNESS_OPTIONS.map((option) => (
              <button
                key={option.value}
                onClick={() => setStrictness(option.value)}
                className={`w-full rounded-xl border p-4 text-left transition-all ${
                  strictness === option.value
                    ? "border-primary bg-primary/5"
                    : "border-border hover:border-primary/30"
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold text-foreground">{option.label}</span>
                    {strictness === option.value && (
                      <Check className="h-4 w-4 text-primary" />
                    )}
                  </div>
                  <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                    option.value === "conservative" ? "bg-primary/20 text-primary" :
                    option.value === "balanced" ? "bg-amber-500/20 text-amber-500" :
                    "bg-muted text-muted-foreground"
                  }`}>
                    {option.grades}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">{option.description}</p>
              </button>
            ))}
          </div>

          {/* Minimum R:R */}
          <div className="mb-6">
            <label className="text-sm font-medium text-foreground mb-2 block">
              Minimum Risk/Reward Ratio
            </label>
            <div className="flex items-center gap-4">
              <input
                type="range"
                min={1}
                max={5}
                step={0.5}
                value={minimumRR}
                onChange={(e) => setMinimumRR(parseFloat(e.target.value))}
                className="flex-1 h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <span className="text-sm font-bold text-foreground w-12 text-center bg-muted rounded-lg py-1">{minimumRR}R</span>
            </div>
          </div>

          {/* HTF Confirmation Toggle */}
          <label className="flex items-center justify-between cursor-pointer mb-4">
            <div>
              <span className="text-sm font-medium text-foreground block">Require HTF Confirmation</span>
              <span className="text-xs text-muted-foreground">Only signals aligned with higher timeframe</span>
            </div>
            <button
              onClick={() => setRequireHTF(!requireHTF)}
              className={`relative h-6 w-11 rounded-full transition-colors ${
                requireHTF ? "bg-primary" : "bg-border"
              }`}
            >
              <span
                className={`absolute top-1 left-1 h-4 w-4 rounded-full bg-white transition-transform ${
                  requireHTF ? "translate-x-5" : "translate-x-0"
                }`}
              />
            </button>
          </label>

          {/* Save Signal Settings Button */}
          <button
            onClick={handleSaveSignalSettings}
            className={`w-full flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition-all ${
              saved
                ? "bg-primary/20 text-primary"
                : "bg-primary text-primary-foreground hover:bg-primary/90"
            }`}
          >
            {saved ? (
              <>
                <Check className="h-4 w-4" />
                Settings Saved
              </>
            ) : (
              "Save Signal Settings"
            )}
          </button>
        </div>

        {/* Profile Section */}
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center gap-3 mb-4">
            <User className="h-5 w-5 text-primary" />
            <h2 className="font-semibold text-foreground">Profile</h2>
          </div>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-muted-foreground">Name</label>
              <input
                type="text"
                defaultValue="Trader"
                className="mt-1 w-full h-10 rounded-lg border border-border bg-background px-3 text-foreground focus:border-primary focus:outline-none"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Email</label>
              <input
                type="email"
                defaultValue="trader@example.com"
                className="mt-1 w-full h-10 rounded-lg border border-border bg-background px-3 text-foreground focus:border-primary focus:outline-none"
              />
            </div>
            <div>
              <label className="text-sm text-muted-foreground">Phone</label>
              <input
                type="tel"
                placeholder="+1 (555) 000-0000"
                className="mt-1 w-full h-10 rounded-lg border border-border bg-background px-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Notifications Section */}
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center gap-3 mb-4">
            <Bell className="h-5 w-5 text-primary" />
            <h2 className="font-semibold text-foreground">Notifications</h2>
          </div>
          <div className="space-y-4">
            {Object.entries(notifications).map(([key, value]) => (
              <label key={key} className="flex items-center justify-between cursor-pointer">
                <span className="text-sm text-foreground capitalize">{key} Notifications</span>
                <button
                  onClick={() => setNotifications({ ...notifications, [key]: !value })}
                  className={`relative h-6 w-11 rounded-full transition-colors ${
                    value ? "bg-primary" : "bg-border"
                  }`}
                >
                  <span
                    className={`absolute top-1 left-1 h-4 w-4 rounded-full bg-white transition-transform ${
                      value ? "translate-x-5" : "translate-x-0"
                    }`}
                  />
                </button>
              </label>
            ))}
          </div>
        </div>

        {/* Subscription Section */}
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center gap-3 mb-4">
            <CreditCard className="h-5 w-5 text-primary" />
            <h2 className="font-semibold text-foreground">Subscription</h2>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-foreground">Starter Plan</p>
              <p className="text-sm text-muted-foreground">$14.99/month</p>
            </div>
            <Link
              href="/#pricing"
              className="rounded-lg border border-primary bg-primary/10 px-4 py-2 text-sm font-medium text-primary hover:bg-primary/20 transition-colors"
            >
              Upgrade
            </Link>
          </div>
        </div>

        {/* Security Section */}
        <div className="rounded-xl border border-border bg-card p-5">
          <div className="flex items-center gap-3 mb-4">
            <Shield className="h-5 w-5 text-primary" />
            <h2 className="font-semibold text-foreground">Security</h2>
          </div>
          <div className="space-y-3">
            <button className="w-full text-left rounded-lg border border-border bg-background px-4 py-3 text-sm text-foreground hover:border-primary/30 transition-colors">
              Change Password
            </button>
            <button className="w-full text-left rounded-lg border border-border bg-background px-4 py-3 text-sm text-foreground hover:border-primary/30 transition-colors">
              Two-Factor Authentication
            </button>
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={handleLogout}
          className="flex items-center justify-center gap-2 w-full rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm font-medium text-destructive hover:bg-destructive/20 transition-colors"
        >
          <LogOut className="h-4 w-4" />
          Log Out
        </button>
      </div>
    </div>
  )
}
