"use client";

import { TrendingUp, Target, BarChart3, Calendar, ArrowUp, ArrowDown } from "lucide-react";

const stats = [
  { label: "Win Rate", value: "68%", change: "+3%", positive: true, icon: Target },
  { label: "Avg R:R", value: "2.4:1", change: "+0.2", positive: true, icon: BarChart3 },
  { label: "Total Trades", value: "47", change: "+12", positive: true, icon: Calendar },
  { label: "Profit Factor", value: "1.85", change: "+0.15", positive: true, icon: TrendingUp },
];

const recentTrades = [
  { symbol: "SPY", direction: "LONG", result: "Win", rMultiple: "+2.1R", date: "Today" },
  { symbol: "BTC", direction: "SHORT", result: "Loss", rMultiple: "-1.0R", date: "Today" },
  { symbol: "SOL", direction: "LONG", result: "Win", rMultiple: "+1.8R", date: "Yesterday" },
  { symbol: "QQQ", direction: "SHORT", result: "Win", rMultiple: "+2.5R", date: "Yesterday" },
  { symbol: "ETH", direction: "LONG", result: "Loss", rMultiple: "-1.0R", date: "Mar 3" },
  { symbol: "AAPL", direction: "LONG", result: "Win", rMultiple: "+1.4R", date: "Mar 3" },
];

const weeklyData = [
  { day: "Mon", wins: 3, losses: 1 },
  { day: "Tue", wins: 2, losses: 2 },
  { day: "Wed", wins: 4, losses: 0 },
  { day: "Thu", wins: 2, losses: 1 },
  { day: "Fri", wins: 3, losses: 2 },
];

export default function PerformancePage() {
  const totalWins = weeklyData.reduce((acc, d) => acc + d.wins, 0);
  const totalLosses = weeklyData.reduce((acc, d) => acc + d.losses, 0);
  const maxTrades = Math.max(...weeklyData.map((d) => d.wins + d.losses));

  return (
    <div className="min-h-screen bg-background p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-start gap-3 mb-6">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <TrendingUp className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Performance</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            Track your strategy performance over time
          </p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="rounded-xl border border-border bg-card p-4 card-glow"
          >
            <div className="flex items-center gap-2 mb-2">
              <stat.icon className="h-4 w-4 text-primary" />
              <span className="text-xs text-muted-foreground">{stat.label}</span>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-bold text-foreground">{stat.value}</span>
              <span className={`text-xs font-medium ${stat.positive ? "text-primary" : "text-destructive"}`}>
                {stat.change}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Weekly Chart */}
      <div className="rounded-xl border border-border bg-card p-5 mb-6">
        <h2 className="text-sm font-semibold text-foreground mb-4">This Week</h2>
        <div className="flex items-end justify-between gap-4 h-32">
          {weeklyData.map((d) => (
            <div key={d.day} className="flex-1 flex flex-col items-center gap-2">
              <div className="w-full flex flex-col gap-1">
                <div
                  className="w-full bg-primary/80 rounded-t"
                  style={{ height: `${(d.wins / maxTrades) * 80}px` }}
                />
                <div
                  className="w-full bg-destructive/80 rounded-b"
                  style={{ height: `${(d.losses / maxTrades) * 80}px` }}
                />
              </div>
              <span className="text-xs text-muted-foreground">{d.day}</span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-center gap-6 mt-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded bg-primary/80" />
            <span className="text-muted-foreground">Wins ({totalWins})</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded bg-destructive/80" />
            <span className="text-muted-foreground">Losses ({totalLosses})</span>
          </div>
        </div>
      </div>

      {/* Recent Trades */}
      <div className="rounded-xl border border-border bg-card p-5">
        <h2 className="text-sm font-semibold text-foreground mb-4">Recent Trades</h2>
        <div className="space-y-3">
          {recentTrades.map((trade, i) => (
            <div
              key={i}
              className="flex items-center justify-between py-2 border-b border-border/50 last:border-0"
            >
              <div className="flex items-center gap-3">
                <div
                  className={`flex h-8 w-8 items-center justify-center rounded-lg ${
                    trade.result === "Win" ? "bg-primary/10" : "bg-destructive/10"
                  }`}
                >
                  {trade.result === "Win" ? (
                    <ArrowUp className="h-4 w-4 text-primary" />
                  ) : (
                    <ArrowDown className="h-4 w-4 text-destructive" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-foreground">{trade.symbol}</span>
                    <span
                      className={`text-xs ${
                        trade.direction === "LONG" ? "text-primary" : "text-destructive"
                      }`}
                    >
                      {trade.direction}
                    </span>
                  </div>
                  <span className="text-xs text-muted-foreground">{trade.date}</span>
                </div>
              </div>
              <span
                className={`text-sm font-semibold ${
                  trade.result === "Win" ? "text-primary" : "text-destructive"
                }`}
              >
                {trade.rMultiple}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
