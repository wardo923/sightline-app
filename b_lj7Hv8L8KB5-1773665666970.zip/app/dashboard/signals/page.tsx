"use client";

import { Bell, TrendingUp, TrendingDown, Filter, Search } from "lucide-react";
import { useState } from "react";

interface Signal {
  id: string;
  symbol: string;
  direction: "LONG" | "SHORT";
  entry: string;
  stop: string;
  target: string;
  rr: string;
  time: string;
  status: "delivered" | "viewed" | "executed";
  market: "Stocks" | "Crypto";
}

const mockSignals: Signal[] = [
  { id: "1", symbol: "SPY", direction: "LONG", entry: "$502.40", stop: "$501.10", target: "$504.20", rr: "1.4:1", time: "Today, 9:45 AM", status: "delivered", market: "Stocks" },
  { id: "2", symbol: "BTC", direction: "SHORT", entry: "$68,950", stop: "$69,480", target: "$68,150", rr: "1.5:1", time: "Today, 10:15 AM", status: "viewed", market: "Crypto" },
  { id: "3", symbol: "SOL", direction: "LONG", entry: "$178.20", stop: "$175.90", target: "$185.00", rr: "2.9:1", time: "Today, 11:30 AM", status: "executed", market: "Crypto" },
  { id: "4", symbol: "QQQ", direction: "SHORT", entry: "$446.80", stop: "$448.10", target: "$443.50", rr: "2.5:1", time: "Yesterday, 2:30 PM", status: "executed", market: "Stocks" },
  { id: "5", symbol: "AAPL", direction: "LONG", entry: "$193.60", stop: "$192.40", target: "$196.20", rr: "2.2:1", time: "Yesterday, 10:00 AM", status: "viewed", market: "Stocks" },
  { id: "6", symbol: "ETH", direction: "SHORT", entry: "$3,520", stop: "$3,575", target: "$3,425", rr: "1.7:1", time: "Mar 3, 3:45 PM", status: "delivered", market: "Crypto" },
];

export default function SignalsPage() {
  const [filter, setFilter] = useState<"all" | "delivered" | "viewed" | "executed">("all");

  const filtered = filter === "all" ? mockSignals : mockSignals.filter((s) => s.status === filter);

  return (
    <div className="min-h-screen bg-background p-4 lg:p-6">
      {/* Header */}
      <div className="flex items-start gap-3 mb-6">
        <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Bell className="h-5 w-5" />
        </div>
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Signals</h1>
          <p className="text-sm text-muted-foreground mt-0.5">
            All signals delivered to your strategy profile
          </p>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between mb-6">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search signals..."
            className="h-10 w-full lg:w-72 rounded-lg border border-border bg-card pl-10 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-muted-foreground" />
          {(["all", "delivered", "viewed", "executed"] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`rounded-full px-3 py-1.5 text-sm border capitalize transition-colors ${
                filter === f
                  ? "bg-primary/10 border-primary/50 text-primary font-medium"
                  : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Signals List */}
      <div className="space-y-3">
        {filtered.map((signal) => (
          <div
            key={signal.id}
            className="rounded-xl border border-border bg-card p-4 hover:border-primary/30 transition-colors card-glow"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="text-lg font-semibold text-foreground">{signal.symbol}</span>
                <span
                  className={`inline-flex items-center gap-1 text-xs font-medium rounded-full px-2 py-0.5 border ${
                    signal.direction === "LONG"
                      ? "border-primary/50 text-primary bg-primary/10"
                      : "border-destructive/50 text-destructive bg-destructive/10"
                  }`}
                >
                  {signal.direction === "LONG" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
                  {signal.direction}
                </span>
                <span className="text-xs rounded-full px-2 py-0.5 border border-border text-muted-foreground">
                  {signal.market}
                </span>
              </div>
              <span
                className={`text-xs rounded-full px-2 py-0.5 border capitalize ${
                  signal.status === "delivered"
                    ? "border-muted-foreground/30 text-muted-foreground bg-muted/50"
                    : signal.status === "viewed"
                    ? "border-amber-500/30 text-amber-500 bg-amber-500/10"
                    : "border-primary/50 text-primary bg-primary/10"
                }`}
              >
                {signal.status}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-3 text-sm">
              <div>
                <div className="text-xs text-muted-foreground">Entry</div>
                <div className="font-medium text-foreground">{signal.entry}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Stop</div>
                <div className="font-medium text-destructive">{signal.stop}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Target</div>
                <div className="font-medium text-primary">{signal.target}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground">R:R</div>
                <div className="font-medium text-foreground">{signal.rr}</div>
              </div>
            </div>

            <div className="mt-3 text-xs text-muted-foreground">{signal.time}</div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="mt-12 text-center">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-surface">
            <Bell className="h-8 w-8 text-muted-foreground" />
          </div>
          <h3 className="mt-4 text-lg font-medium text-foreground">No signals found</h3>
          <p className="mt-1 text-sm text-muted-foreground">
            Adjust your filters or check back later
          </p>
        </div>
      )}
    </div>
  );
}
