"use client";

import * as React from "react";
import type { Trade, TradeStatus } from "@/lib/trade-types";
import { mockTrades } from "@/lib/mock-trades";
import { TradeCard } from "@/components/trade-card";
import { TradeDetailDrawer } from "@/components/trade-detail-drawer";
import { Radar, Filter } from "lucide-react";

const statusFilters: { value: TradeStatus | "ALL"; label: string }[] = [
  { value: "ALL", label: "All" },
  { value: "READY", label: "Ready" },
  { value: "WAITING", label: "Waiting" },
  { value: "ACTIVE", label: "Active" },
  { value: "INVALIDATED", label: "Invalidated" },
];

const marketFilters = ["All", "Stocks", "Crypto"];

export default function TradeRadarPage() {
  const [status, setStatus] = React.useState<TradeStatus | "ALL">("ALL");
  const [market, setMarket] = React.useState("All");
  const [oneTradeAtATime, setOneTradeAtATime] = React.useState(true);
  const [selectedTrade, setSelectedTrade] = React.useState<Trade | null>(null);

  const hasActive = mockTrades.some((t) => t.status === "ACTIVE");
  const canStartNew = !oneTradeAtATime || !hasActive;

  const filtered = mockTrades.filter((t) => {
    if (status !== "ALL" && t.status !== status) return false;
    if (market !== "All" && t.market !== market) return false;
    return true;
  });

  // Count by status for badges
  const counts = {
    ALL: mockTrades.length,
    READY: mockTrades.filter((t) => t.status === "READY").length,
    WAITING: mockTrades.filter((t) => t.status === "WAITING").length,
    ACTIVE: mockTrades.filter((t) => t.status === "ACTIVE").length,
    INVALIDATED: mockTrades.filter((t) => t.status === "INVALIDATED").length,
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="p-4 lg:p-6">
        {/* Header */}
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="flex items-start gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
              <Radar className="h-5 w-5" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold text-foreground">Trade Radar</h1>
              <p className="text-sm text-muted-foreground mt-0.5">
                Clear, risk-defined setups from your strategy profile
              </p>
            </div>
          </div>

          <label className="flex items-center gap-3 rounded-lg border border-border bg-card px-4 py-2.5 cursor-pointer hover:border-primary/30 transition-colors">
            <input
              type="checkbox"
              checked={oneTradeAtATime}
              onChange={(e) => setOneTradeAtATime(e.target.checked)}
              className="h-4 w-4 rounded border-border text-primary focus:ring-primary focus:ring-offset-background"
            />
            <span className="text-sm text-foreground">One trade at a time</span>
          </label>
        </div>

        {/* Active trade warning */}
        {!canStartNew && (
          <div className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm text-amber-500">
            You currently have an <span className="font-semibold">ACTIVE</span> trade. New entries are paused while &quot;One trade at a time&quot; is enabled.
          </div>
        )}

        {/* Filters */}
        <div className="mt-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          {/* Status filter */}
          <div className="flex flex-wrap items-center gap-2">
            {statusFilters.map((f) => (
              <button
                key={f.value}
                onClick={() => setStatus(f.value)}
                className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-sm border transition-colors ${
                  status === f.value
                    ? "bg-primary/10 border-primary/50 text-primary font-medium"
                    : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
                }`}
              >
                {f.label}
                <span className={`text-xs ${status === f.value ? "text-primary/70" : "text-muted-foreground/70"}`}>
                  {counts[f.value]}
                </span>
              </button>
            ))}
          </div>

          {/* Market filter */}
          <div className="flex items-center gap-2">
            <Filter className="h-4 w-4 text-muted-foreground" />
            {marketFilters.map((m) => (
              <button
                key={m}
                onClick={() => setMarket(m)}
                className={`rounded-full px-3 py-1.5 text-sm border transition-colors ${
                  market === m
                    ? "bg-primary/10 border-primary/50 text-primary font-medium"
                    : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
                }`}
              >
                {m}
              </button>
            ))}
          </div>
        </div>

        {/* Trade cards grid */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((t) => (
            <TradeCard key={t.id} trade={t} onOpen={setSelectedTrade} />
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="mt-12 text-center">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-surface">
              <Radar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="mt-4 text-lg font-medium text-foreground">No trades found</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Adjust your filters or check back later for new setups
            </p>
          </div>
        )}
      </div>

      {/* Trade detail drawer */}
      {selectedTrade && (
        <TradeDetailDrawer trade={selectedTrade} onClose={() => setSelectedTrade(null)} />
      )}
    </div>
  );
}
