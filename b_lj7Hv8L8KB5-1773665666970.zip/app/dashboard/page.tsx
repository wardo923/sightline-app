"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { 
  Bell, 
  TrendingUp, 
  TrendingDown, 
  Activity, 
  Target, 
  Zap,
  Settings,
  ChevronRight,
  Crosshair,
  LogOut,
  Shield,
  Lock,
  RefreshCw,
  Eye,
  AlertTriangle,
  ArrowDownUp,
  Clock,
  Layers,
  Check,
  Plus,
  Calendar,
} from "lucide-react"
import { TradeBox } from "@/components/trade-box"
import { useSignals, Signal } from "@/hooks/use-signals"
import { useMarketData } from "@/hooks/use-market-data"
import { createClient } from "@/lib/supabase/client"
import { STRATEGY_INFO, StrategyKey } from "@/lib/strategies"

// Icon mapping for strategies
const STRATEGY_ICONS: Record<StrategyKey, typeof Zap> = {
  MOMENTUM_BREAKOUT: TrendingUp,
  LIQUIDITY_REVERSAL: ArrowDownUp,
  STRUCTURE_REACTION: Target,
  OPENING_RANGE: Clock,
  VOLATILITY_EXPANSION: Zap,
  SESSION_STRUCTURE: Layers
}

interface UserStrategy {
  id: string
  name?: string
  bundle_name: string
  asset: string
  market_type: string
  timeframe: string
  trading_style?: string
  setup_preference?: string
  signal_frequency?: string
  confirmation_style?: string
  alert_frequency: string
  confidence_score: number
  wizard_answers: Record<string, string>
  created_at: string
}

interface UsageStats {
  tier: string
  signalsToday: number
  signalsLimit: number
  alertsToday: number
  alertsLimit: number
  scansToday: number
  scansLimit: number
  assetsMonitored: number
  assetsLimit: number
}

export default function DashboardPage() {
  const router = useRouter()
  const { signals, unreadCount, isLoading: signalsLoading, markAsRead, refreshSignals } = useSignals()
  const [strategies, setStrategies] = useState<UserStrategy[]>([])
  const [activeStrategy, setActiveStrategy] = useState<UserStrategy | null>(null)
  const [userName, setUserName] = useState<string>("")
  const [isLoading, setIsLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [showUserMenu, setShowUserMenu] = useState(false)
  const [usage, setUsage] = useState<UsageStats | null>(null)
  
  // Live market data for user's selected asset
  const { marketData, isLoading: marketLoading } = useMarketData(activeStrategy?.asset || "")

  useEffect(() => {
    async function loadUserData() {
      try {
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()
        
        if (!user) {
          router.replace("/auth/login")
          return
        }
        
        // Set username from email immediately
        if (user.email) {
          setUserName(user.email.split('@')[0])
        }
        
        // Fetch user profile - MUST check wizard_completed
        const { data: profile } = await supabase
          .from("profiles")
          .select("name, email, wizard_completed")
          .eq("id", user.id)
          .single()
        
        // Check wizard completion FIRST before anything else
        if (!profile?.wizard_completed) {
          router.replace("/strategy-wizard")
          return
        }
        
        if (profile?.name) {
          setUserName(profile.name)
        } else if (profile?.email) {
          setUserName(profile.email.split('@')[0])
        }
        
        // Fetch ALL user strategies
        const { data: strategiesData } = await supabase
          .from("strategies")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
        
        if (strategiesData && strategiesData.length > 0) {
          setStrategies(strategiesData)
          // Set the most recent strategy as active
          setActiveStrategy(strategiesData[0])
          
          // Fetch usage stats
          try {
            const usageRes = await fetch("/api/signals/scan")
            if (usageRes.ok) {
              const usageData = await usageRes.json()
              setUsage({
                tier: usageData.tier || "STARTER",
                signalsToday: usageData.usage?.signalsToday || 0,
                signalsLimit: usageData.usage?.signalsLimit || 5,
                alertsToday: usageData.usage?.alertsToday || 0,
                alertsLimit: usageData.usage?.alertsLimit || 10,
                scansToday: usageData.usage?.scansToday || 0,
                scansLimit: usageData.usage?.scansLimit || 12,
                assetsMonitored: usageData.usage?.assetsMonitored || 0,
                assetsLimit: usageData.usage?.assetsLimit || 3,
              })
            }
          } catch {
            // Usage fetch failed - continue without it
          }
        }
        // Even if no strategy found, stay on dashboard if onboarding_complete is true
        // User can retake wizard from menu
        setIsLoading(false)
      } catch (err) {
        setLoadError(err instanceof Error ? err.message : "Failed to load dashboard")
        setIsLoading(false)
      }
    }
    
    loadUserData()
  }, [router])

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    localStorage.removeItem("sightline_logged_in")
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }
  
  if (loadError) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center bg-background px-4">
        <div className="text-center">
          <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
          <h1 className="text-xl font-bold text-foreground mb-2">Failed to load dashboard</h1>
          <p className="text-sm text-muted-foreground mb-4">{loadError}</p>
          <button
            onClick={() => window.location.reload()}
            className="rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
          >
            Retry
          </button>
        </div>
      </div>
    )
  }

  // Get strategy info from the bundle system
  // Check wizard_answers for matrix bundle if bundle_name is not set directly
  const getStrategyKey = (): StrategyKey | null => {
    if (!activeStrategy) return null
    // Direct bundle_name from database takes priority
    if (activeStrategy.bundle_name) return activeStrategy.bundle_name as StrategyKey
    // Fall back to matrix bundle stored in wizard_answers
    const wizardAnswers = activeStrategy.wizard_answers as { _matrixBundle?: string } | undefined
    if (wizardAnswers?._matrixBundle) return wizardAnswers._matrixBundle as StrategyKey
    return null
  }
  
  const strategyKey = getStrategyKey()
  const strategyInfo = strategyKey ? STRATEGY_INFO[strategyKey] : null
  const StrategyIcon = strategyKey ? (STRATEGY_ICONS[strategyKey] || Activity) : Activity
  
  const activeSignals = signals.filter(s => s.status === "pending" || s.status === "active")
  const recentSignals = signals.slice(0, 5)

  // Generate strategy display name from wizard answers
  const getStrategyDisplayName = (s: UserStrategy): string => {
    if (s.name) return s.name
    const asset = s.asset || "Multi-Asset"
    const setup = s.setup_preference || s.bundle_name?.replace(/_/g, " ") || "Strategy"
    const pace = s.trading_style || s.signal_frequency || "Active"
    return `${asset} ${setup} ${pace}`
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 flex items-center justify-between border-b border-border bg-card/95 px-4 py-3 backdrop-blur-sm pt-safe">
        <Link href="/" className="flex items-center gap-2">
          <Crosshair className="h-6 w-6 text-primary" />
          <span className="text-lg font-bold text-foreground">SightLine</span>
        </Link>
        
        <div className="flex items-center gap-3">
          {/* Notification Bell */}
          <button className="relative rounded-lg p-2 transition-colors hover:bg-muted">
            <Bell className="h-5 w-5 text-muted-foreground" />
            {unreadCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-primary-foreground">
                {unreadCount > 9 ? "9+" : unreadCount}
              </span>
            )}
          </button>
          
          {/* User Menu */}
          <div className="relative">
            <button 
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-sm font-bold text-primary"
            >
              {userName ? userName.charAt(0).toUpperCase() : "U"}
            </button>
            
            {showUserMenu && (
              <div className="absolute right-0 top-10 w-48 rounded-xl border border-border bg-card p-2 shadow-lg">
                <p className="truncate px-3 py-2 text-xs text-muted-foreground">{userName}</p>
                <hr className="my-1 border-border" />
                <Link
                  href="/profile"
                  onClick={() => setShowUserMenu(false)}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-foreground transition-colors hover:bg-muted"
                >
                  <Settings className="h-4 w-4" />
                  Settings
                </Link>
                <Link
                  href="/signals/preview"
                  onClick={() => setShowUserMenu(false)}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-foreground transition-colors hover:bg-muted"
                >
                  <Eye className="h-4 w-4" />
                  Signal Preview
                </Link>
                <Link
                  href="/strategy-wizard"
                  onClick={() => setShowUserMenu(false)}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-foreground transition-colors hover:bg-muted"
                >
                  <RefreshCw className="h-4 w-4" />
                  Retake Wizard
                </Link>
                <button
                  onClick={handleLogout}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-foreground transition-colors hover:bg-muted"
                >
                  <LogOut className="h-4 w-4" />
                  Sign out
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto px-4 py-6 pb-safe">
        <div className="mx-auto max-w-lg space-y-6">
          
          {/* Welcome Greeting with Tier Badge */}
          {userName && (
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-1">
                <h1 className="text-lg font-bold text-foreground">
                  Welcome back, {userName}
                </h1>
                {usage && (
                  <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wider ${
                    usage.tier === 'ELITE' ? 'bg-amber-500/20 text-amber-500' :
                    usage.tier === 'PRO' ? 'bg-primary/20 text-primary' :
                    'bg-muted text-muted-foreground'
                  }`}>
                    {usage.tier}
                  </span>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Your strategy is actively monitoring the markets.
              </p>
            </div>
          )}
          
          {/* Usage Limits Card */}
          {usage && (
            <div className="rounded-xl border border-border bg-card/50 p-4">
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-xs font-semibold text-foreground">Daily Usage</h3>
                <Link href="/pricing" className="text-[10px] text-primary hover:underline">
                  {usage.tier === 'STARTER' ? 'Upgrade Plan' : 'Manage Plan'}
                </Link>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-muted-foreground">Signals</span>
                    <span className="text-[10px] text-muted-foreground">{usage.signalsToday}/{usage.signalsLimit}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        usage.signalsToday >= usage.signalsLimit ? 'bg-destructive' : 'bg-primary'
                      }`}
                      style={{ width: `${Math.min(100, (usage.signalsToday / usage.signalsLimit) * 100)}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-muted-foreground">Alerts</span>
                    <span className="text-[10px] text-muted-foreground">{usage.alertsToday}/{usage.alertsLimit}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        usage.alertsToday >= usage.alertsLimit ? 'bg-destructive' : 'bg-primary'
                      }`}
                      style={{ width: `${Math.min(100, (usage.alertsToday / usage.alertsLimit) * 100)}%` }}
                    />
                  </div>
                </div>
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-muted-foreground">Assets</span>
                    <span className="text-[10px] text-muted-foreground">{usage.assetsMonitored}/{usage.assetsLimit}</span>
                  </div>
                  <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                    <div 
                      className={`h-full rounded-full transition-all ${
                        usage.assetsMonitored >= usage.assetsLimit ? 'bg-destructive' : 'bg-primary'
                      }`}
                      style={{ width: `${Math.min(100, (usage.assetsMonitored / usage.assetsLimit) * 100)}%` }}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
          
          {/* Strategy Profile Card - Per Spec Step 10 */}
          {strategyInfo && activeStrategy && (
            <div className="rounded-2xl border border-border bg-gradient-to-br from-primary/5 to-background p-5">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-xl bg-primary/10 p-3 text-primary">
                    <StrategyIcon className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Your Strategy</p>
                    <h2 className="text-lg font-bold text-foreground">{strategyInfo.name}</h2>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <div className="flex items-center gap-1.5 rounded-full bg-primary/20 px-3 py-1.5">
                    <div className="h-2 w-2 rounded-full bg-primary animate-pulse" />
                    <span className="text-xs font-semibold text-primary">
                      {marketData?.isMarketOpen ? "Live" : "Closed"}
                    </span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">
                    {activeStrategy.signal_frequency === "Balanced" ? "Standard" : "High Selectivity"}
                  </span>
                </div>
              </div>
              
              {/* Live Price Display */}
              {marketData && (
                <div className="mt-4 rounded-xl bg-background/60 p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-muted-foreground">Live Price · {activeStrategy.asset}</p>
                      <p className="text-2xl font-bold text-foreground">
                        ${marketData.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                      </p>
                    </div>
                    <div className={`text-right ${marketData.change >= 0 ? "text-primary" : "text-destructive"}`}>
                      <p className="text-lg font-semibold">
                        {marketData.change >= 0 ? "+" : ""}{marketData.change.toFixed(2)}
                      </p>
                      <p className="text-xs">
                        ({marketData.change >= 0 ? "+" : ""}{marketData.changePercent.toFixed(2)}%)
                      </p>
                    </div>
                  </div>
                  <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
                    <span>H: ${marketData.high.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    <span>L: ${marketData.low.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                    <span>Vol: {(marketData.volume / 1000000).toFixed(2)}M</span>
                  </div>
                </div>
              )}
              
              {/* Strategy Profile Summary - Per Spec Step 10 */}
              <div className="mt-5 grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-background/50 p-3">
                  <p className="text-[10px] text-muted-foreground mb-1">Alert Mode</p>
                  <p className="text-sm font-semibold text-foreground">
                    {activeStrategy.signal_frequency === "Balanced" ? "Standard" : "High Selectivity"}
                  </p>
                </div>
                <div className="rounded-xl bg-background/50 p-3">
                  <p className="text-[10px] text-muted-foreground mb-1">Primary Asset</p>
                  <p className="text-sm font-semibold text-foreground">{activeStrategy.asset}</p>
                </div>
                <div className="rounded-xl bg-background/50 p-3">
                  <p className="text-[10px] text-muted-foreground mb-1">Primary Timeframe</p>
                  <p className="text-sm font-semibold text-foreground">{activeStrategy.timeframe}</p>
                </div>
                <div className="rounded-xl bg-background/50 p-3">
                  <p className="text-[10px] text-muted-foreground mb-1">Market</p>
                  <p className="text-sm font-semibold text-foreground">
                    {activeStrategy.market_type === "crypto" ? "Crypto" : "Stocks"}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Today's Market Activity */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground">Today&apos;s Market Activity</h3>
              <GenerateDemoButton 
                asset={activeStrategy?.asset || 'SPY'} 
                framework={strategyKey}
                onGenerated={refreshSignals}
              />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="rounded-xl border border-border bg-card/50 p-4 text-center">
                <p className="text-2xl font-bold text-foreground">
                  {signals.filter(s => {
                    const today = new Date()
                    const signalDate = new Date(s.created_at)
                    return signalDate.toDateString() === today.toDateString()
                  }).length}
                </p>
                <p className="text-xs text-muted-foreground mt-1">Setups Detected</p>
              </div>
              <div className="rounded-xl border border-border bg-card/50 p-4 text-center">
                <p className="text-2xl font-bold text-foreground">
                  {signals.filter(s => {
                    const today = new Date()
                    const signalDate = new Date(s.created_at)
                    return signalDate.toDateString() === today.toDateString() && (s.status === 'pending' || s.status === 'active')
                  }).length}
                </p>
                <p className="text-xs text-muted-foreground mt-1">Active Now</p>
              </div>
              <div className="rounded-xl border border-border bg-card/50 p-4 text-center">
                <p className="text-2xl font-bold text-primary">
                  {signals.filter(s => {
                    const today = new Date()
                    const signalDate = new Date(s.created_at)
                    return signalDate.toDateString() === today.toDateString() && s.status === 'triggered'
                  }).length}
                </p>
                <p className="text-xs text-muted-foreground mt-1">Triggered</p>
              </div>
            </div>
          </div>

          {/* Active Signals */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground">Active Setups</h3>
              <button 
                onClick={() => refreshSignals()}
                className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
              >
                <RefreshCw className="h-3 w-3" />
                Refresh
              </button>
            </div>
            
            {signalsLoading ? (
              <div className="rounded-xl border border-border bg-card p-8 text-center">
                <div className="mx-auto h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
              </div>
            ) : activeSignals.length > 0 ? (
              <div className="space-y-3">
                {activeSignals.map((signal) => (
                  <SignalCard 
                    key={signal.id} 
                    signal={signal} 
                    onRead={() => markAsRead(signal.id)}
                  />
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-border bg-card p-6 text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                  <Eye className="h-7 w-7 text-muted-foreground" />
                </div>
                <h4 className="font-semibold text-foreground">No Active Setups</h4>
                <p className="mt-2 text-xs text-muted-foreground max-w-xs mx-auto">
                  Conditions currently do not support the {strategyInfo?.name || "selected strategy"}. 
                  No valid setup is active at this time.
                </p>
              </div>
            )}
          </div>

          {/* How SightLine Fires Signals */}
          {activeSignals.length === 0 && (
            <div className="rounded-xl border border-border bg-card/50 p-4">
              <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-2">
                How SightLine Fires Signals
              </h4>
              <p className="text-xs text-muted-foreground leading-relaxed">
                SightLine does not attempt to alert on every market move. Our decision engine filters 
                aggressively and only surfaces setups that meet strict structure, confirmation, and 
                reward-to-risk criteria.
              </p>
              <p className="mt-2 text-xs text-muted-foreground leading-relaxed">
                Because of this, some trading sessions may produce <span className="text-foreground font-medium">no signals at all</span>. 
                This is intentional. No signal is often better than a low-quality trade.
              </p>
              <p className="mt-2 text-xs text-primary font-medium">
                SightLine prioritizes quality over quantity.
              </p>
            </div>
          )}

          {/* Recent Signal History */}
          {recentSignals.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-semibold text-foreground">Recent History</h3>
                <Link 
                  href="/signals"
                  className="flex items-center gap-1 text-xs text-primary hover:underline"
                >
                  View all
                  <ChevronRight className="h-3 w-3" />
                </Link>
              </div>
              
              <div className="rounded-xl border border-border bg-card divide-y divide-border">
                {recentSignals.map((signal) => (
                  <div key={signal.id} className="flex items-center justify-between p-3">
                    <div className="flex items-center gap-3">
                      <div className={`rounded-lg p-1.5 ${
                        signal.direction === "BUY" ? "bg-primary/10" : "bg-destructive/10"
                      }`}>
                        {signal.direction === "BUY" ? (
                          <TrendingUp className="h-4 w-4 text-primary" />
                        ) : (
                          <TrendingDown className="h-4 w-4 text-destructive" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {signal.symbol} {signal.direction}
                        </p>
                        <p className="text-[10px] text-muted-foreground">
                          {signal.setup_type?.replace(/_/g, " ")} · {signal.timeframe}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                        signal.status === "won" ? "bg-primary/10 text-primary" :
                        signal.status === "lost" ? "bg-destructive/10 text-destructive" :
                        "bg-muted text-muted-foreground"
                      }`}>
                        {signal.status === "won" ? "Win" : 
                         signal.status === "lost" ? "Loss" : 
                         signal.status === "active" ? "Active" : "Pending"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* My Strategy Library Section */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-foreground">My Strategy Library</h3>
              <Link
                href="/strategy-wizard"
                className="flex items-center gap-1.5 rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/20"
              >
                <Plus className="h-3 w-3" />
                Build New Strategy
              </Link>
            </div>
            
            {strategies.length > 0 ? (
              <div className="space-y-3">
                {strategies.map((s) => (
                  <StrategyLibraryCard
                    key={s.id}
                    strategy={s}
                    isActive={s.id === activeStrategy?.id}
                    displayName={getStrategyDisplayName(s)}
                    onSelect={() => setActiveStrategy(s)}
                  />
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-border bg-card/50 p-8 text-center">
                <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                  <Target className="h-7 w-7 text-muted-foreground" />
                </div>
                <h4 className="font-semibold text-foreground">No Strategies Yet</h4>
                <p className="mt-2 text-xs text-muted-foreground max-w-xs mx-auto mb-4">
                  Create your first trading strategy using the SightLine Strategy Wizard.
                </p>
                <Link
                  href="/strategy-wizard"
                  className="inline-flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
                >
                  <Plus className="h-4 w-4" />
                  Create New Strategy
                </Link>
              </div>
            )}
          </div>

          {/* Disclaimer */}
          <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-xs font-semibold text-amber-500 mb-1">Not Financial Advice</p>
                <p className="text-[10px] text-muted-foreground leading-relaxed">
                  SightLine provides trade setup ideas based on technical patterns. 
                  No trading strategy wins every trade, and no platform can guarantee results.
                  Past performance does not guarantee future results. Always manage your risk.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

// Signal Card Component
function SignalCard({ signal, onRead }: { signal: Signal; onRead: () => void }) {
  const isUnread = !signal.read_at
  const setupQuality = signal.setup_quality || (signal.grade === "A" ? "Elite" : signal.grade === "B" ? "Strong" : "Developing")
  const conditions = signal.reasons || []

  // V1 Setup Quality colors
  const qualityColors = {
    Elite: "bg-primary/20 text-primary border-primary/30",
    Strong: "bg-amber-500/20 text-amber-500 border-amber-500/30",
    Developing: "bg-muted text-muted-foreground border-border",
  }

  return (
    <div
      onClick={onRead}
      className={`rounded-xl border bg-card p-4 cursor-pointer transition-all hover:border-primary/30 ${
        isUnread ? "border-primary/30 bg-primary/5" : "border-border"
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-foreground">{signal.symbol}</span>
          <span className="text-xs text-muted-foreground">/ {signal.timeframe}</span>
          <span
            className={`flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase ${
              signal.direction === "BUY" ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
            }`}
          >
            {signal.direction === "BUY" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {signal.direction}
          </span>
          {isUnread && <span className="h-2 w-2 rounded-full bg-primary animate-pulse" />}
        </div>
        <span className={`text-xs font-bold px-2.5 py-1 rounded-lg border ${qualityColors[setupQuality as keyof typeof qualityColors]}`}>
          {setupQuality} Setup
        </span>
      </div>

      {/* Setup Type */}
      {signal.setup_type && (
        <p className="text-xs text-primary font-medium mb-3">{signal.setup_type.replace(/_/g, " ")}</p>
      )}

      {/* Watch Level */}
      {signal.watch_level && (
        <div className="mb-3 rounded-lg bg-muted/50 px-3 py-2">
          <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Watch Level</p>
          <p className="text-sm font-bold text-foreground">${signal.watch_level.toLocaleString(undefined, { minimumFractionDigits: 2 })}</p>
        </div>
      )}

      {/* Trade Plan Box Visualization */}
      <TradeBox
        entry={signal.entry_price}
        stopLoss={signal.stop_loss}
        target1={signal.target_1}
        target2={signal.target_2 || undefined}
        direction={signal.direction}
      />

      {/* Setup Conditions Met */}
      {conditions.length > 0 && (
        <div className="mt-3 space-y-1.5">
          <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">Setup Conditions Met</p>
          <ul className="text-xs text-muted-foreground space-y-1">
            {conditions.slice(0, 5).map((condition, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-primary mt-0.5 shrink-0">
                  <Check className="h-3 w-3" />
                </span>
                <span>{condition}</span>
              </li>
            ))}
          </ul>
          {conditions.length > 5 && (
            <p className="text-[10px] text-muted-foreground/70">+{conditions.length - 5} more conditions</p>
          )}
        </div>
      )}

      {/* R:R Display */}
      {signal.risk_reward && (
        <div className="mt-3 flex items-center gap-2 text-xs">
          <span className="text-muted-foreground">Risk/Reward:</span>
          <span className="font-semibold text-foreground">{signal.risk_reward}:1</span>
        </div>
      )}
    </div>
  )
}

// Strategy Library Card Component
function StrategyLibraryCard({
  strategy,
  isActive,
  displayName,
  onSelect,
}: {
  strategy: UserStrategy
  isActive: boolean
  displayName: string
  onSelect: () => void
}) {
  const createdDate = new Date(strategy.created_at).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })

  return (
    <button
      onClick={onSelect}
      className={`w-full text-left rounded-xl border p-4 transition-all ${
        isActive
          ? "border-primary bg-primary/5"
          : "border-border bg-card hover:border-primary/30"
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h4 className="text-sm font-semibold text-foreground">{displayName}</h4>
            {isActive && (
              <span className="rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-medium text-primary">
                Active
              </span>
            )}
          </div>
          <div className="flex items-center gap-1 mt-1 text-[10px] text-muted-foreground">
            <Calendar className="h-3 w-3" />
            Created {createdDate}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-[10px]">
        <div>
          <p className="text-muted-foreground">Asset</p>
          <p className="font-medium text-foreground">{strategy.asset}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Timeframe</p>
          <p className="font-medium text-foreground">{strategy.timeframe}</p>
        </div>
        <div>
          <p className="text-muted-foreground">Style</p>
          <p className="font-medium text-foreground">{strategy.trading_style || "Balanced"}</p>
        </div>
      </div>

      {strategy.setup_preference && (
        <div className="mt-2 pt-2 border-t border-border">
          <p className="text-[10px] text-muted-foreground">Setup: <span className="text-foreground">{strategy.setup_preference}</span></p>
        </div>
      )}
    </button>
  )
}

// Generate Demo Signal Button
function GenerateDemoButton({ 
  asset, 
  framework, 
  onGenerated 
}: { 
  asset: string
  framework: StrategyKey
  onGenerated: () => void 
}) {
  const [isGenerating, setIsGenerating] = useState(false)

  const handleGenerate = async () => {
    setIsGenerating(true)
    try {
      const response = await fetch('/api/signals/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          asset, 
          framework,
          mode: 'single'
        })
      })
      
      if (response.ok) {
        onGenerated()
      }
    } catch (error) {
      console.error('Failed to generate signal:', error)
    }
    setIsGenerating(false)
  }

  return (
    <button
      onClick={handleGenerate}
      disabled={isGenerating}
      className="flex items-center gap-1.5 rounded-lg bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary transition-colors hover:bg-primary/20 disabled:opacity-50"
    >
      {isGenerating ? (
        <>
          <div className="h-3 w-3 animate-spin rounded-full border border-primary border-t-transparent" />
          Generating...
        </>
      ) : (
        <>
          <Zap className="h-3 w-3" />
          Demo Signal
        </>
      )}
    </button>
  )
}
