"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Zap, TrendingUp, TrendingDown, Check, X } from "lucide-react"
import { processIncomingSignal } from "@/lib/signal-engine"
import { IncomingSignal } from "@/lib/storage"
import { SignalType } from "@/lib/signal-scoring"
import { MarketCondition } from "@/lib/market-condition"

interface DemoSignalConfig {
  label: string
  signal: IncomingSignal & {
    signalType: SignalType
    marketCondition: MarketCondition
    trendAligned?: boolean
    htfAligned?: boolean
    volumeExpansion?: boolean
    cleanBreak?: boolean
    retestHeld?: boolean
    rejectionCandle?: boolean
    momentumStrong?: boolean
  }
}

const DEMO_SIGNALS: DemoSignalConfig[] = [
  {
    label: "BTC Break + Retest (Grade A)",
    signal: {
      symbol: "BTCUSD",
      timeframe: "15",
      direction: "BUY",
      entry: 64200,
      stopLoss: 63700,
      target1: 65300,
      target2: 66000,
      setupType: "break_retest",
      signalType: "break_retest",
      marketCondition: "trending_up",
      trendAligned: true,
      htfAligned: true,
      volumeExpansion: true,
      cleanBreak: true,
      retestHeld: true,
      timestamp: new Date().toISOString(),
    },
  },
  {
    label: "ETH Trend Continuation (Grade B)",
    signal: {
      symbol: "ETHUSD",
      timeframe: "15",
      direction: "BUY",
      entry: 3485,
      stopLoss: 3420,
      target1: 3580,
      target2: 3650,
      setupType: "trend_continuation",
      signalType: "trend_continuation",
      marketCondition: "trending_up",
      trendAligned: true,
      htfAligned: true,
      retestHeld: true,
      momentumStrong: false,
      timestamp: new Date().toISOString(),
    },
  },
  {
    label: "SPY Breakout (Grade A)",
    signal: {
      symbol: "SPY",
      timeframe: "15",
      direction: "BUY",
      entry: 582.50,
      stopLoss: 580.25,
      target1: 586.00,
      target2: 589.00,
      setupType: "breakout",
      signalType: "breakout",
      marketCondition: "compression",
      trendAligned: true,
      htfAligned: true,
      volumeExpansion: true,
      cleanBreak: true,
      timestamp: new Date().toISOString(),
    },
  },
  {
    label: "SOL Liquidity Sweep (Grade A)",
    signal: {
      symbol: "SOLUSD",
      timeframe: "60",
      direction: "SELL",
      entry: 142.50,
      stopLoss: 146.00,
      target1: 137.00,
      target2: 132.00,
      setupType: "liquidity_sweep",
      signalType: "liquidity_sweep",
      marketCondition: "volatile",
      htfAligned: true,
      volumeExpansion: true,
      rejectionCandle: true,
      timestamp: new Date().toISOString(),
    },
  },
  {
    label: "NVDA Range Bounce (Grade C)",
    signal: {
      symbol: "NVDA",
      timeframe: "15",
      direction: "BUY",
      entry: 875.00,
      stopLoss: 865.00,
      target1: 895.00,
      target2: 910.00,
      setupType: "range_bounce",
      signalType: "range_bounce",
      marketCondition: "ranging",
      rejectionCandle: true,
      htfAligned: false,
      trendAligned: false,
      timestamp: new Date().toISOString(),
    },
  },
  {
    label: "QQQ Failed Breakout (Filtered)",
    signal: {
      symbol: "QQQ",
      timeframe: "15",
      direction: "SELL",
      entry: 495.00,
      stopLoss: 498.00,
      target1: 490.00,
      setupType: "failed_breakout",
      signalType: "failed_breakout",
      marketCondition: "trending_up", // Wrong condition - will be filtered
      timestamp: new Date().toISOString(),
    },
  },
]

interface SignalResult {
  label: string
  alertsCreated: number
  success: boolean
  grade?: string
  score?: number
  reasons?: string[]
  filtered?: boolean
  filterReason?: string
}

export default function DemoSignalPage() {
  const [results, setResults] = useState<SignalResult[]>([])
  const [isProcessing, setIsProcessing] = useState(false)

  const handleGenerateSignal = async (config: DemoSignalConfig) => {
    setIsProcessing(true)
    
    await new Promise(resolve => setTimeout(resolve, 500))
    
    const result = processIncomingSignal(config.signal)
    
    setResults(prev => [
      {
        label: config.label,
        alertsCreated: result.alertsCreated,
        success: result.alertsCreated > 0,
        grade: result.grade,
        score: result.score,
        reasons: result.reasons,
        filtered: result.filtered,
        filterReason: result.filterReason,
      },
      ...prev,
    ])
    
    setIsProcessing(false)
  }

  const handleGenerateAll = async () => {
    setIsProcessing(true)
    setResults([])
    
    for (const config of DEMO_SIGNALS) {
      await new Promise(resolve => setTimeout(resolve, 400))
      const result = processIncomingSignal(config.signal)
      setResults(prev => [
        ...prev,
        {
          label: config.label,
          alertsCreated: result.alertsCreated,
          success: result.alertsCreated > 0,
          grade: result.grade,
          score: result.score,
          reasons: result.reasons,
          filtered: result.filtered,
          filterReason: result.filterReason,
        },
      ])
    }
    
    setIsProcessing(false)
  }

  const gradeColors: Record<string, string> = {
    A: "bg-primary/20 text-primary",
    B: "bg-amber-500/20 text-amber-500",
    C: "bg-muted text-muted-foreground",
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur-lg">
        <div className="flex items-center gap-4 px-5 py-4">
          <Link
            href="/dashboard"
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-border text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" />
          </Link>
          <div>
            <h1 className="text-lg font-bold text-foreground">Signal Engine Demo</h1>
            <p className="text-xs text-muted-foreground">Test the 4-layer signal scoring system</p>
          </div>
        </div>
      </header>

      <main className="px-5 py-6">
        {/* Info */}
        <div className="mb-6 rounded-xl border border-primary/20 bg-primary/5 p-4">
          <p className="text-sm font-medium text-foreground mb-2">How it works:</p>
          <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside">
            <li>Market condition is detected (trending, ranging, compression, volatile)</li>
            <li>Signal type is checked against allowed types for that condition</li>
            <li>Signal is scored using the confirmation matrix (10+ factors)</li>
            <li>Grade A/B/C is assigned based on score (A: 8+, B: 6-7, C: 4-5)</li>
          </ol>
        </div>

        {/* Generate All Button */}
        <button
          onClick={handleGenerateAll}
          disabled={isProcessing}
          className="w-full mb-6 flex items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isProcessing ? (
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />
          ) : (
            <Zap className="h-4 w-4" />
          )}
          Run All Demo Signals
        </button>

        {/* Individual Signals */}
        <div className="space-y-3 mb-8">
          <h2 className="text-sm font-semibold text-foreground mb-3">Demo Signals:</h2>
          {DEMO_SIGNALS.map((config) => (
            <div
              key={config.label}
              className="flex items-center justify-between rounded-xl border border-border bg-card p-4"
            >
              <div className="flex items-center gap-3">
                <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                  config.signal.direction === "BUY" 
                    ? "bg-primary/10 text-primary" 
                    : "bg-destructive/10 text-destructive"
                }`}>
                  {config.signal.direction === "BUY" ? (
                    <TrendingUp className="h-5 w-5" />
                  ) : (
                    <TrendingDown className="h-5 w-5" />
                  )}
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground">{config.label}</p>
                  <p className="text-xs text-muted-foreground">
                    {config.signal.symbol} | {config.signal.signalType.replace(/_/g, " ")} | {config.signal.marketCondition.replace(/_/g, " ")}
                  </p>
                </div>
              </div>
              <button
                onClick={() => handleGenerateSignal(config)}
                disabled={isProcessing}
                className="rounded-lg border border-border px-3 py-1.5 text-xs font-medium text-foreground transition-colors hover:border-primary/30 hover:text-primary disabled:opacity-50"
              >
                Test
              </button>
            </div>
          ))}
        </div>

        {/* Results */}
        {results.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-foreground mb-3">Results</h2>
            <div className="space-y-3">
              {results.map((result, i) => (
                <div
                  key={i}
                  className={`rounded-xl border bg-card p-4 ${
                    result.filtered ? "border-destructive/30 bg-destructive/5" : 
                    result.success ? "border-primary/30" : "border-border"
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className={`flex h-6 w-6 items-center justify-center rounded-full ${
                        result.filtered ? "bg-destructive/10 text-destructive" :
                        result.success ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"
                      }`}>
                        {result.filtered ? <X className="h-3 w-3" /> : 
                         result.success ? <Check className="h-3 w-3" /> : <span className="text-xs">—</span>}
                      </div>
                      <span className="text-sm font-medium text-foreground">{result.label}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {result.grade && !result.filtered && (
                        <span className={`text-xs font-bold px-2 py-0.5 rounded ${gradeColors[result.grade] || ""}`}>
                          Grade {result.grade} ({result.score}/10)
                        </span>
                      )}
                      <span className={`text-xs font-medium ${
                        result.filtered ? "text-destructive" :
                        result.success ? "text-primary" : "text-muted-foreground"
                      }`}>
                        {result.filtered ? "Filtered" : `${result.alertsCreated} alert${result.alertsCreated !== 1 ? "s" : ""}`}
                      </span>
                    </div>
                  </div>
                  
                  {result.filtered && result.filterReason && (
                    <p className="text-xs text-destructive/80 mt-2">{result.filterReason}</p>
                  )}
                  
                  {result.reasons && result.reasons.length > 0 && !result.filtered && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {result.reasons.map((reason, j) => (
                        <span key={j} className="flex items-center gap-1 text-[10px] text-muted-foreground bg-muted/50 px-2 py-0.5 rounded">
                          <Check className="h-2.5 w-2.5 text-primary" />
                          {reason}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <div className="mt-4 text-center">
              <Link
                href="/dashboard"
                className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
              >
                View alerts in dashboard
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
