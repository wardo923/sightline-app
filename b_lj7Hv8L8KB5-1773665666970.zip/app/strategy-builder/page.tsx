import { redirect } from "next/navigation"

export const metadata = {
  title: "Strategy Builder - SightLine Advanced Trading Analytics",
  description: "Build your custom trading strategy engine in 12 simple questions.",
}

// Redirect to master wizard route
export default function StrategyBuilderPage() {
  redirect("/strategy-wizard")
}
