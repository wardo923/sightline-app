import { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"

export const metadata: Metadata = {
  title: "FAQ - SightLine",
  description: "Frequently asked questions about SightLine trading analytics platform.",
}

const faqs = [
  {
    question: "What is SightLine?",
    answer: "SightLine is a market analysis platform designed to help traders evaluate market structure and highlight market conditions based on a structured framework.",
  },
  {
    question: "Does SightLine execute trades?",
    answer: "No. SightLine does not execute trades or connect to brokerage accounts. The platform provides market analysis tools only - you maintain full control of your trading account.",
  },
  {
    question: "Is this financial advice?",
    answer: "No. SightLine provides analytical insights and does not provide financial or investment advice. All trading decisions are your responsibility.",
  },
  {
    question: "What markets does SightLine support?",
    answer: "SightLine supports market structure analysis across crypto, stocks, indices, and futures.",
  },
  {
    question: "How does the Strategy Wizard work?",
    answer: "The Strategy Wizard asks guided questions about preferred markets, timeframe, risk tolerance, and monitoring preferences. These responses are used to create a personalized trading framework.",
  },
  {
    question: "Can I have multiple strategy profiles?",
    answer: "Yes, depending on your plan. Starter allows 1 strategy profile, Pro allows up to 3, and Elite offers unlimited strategy profiles.",
  },
  {
    question: "What alert channels are available?",
    answer: "SightLine offers dashboard alerts, email alerts, and mobile notifications depending on your subscription plan.",
  },
  {
    question: "Is there a free trial?",
    answer: "Yes. The Starter plan includes a 3-day free trial with no credit card required.",
  },
  {
    question: "Can I cancel my subscription?",
    answer: "Yes. All plans are month-to-month with no long-term commitment. You can cancel anytime from your account settings.",
  },
  {
    question: "How do I contact support?",
    answer: "You can reach our support team through the Help Center or by emailing support@sightline.app.",
  },
]

export default function FAQPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <p className="mb-4 text-xs font-semibold tracking-widest text-primary uppercase">
            Support
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            Frequently Asked Questions
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground text-pretty">
            Find answers to common questions about SightLine.
          </p>
        </div>
      </section>

      {/* FAQ List */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-4 md:px-6">
          <div className="space-y-4">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-xl border border-border bg-card p-6 transition-all hover:border-primary/20"
              >
                <h2 className="text-base font-semibold text-foreground mb-3">
                  {faq.question}
                </h2>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
