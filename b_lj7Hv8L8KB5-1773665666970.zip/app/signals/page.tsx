"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { 
  Crosshair, 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown,
  Filter,
  ChevronRight,
} from "lucide-react"
import { useSignals, Signal } from "@/hooks/use-signals"
import { createClient } from "@/lib/supabase/client"

type FilterStatus = "all" | "active" | "completed"

export default function SignalsPage() {
  const router = useRouter()
  const { signals, isLoading: signalsLoading } = useSignals()
  const [isLoading, setIsLoading] = useState(true)
  const [filter, setFilter] = useState<FilterStatus>("all")

  useEffect(() => {
    async function checkAuth() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        router.push("/auth/login")
        return
      }
      setIsLoading(false)
    }
    checkAuth()
  }, [router])

  if (isLoading || signalsLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  const filteredSignals = signals.filter(s => {
    if (filter === "active") return s.status === "pending" || s.status === "active"
    if (filter === "completed") return s.status === "target_hit" || s.status === "stopped_out" || s.status === "invalidated"
    return true
  })

  const getStatusBadge = (status: Signal["status"]) => {
    const styles = {
      pending: "bg-amber-500/10 text-amber-500 border-amber-500/30",
      active: "bg-primary/10 text-primary border-primary/30",
      invalidated: "bg-muted text-muted-foreground border-border",
      target_hit: "bg-primary/10 text-primary border-primary/30",
      stopped_out: "bg-destructive/10 text-destructive border-destructive/30",
    }
    const labels = {
      pending: "Pending",
      active: "Active",
      invalidated: "Invalidated",
      target_hit: "Target Hit",
      stopped_out: "Stopped Out",
    }
    return (
      <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md border ${styles[status]}`}>
        {labels[status]}
      </span>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur-lg">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <button onClick={() => router.back()} className="flex h-10 w-10 items-center justify-center rounded-xl border border-border text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
              <h1 className="text-lg font-bold text-foreground">Signal History</h1>
              <p className="text-xs text-muted-foreground">{signals.length} total signals</p>
            </div>
          </div>
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
              <Crosshair className="h-5 w-5 text-primary-foreground" />
            </div>
          </Link>
        </div>
      </header>

      {/* Filters */}
      <div className="border-b border-border bg-card/50">
        <div className="flex items-center gap-2 px-4 py-3 overflow-x-auto">
          <Filter className="h-4 w-4 text-muted-foreground shrink-0" />
          {(["all", "active", "completed"] as FilterStatus[]).map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                filter === f 
                  ? "bg-primary text-primary-foreground" 
                  : "bg-muted text-muted-foreground hover:text-foreground"
              }`}
            >
              {f === "all" ? "All Signals" : f === "active" ? "Active" : "Completed"}
            </button>
          ))}
        </div>
      </div>

      {/* Signals List */}
      <main className="px-4 py-4">
        {filteredSignals.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-muted mb-4">
              <TrendingUp className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold text-foreground mb-1">No signals yet</h3>
            <p className="text-sm text-muted-foreground max-w-xs">
              SightLine is monitoring your markets. Signals will appear here when they match your strategy.
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredSignals.map(signal => (
              <Link
                key={signal.id}
                href={`/signals/${signal.id}`}
                className="flex items-center justify-between p-4 rounded-xl border border-border bg-card hover:border-primary/30 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-xl ${
                    signal.direction === "BUY" ? "bg-primary/10" : "bg-destructive/10"
                  }`}>
                    {signal.direction === "BUY" ? (
                      <TrendingUp className="h-5 w-5 text-primary" />
                    ) : (
                      <TrendingDown className="h-5 w-5 text-destructive" />
                    )}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-foreground">{signal.symbol}</span>
                      <span className="text-xs text-muted-foreground">/ {signal.timeframe}</span>
                      {getStatusBadge(signal.status)}
                    </div>
                    <div className="flex items-center gap-3 mt-0.5">
                      <span className="text-xs text-muted-foreground">{signal.setup_type}</span>
                      <span className="text-xs text-muted-foreground">Grade {signal.grade}</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(signal.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </Link>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
