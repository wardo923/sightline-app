"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { 
  Crosshair, 
  RefreshCw, 
  TrendingUp, 
  TrendingDown, 
  Check,
  ArrowLeft,
  Zap,
  Target,
  Shield
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface PreviewSignal {
  symbol: string
  timeframe: string
  direction: 'BUY' | 'SELL'
  setup_type: string
  setup_quality: 'Elite' | 'Strong' | 'Developing' | 'NoAlert'
  entry_price: number
  stop_loss: number
  target_1: number
  target_2: number
  risk_reward: string
  watch_level: number
  v1_score: number
  reasons: string[]
  market_condition: string
  suppressed?: boolean
  suppressReason?: string
}

const QUALITY_STYLES = {
  Elite: {
    badge: "bg-primary/20 text-primary border-primary/30",
    icon: Zap,
    label: "Elite Setup",
  },
  Strong: {
    badge: "bg-amber-500/20 text-amber-500 border-amber-500/30",
    icon: Target,
    label: "Strong Setup",
  },
  Developing: {
    badge: "bg-muted text-muted-foreground border-border",
    icon: Shield,
    label: "Developing Setup",
  },
}

function SignalPreviewCard({ signal }: { signal: PreviewSignal }) {
  const qualityStyle = QUALITY_STYLES[signal.setup_quality]
  const QualityIcon = qualityStyle.icon

  return (
    <div className="rounded-xl border border-border bg-card p-4">
      {/* Header */}
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-lg font-bold text-foreground">{signal.symbol}</span>
          <span className="text-xs text-muted-foreground">/ {signal.timeframe}</span>
          <span
            className={cn(
              "flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase",
              signal.direction === "BUY" ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
            )}
          >
            {signal.direction === "BUY" ? <TrendingUp className="h-3 w-3" /> : <TrendingDown className="h-3 w-3" />}
            {signal.direction}
          </span>
        </div>
        <span className={cn("flex items-center gap-1 text-xs font-bold px-2.5 py-1 rounded-lg border", qualityStyle.badge)}>
          <QualityIcon className="h-3 w-3" />
          {qualityStyle.label}
        </span>
      </div>

      {/* Setup Type */}
      <p className="text-xs text-primary font-medium mb-3">
        {signal.setup_type.replace(/_/g, " ")}
      </p>

      {/* Watch Level */}
      <div className="mb-3 rounded-lg bg-muted/50 px-3 py-2">
        <p className="text-[10px] text-muted-foreground uppercase tracking-wide">Watch Level</p>
        <p className="text-sm font-bold text-foreground">
          ${signal.watch_level.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </p>
      </div>

      {/* Trade Plan */}
      <div className="grid grid-cols-4 gap-2 mb-3 text-center">
        <div className="rounded-lg bg-muted/30 p-2">
          <p className="text-[9px] text-muted-foreground uppercase">Entry</p>
          <p className="text-xs font-semibold text-foreground">
            ${signal.entry_price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
        <div className="rounded-lg bg-destructive/10 p-2">
          <p className="text-[9px] text-destructive uppercase">Stop</p>
          <p className="text-xs font-semibold text-destructive">
            ${signal.stop_loss.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
        <div className="rounded-lg bg-primary/10 p-2">
          <p className="text-[9px] text-primary uppercase">Target 1</p>
          <p className="text-xs font-semibold text-primary">
            ${signal.target_1.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
        <div className="rounded-lg bg-primary/10 p-2">
          <p className="text-[9px] text-primary uppercase">Target 2</p>
          <p className="text-xs font-semibold text-primary">
            ${signal.target_2.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </p>
        </div>
      </div>

      {/* Risk/Reward */}
      <div className="flex items-center justify-between mb-3 text-xs">
        <span className="text-muted-foreground">Risk/Reward</span>
        <span className="font-semibold text-foreground">{signal.risk_reward}</span>
      </div>

      {/* Setup Conditions Met */}
      <div className="space-y-1.5">
        <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide">
          Setup Conditions Met
        </p>
        <ul className="text-xs text-muted-foreground space-y-1">
          {signal.reasons.map((condition, i) => (
            <li key={i} className="flex items-start gap-2">
              <span className="text-primary mt-0.5 shrink-0">
                <Check className="h-3 w-3" />
              </span>
              <span>{condition}</span>
            </li>
          ))}
        </ul>
      </div>

      {/* V1 Score */}
      <div className="mt-3 pt-3 border-t border-border flex items-center justify-between">
        <span className="text-[10px] text-muted-foreground">V1 Engine Score</span>
        <span className="text-xs font-semibold text-foreground">{signal.v1_score}/9</span>
      </div>
    </div>
  )
}

export default function SignalPreviewPage() {
  const [signals, setSignals] = useState<PreviewSignal[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedAsset, setSelectedAsset] = useState<string | null>(null)

  const assets = ['SPY', 'QQQ', 'BTC', 'ETH']

  const fetchSignals = async () => {
    setLoading(true)
    try {
      const response = await fetch('/api/signals/generate')
      const data = await response.json()
      setSignals(data.signals || [])
    } catch (error) {
      console.error('Failed to fetch signals:', error)
    }
    setLoading(false)
  }

  useEffect(() => {
    fetchSignals()
  }, [])

  const filteredSignals = selectedAsset 
    ? signals.filter(s => s.symbol === selectedAsset)
    : signals

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur-sm">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <Link href="/" className="flex items-center gap-2">
              <Crosshair className="h-5 w-5 text-primary" />
              <span className="text-base font-bold text-foreground">SightLine</span>
            </Link>
            <span className="text-xs text-muted-foreground">/ Signal Preview</span>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={fetchSignals}
            disabled={loading}
            className="gap-2"
          >
            <RefreshCw className={cn("h-4 w-4", loading && "animate-spin")} />
            Refresh
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-4 py-6 pb-safe">
        <div className="max-w-2xl mx-auto">
          {/* Title */}
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-foreground">Signal Preview</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Preview how the V1 engine generates alerts for different assets. These are example signals showing the alert format and quality levels.
            </p>
          </div>

          {/* Asset Filter */}
          <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
            <button
              onClick={() => setSelectedAsset(null)}
              className={cn(
                "shrink-0 rounded-lg px-4 py-2 text-sm font-medium transition-colors",
                selectedAsset === null
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              )}
            >
              All Assets
            </button>
            {assets.map(asset => (
              <button
                key={asset}
                onClick={() => setSelectedAsset(asset)}
                className={cn(
                  "shrink-0 rounded-lg px-4 py-2 text-sm font-medium transition-colors",
                  selectedAsset === asset
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground hover:bg-muted/80"
                )}
              >
                {asset}
              </button>
            ))}
          </div>

          {/* V1 Engine Stats */}
          <div className="rounded-xl border border-border bg-card/50 p-4 mb-6">
            <p className="text-xs font-semibold text-foreground mb-3">V1 Engine Quality Distribution</p>
            <div className="grid grid-cols-4 gap-3 text-center">
              <div>
                <span className={cn("inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-lg border", QUALITY_STYLES.Elite.badge)}>
                  <Zap className="h-3 w-3" />
                  Elite
                </span>
                <p className="text-lg font-bold text-foreground mt-1">
                  {filteredSignals.filter(s => s.setup_quality === 'Elite').length}
                </p>
                <p className="text-[10px] text-muted-foreground">Score 7-9</p>
              </div>
              <div>
                <span className={cn("inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-lg border", QUALITY_STYLES.Strong.badge)}>
                  <Target className="h-3 w-3" />
                  Strong
                </span>
                <p className="text-lg font-bold text-foreground mt-1">
                  {filteredSignals.filter(s => s.setup_quality === 'Strong').length}
                </p>
                <p className="text-[10px] text-muted-foreground">Score 5-6</p>
              </div>
              <div>
                <span className={cn("inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-lg border", QUALITY_STYLES.Developing.badge)}>
                  <Shield className="h-3 w-3" />
                  Develop
                </span>
                <p className="text-lg font-bold text-foreground mt-1">
                  {filteredSignals.filter(s => s.setup_quality === 'Developing').length}
                </p>
                <p className="text-[10px] text-muted-foreground">Score 4</p>
              </div>
              <div>
                <span className="inline-flex items-center gap-1 text-xs font-bold px-2 py-1 rounded-lg border bg-destructive/10 text-destructive border-destructive/30">
                  Filtered
                </span>
                <p className="text-lg font-bold text-foreground mt-1">
                  {signals.filter(s => s.suppressed).length}
                </p>
                <p className="text-[10px] text-muted-foreground">Suppressed</p>
              </div>
            </div>
            <p className="mt-3 text-[10px] text-muted-foreground">
              Conservative V1 filters out weak setups, midday stock signals, and exhausted breakouts to prioritize quality over quantity.
            </p>
          </div>

          {/* Active Signals */}
          <h3 className="text-sm font-semibold text-foreground mb-3">Qualifying Setups</h3>
          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3, 4].map(i => (
                <div key={i} className="rounded-xl border border-border bg-card p-4 animate-pulse">
                  <div className="h-6 bg-muted rounded w-1/3 mb-3" />
                  <div className="h-4 bg-muted rounded w-1/4 mb-3" />
                  <div className="h-20 bg-muted rounded mb-3" />
                  <div className="space-y-2">
                    <div className="h-3 bg-muted rounded w-full" />
                    <div className="h-3 bg-muted rounded w-5/6" />
                    <div className="h-3 bg-muted rounded w-4/6" />
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredSignals.filter(s => !s.suppressed && s.setup_quality !== 'NoAlert').map((signal, index) => (
                <SignalPreviewCard key={index} signal={signal} />
              ))}
            </div>
          )}

          {/* Suppressed Signals Section */}
          {!loading && filteredSignals.some(s => s.suppressed || s.setup_quality === 'NoAlert') && (
            <div className="mt-8">
              <h3 className="text-sm font-semibold text-foreground mb-2">Filtered by V1 Engine</h3>
              <p className="text-xs text-muted-foreground mb-4">
                These setups were detected but suppressed by conservative V1 filters to maintain signal quality.
              </p>
              <div className="space-y-3">
                {filteredSignals.filter(s => s.suppressed || s.setup_quality === 'NoAlert').map((signal, index) => (
                  <div 
                    key={`suppressed-${index}`} 
                    className="rounded-xl border border-destructive/20 bg-destructive/5 p-4 opacity-70"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-foreground">{signal.symbol}</span>
                        <span className="text-xs text-muted-foreground">/ {signal.timeframe}</span>
                        <span className={cn(
                          "flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold uppercase",
                          signal.direction === 'BUY' ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
                        )}>
                          {signal.direction}
                        </span>
                      </div>
                      <span className="text-xs font-medium px-2 py-1 rounded-lg bg-destructive/10 text-destructive border border-destructive/20">
                        Filtered
                      </span>
                    </div>
                    <p className="text-xs text-muted-foreground mb-2">
                      {signal.setup_type?.replace(/_/g, ' ')}
                    </p>
                    <div className="rounded-lg bg-background/50 p-3 mb-3">
                      <p className="text-xs font-medium text-destructive mb-1">Reason Suppressed:</p>
                      <p className="text-xs text-muted-foreground">{signal.suppressReason || 'Score below minimum threshold'}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-[10px] font-semibold text-muted-foreground uppercase">Conditions Evaluated</p>
                      <ul className="text-xs text-muted-foreground space-y-0.5">
                        {signal.reasons?.slice(0, 4).map((reason, i) => (
                          <li key={i} className="flex items-start gap-1.5">
                            <span className="text-destructive/60 mt-0.5">-</span>
                            {reason}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Disclaimer */}
          <div className="mt-6 rounded-xl border border-border bg-card/30 p-4">
            <p className="text-xs text-muted-foreground">
              <span className="font-semibold text-foreground">Note:</span> These are example signals generated by the V1 engine for preview purposes. Actual signals will be generated when the engine detects qualifying setups based on your strategy configuration. No signal is guaranteed to result in a profitable trade.
            </p>
          </div>

          {/* Back Link */}
          <div className="mt-6">
            <Link 
              href="/dashboard"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" />
              Back to Dashboard
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
