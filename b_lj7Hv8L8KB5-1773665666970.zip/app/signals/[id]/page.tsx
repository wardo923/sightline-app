"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { 
  Crosshair, 
  ArrowLeft, 
  TrendingUp, 
  TrendingDown,
  Check,
  Clock,
  Target,
  AlertTriangle,
  XCircle,
} from "lucide-react"
import { Signal } from "@/hooks/use-signals"
import { createClient } from "@/lib/supabase/client"
import { TradeBox } from "@/components/trade-box"

interface SignalEvent {
  id: string
  event_type: string
  notes: string | null
  price_at_event: number | null
  created_at: string
}

export default function SignalDetailPage() {
  const router = useRouter()
  const params = useParams()
  const [signal, setSignal] = useState<Signal | null>(null)
  const [events, setEvents] = useState<SignalEvent[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadSignal() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        router.push("/auth/login")
        return
      }

      // Fetch signal
      const { data: signalData, error } = await supabase
        .from("signals")
        .select("*")
        .eq("id", params.id)
        .eq("user_id", user.id)
        .single()

      if (error || !signalData) {
        router.push("/signals")
        return
      }

      setSignal(signalData)

      // Fetch events
      const { data: eventsData } = await supabase
        .from("signal_events")
        .select("*")
        .eq("signal_id", params.id)
        .order("created_at", { ascending: false })

      if (eventsData) {
        setEvents(eventsData)
      }

      setIsLoading(false)
    }

    loadSignal()
  }, [params.id, router])

  if (isLoading || !signal) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  const getStatusBadge = (status: Signal["status"]) => {
    const styles = {
      pending: "bg-amber-500/10 text-amber-500 border-amber-500/30",
      active: "bg-primary/10 text-primary border-primary/30",
      invalidated: "bg-muted text-muted-foreground border-border",
      target_hit: "bg-primary/10 text-primary border-primary/30",
      stopped_out: "bg-destructive/10 text-destructive border-destructive/30",
    }
    const labels = {
      pending: "Pending",
      active: "Active",
      invalidated: "Invalidated",
      target_hit: "Target Hit",
      stopped_out: "Stopped Out",
    }
    return (
      <span className={`text-xs font-semibold px-3 py-1 rounded-lg border ${styles[status]}`}>
        {labels[status]}
      </span>
    )
  }

  const getEventIcon = (type: string) => {
    switch (type) {
      case "signal_created": return <Clock className="h-4 w-4 text-muted-foreground" />
      case "entry_triggered": return <TrendingUp className="h-4 w-4 text-primary" />
      case "target_1_hit": 
      case "target_2_hit": return <Target className="h-4 w-4 text-primary" />
      case "stop_loss_hit": return <XCircle className="h-4 w-4 text-destructive" />
      case "invalidated": return <AlertTriangle className="h-4 w-4 text-amber-500" />
      default: return <Clock className="h-4 w-4 text-muted-foreground" />
    }
  }

  const getEventLabel = (type: string) => {
    const labels: Record<string, string> = {
      signal_created: "Signal Created",
      entry_triggered: "Entry Triggered",
      target_1_hit: "Target 1 Hit",
      target_2_hit: "Target 2 Hit",
      stop_loss_hit: "Stop Loss Hit",
      invalidated: "Signal Invalidated",
      expired: "Signal Expired",
      manual_closed: "Manually Closed",
    }
    return labels[type] || type
  }

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur-lg">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <button onClick={() => router.back()} className="flex h-10 w-10 items-center justify-center rounded-xl border border-border text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold text-foreground">{signal.symbol}</h1>
                <span className="text-sm text-muted-foreground">/ {signal.timeframe}</span>
              </div>
              <p className="text-xs text-muted-foreground">{signal.setup_type}</p>
            </div>
          </div>
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
              <Crosshair className="h-5 w-5 text-primary-foreground" />
            </div>
          </Link>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto">
        {/* Status and Direction */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${
              signal.direction === "BUY" ? "bg-primary/10" : "bg-destructive/10"
            }`}>
              {signal.direction === "BUY" ? (
                <TrendingUp className="h-6 w-6 text-primary" />
              ) : (
                <TrendingDown className="h-6 w-6 text-destructive" />
              )}
            </div>
            <div>
              <p className="text-sm font-semibold text-foreground">{signal.direction}</p>
              <p className="text-xs text-muted-foreground">Grade {signal.grade}</p>
            </div>
          </div>
          {getStatusBadge(signal.status)}
        </div>

        {/* Trade Plan Visualization */}
        <div className="rounded-xl border border-border bg-card p-4 mb-6">
          <h3 className="text-sm font-semibold text-foreground mb-4">Trade Plan</h3>
          <TradeBox
            entry={signal.entry_price}
            stopLoss={signal.stop_loss}
            target1={signal.target_1}
            target2={signal.target_2 || undefined}
            direction={signal.direction}
            riskReward={signal.risk_reward}
          />
        </div>

        {/* Levels */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground mb-1">Entry</p>
            <p className="text-lg font-semibold text-foreground">{signal.entry_price.toLocaleString()}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground mb-1">Stop Loss</p>
            <p className="text-lg font-semibold text-destructive">{signal.stop_loss.toLocaleString()}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground mb-1">Target 1</p>
            <p className="text-lg font-semibold text-primary">{signal.target_1.toLocaleString()}</p>
          </div>
          <div className="rounded-xl border border-border bg-card p-4">
            <p className="text-xs text-muted-foreground mb-1">Target 2</p>
            <p className="text-lg font-semibold text-primary">{signal.target_2?.toLocaleString() || "—"}</p>
          </div>
        </div>

        {/* Risk/Reward */}
        <div className="rounded-xl border border-border bg-card p-4 mb-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground mb-1">Reward / Risk</p>
              <p className="text-2xl font-bold text-foreground">{signal.risk_reward}</p>
            </div>
            {signal.market_condition && (
              <div className="text-right">
                <p className="text-xs text-muted-foreground mb-1">Market Condition</p>
                <p className="text-sm font-semibold text-foreground capitalize">{signal.market_condition}</p>
              </div>
            )}
          </div>
        </div>

        {/* Why This Qualifies */}
        {signal.reasons && signal.reasons.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-4 mb-6">
            <h3 className="text-sm font-semibold text-foreground mb-3">Why This Setup Qualified</h3>
            <ul className="space-y-2">
              {signal.reasons.map((reason, i) => (
                <li key={i} className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Check className="h-4 w-4 text-primary shrink-0" />
                  {reason}
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Event Timeline */}
        {events.length > 0 && (
          <div className="rounded-xl border border-border bg-card p-4">
            <h3 className="text-sm font-semibold text-foreground mb-4">Event Timeline</h3>
            <div className="space-y-4">
              {events.map((event, i) => (
                <div key={event.id} className="flex items-start gap-3">
                  <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-muted shrink-0">
                    {getEventIcon(event.event_type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">{getEventLabel(event.event_type)}</p>
                    {event.notes && <p className="text-xs text-muted-foreground mt-0.5">{event.notes}</p>}
                    {event.price_at_event && (
                      <p className="text-xs text-muted-foreground mt-0.5">
                        Price: {event.price_at_event.toLocaleString()}
                      </p>
                    )}
                    <p className="text-[10px] text-muted-foreground/70 mt-1">
                      {new Date(event.created_at).toLocaleString()}
                    </p>
                  </div>
                  {i < events.length - 1 && (
                    <div className="absolute left-[19px] top-10 bottom-0 w-px bg-border" />
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Created Date */}
        <p className="text-xs text-muted-foreground text-center mt-6">
          Signal created {new Date(signal.created_at).toLocaleString()}
        </p>
      </main>
    </div>
  )
}
