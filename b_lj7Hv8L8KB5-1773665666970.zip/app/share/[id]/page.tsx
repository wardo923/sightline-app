"use client"

import Link from "next/link"
import { useParams } from "next/navigation"
import { Crosshair, ArrowRight } from "lucide-react"

// Mock profiles for demo - in production this would come from a database
const mockProfiles: Record<string, {
  name: string
  markets: string[]
  tradingStyle: string
  timeframe: string
  setupPreference: string
  riskPerTrade: string
}> = {
  "demo": {
    name: "Kelly",
    markets: ["BTC", "ETH", "SPY"],
    tradingStyle: "Intraday",
    timeframe: "15 minute",
    setupPreference: "Breakout setups",
    riskPerTrade: "1%",
  },
}

export default function ShareProfilePage() {
  const params = useParams()
  const profileId = params.id as string
  
  // Get profile from mock data or localStorage
  let profile = mockProfiles[profileId]
  
  // Try to get from localStorage if not in mock data
  if (!profile && typeof window !== "undefined") {
    const stored = localStorage.getItem("sightline_shared_profile_" + profileId)
    if (stored) {
      profile = JSON.parse(stored)
    }
  }

  // Fallback to demo profile
  if (!profile) {
    profile = mockProfiles["demo"]
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border px-5 py-4">
        <div className="mx-auto max-w-3xl flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Crosshair className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-sm font-bold text-foreground">SightLine</span>
              <span className="text-[9px] font-medium tracking-widest text-primary uppercase">
                Advanced Trading Analytics
              </span>
            </div>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-5 py-12">
        <div className="mx-auto max-w-md">
          {/* Profile Card */}
          <div className="rounded-2xl border border-border bg-card p-6">
            {/* Header */}
            <div className="text-center mb-6">
              <p className="text-xs font-semibold tracking-widest text-primary uppercase mb-2">
                Shared Trading Profile
              </p>
              <h1 className="text-2xl font-bold text-foreground">
                {profile.name}&apos;s SightLine Trading Profile
              </h1>
            </div>

            {/* Profile Details */}
            <div className="space-y-4">
              <ProfileRow label="Markets" value={profile.markets.join(" • ")} />
              <ProfileRow label="Trading Style" value={profile.tradingStyle} />
              <ProfileRow label="Timeframe" value={profile.timeframe} />
              <ProfileRow label="Setup Preference" value={profile.setupPreference} />
              <ProfileRow label="Risk Per Trade" value={profile.riskPerTrade} />
            </div>

            {/* CTA */}
            <div className="mt-8">
              <Link
                href="/get-started"
                className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 glow-green"
              >
                Build Your Own Trading Profile
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>

          {/* Disclaimer */}
          <p className="mt-6 text-center text-xs text-muted-foreground/60">
            This profile shows trading preferences only. No performance data, profits, or account information is shared.
          </p>
        </div>
      </main>
    </div>
  )
}

function ProfileRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between rounded-xl border border-border bg-background/50 px-4 py-3">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className="text-sm font-medium text-foreground">{value}</span>
    </div>
  )
}
