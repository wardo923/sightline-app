import { createClient } from "@/lib/supabase/server"
import { NextResponse } from "next/server"

export async function GET(request: Request) {
  const requestUrl = new URL(request.url)
  const code = requestUrl.searchParams.get("code")
  const error = requestUrl.searchParams.get("error")
  const errorDescription = requestUrl.searchParams.get("error_description")
  const origin = requestUrl.origin

  // Handle OAuth/email errors from Supabase
  if (error) {
    const errorMsg = encodeURIComponent(errorDescription || error)
    return NextResponse.redirect(`${origin}/auth/error?error=${errorMsg}`)
  }

  if (code) {
    const supabase = await createClient()
    const { error: exchangeError } = await supabase.auth.exchangeCodeForSession(code)
    
    if (!exchangeError) {
      // Successfully authenticated - redirect to post-login handler
      // This will check for wizard state and route appropriately
      return NextResponse.redirect(`${origin}/auth/post-login`)
    }
    
    // Code exchange failed
    const errorMsg = encodeURIComponent(exchangeError.message)
    return NextResponse.redirect(`${origin}/auth/error?error=${errorMsg}`)
  }

  // No code provided - redirect to login
  return NextResponse.redirect(`${origin}/auth/login`)
}
