"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

export default function PostLoginPage() {
  const router = useRouter()

  useEffect(() => {
    const handlePostLogin = async () => {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()

      if (!user) {
        // Not logged in - redirect to login
        router.push("/auth/login")
        return
      }

      // Check if user has pending wizard state that needs to be saved
      const wizardAnswers = sessionStorage.getItem("wizard_answers")
      
      if (wizardAnswers) {
        // User came from wizard - route to complete page to save strategy
        router.push("/strategy-wizard/complete")
      } else {
        // Check wizard_completed flag in profile
        const { data: profile } = await supabase
          .from("profiles")
          .select("wizard_completed")
          .eq("id", user.id)
          .single()

        if (profile?.wizard_completed) {
          // User completed wizard - go to dashboard
          router.push("/dashboard")
        } else {
          // No wizard completed - send to strategy wizard
          router.push("/strategy-wizard")
        }
      }
    }

    handlePostLogin()
  }, [router])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-black text-white">
      <div className="animate-spin rounded-full h-10 w-10 border-2 border-[#2bd673] border-t-transparent mb-4" />
      <p className="text-sm text-[#9fb3a7]">Setting up your account...</p>
    </div>
  )
}
