"use client"

import Link from "next/link"
import { useEffect, useState } from "react"
import { Crosshair, Mail, ArrowRight, Loader2, CheckCircle, AlertCircle, RefreshCw, ExternalLink } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface SetupInstructions {
  title: string
  steps: string[]
  resendDocsUrl: string
  supabaseDocsUrl: string
}

export default function SignUpSuccessPage() {
  const [email, setEmail] = useState<string | null>(null)
  const [isResending, setIsResending] = useState(false)
  const [resendStatus, setResendStatus] = useState<"idle" | "success" | "error" | "cooldown">("idle")
  const [resendMessage, setResendMessage] = useState<string | null>(null)
  const [cooldownSeconds, setCooldownSeconds] = useState(0)
  const [setupRequired, setSetupRequired] = useState<SetupInstructions | null>(null)

  useEffect(() => {
    // Get email from sessionStorage
    const storedEmail = sessionStorage.getItem("signup_email")
    if (storedEmail) {
      setEmail(storedEmail)
    }

    // Check if email is properly configured
    fetch("/api/auth/email-status")
      .then(res => res.json())
      .then(data => {
        if (data.setupInstructions) {
          setSetupRequired(data.setupInstructions)
        }
      })
      .catch(() => {
        // Ignore errors
      })
  }, [])

  useEffect(() => {
    // Countdown timer for cooldown
    if (cooldownSeconds > 0) {
      const timer = setTimeout(() => setCooldownSeconds(cooldownSeconds - 1), 1000)
      return () => clearTimeout(timer)
    } else if (cooldownSeconds === 0 && resendStatus === "cooldown") {
      setResendStatus("idle")
    }
  }, [cooldownSeconds, resendStatus])

  const handleResendEmail = async () => {
    if (!email || isResending || cooldownSeconds > 0) return

    setIsResending(true)
    setResendStatus("idle")
    setResendMessage(null)

    try {
      const supabase = createClient()
      
      const { error } = await supabase.auth.resend({
        type: "signup",
        email,
        options: {
          emailRedirectTo: `${window.location.origin}/auth/callback`,
        },
      })

      if (error) {
        // Check for rate limit
        if (error.message.includes("rate") || error.message.includes("limit")) {
          setResendStatus("cooldown")
          setCooldownSeconds(60)
          setResendMessage("Please wait before requesting another email")
        } else {
          setResendStatus("error")
          setResendMessage(error.message)
        }
      } else {
        setResendStatus("success")
        setResendMessage("Verification email sent!")
        setCooldownSeconds(60)
      }
    } catch (err) {
      setResendStatus("error")
      setResendMessage("Failed to resend email. Please try again.")
    } finally {
      setIsResending(false)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between px-5 py-4 lg:px-12">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
            <Crosshair className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-sm font-bold text-foreground">SightLine</span>
        </Link>
      </header>

      {/* Main */}
      <main className="flex flex-1 items-center justify-center px-5 py-8">
        <div className="w-full max-w-sm text-center">
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <Mail className="h-8 w-8 text-primary" />
          </div>

          <h1 className="text-2xl font-bold text-foreground">Check your email</h1>
          <p className="mt-3 text-sm text-muted-foreground">
            {"We've sent a confirmation link to "}
            {email ? (
              <span className="font-medium text-foreground">{email}</span>
            ) : (
              "your email address"
            )}
            {". Click the link to verify your account."}
          </p>

          {/* Resend Section */}
          <div className="mt-8 rounded-xl border border-border bg-card p-4 space-y-3">
            <p className="text-xs text-muted-foreground">
              {"Didn't receive an email? Check your spam folder or click below to resend."}
            </p>

            {/* Status Messages */}
            {resendStatus === "success" && (
              <div className="flex items-center justify-center gap-2 text-sm text-green-500">
                <CheckCircle className="h-4 w-4" />
                {resendMessage}
              </div>
            )}

            {resendStatus === "error" && (
              <div className="flex items-center justify-center gap-2 text-sm text-destructive">
                <AlertCircle className="h-4 w-4" />
                {resendMessage}
              </div>
            )}

            {resendStatus === "cooldown" && cooldownSeconds > 0 && (
              <p className="text-xs text-muted-foreground">
                You can request another email in {cooldownSeconds}s
              </p>
            )}

            {/* Resend Button */}
            <button
              onClick={handleResendEmail}
              disabled={isResending || cooldownSeconds > 0 || !email}
              className="inline-flex items-center justify-center gap-2 rounded-lg bg-muted px-4 py-2 text-sm font-medium text-foreground hover:bg-muted/80 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {isResending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : cooldownSeconds > 0 ? (
                <>
                  <RefreshCw className="h-4 w-4" />
                  Resend in {cooldownSeconds}s
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4" />
                  Resend verification email
                </>
              )}
            </button>
          </div>

          {/* Setup Required Warning (for admins) */}
          {setupRequired && (
            <div className="mt-6 rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-left">
              <p className="text-xs font-medium text-amber-500 mb-2 flex items-center gap-2">
                <AlertCircle className="h-3.5 w-3.5" />
                {setupRequired.title}
              </p>
              <p className="text-xs text-muted-foreground mb-3">
                Email verification requires SMTP configuration. Follow these steps:
              </p>
              <ol className="text-xs text-muted-foreground space-y-1 list-decimal list-inside mb-3">
                <li>Create a Resend account at resend.com</li>
                <li>Add RESEND_API_KEY to environment variables</li>
                <li>Configure Supabase SMTP settings</li>
              </ol>
              <div className="flex gap-2">
                <a
                  href={setupRequired.resendDocsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                >
                  Resend + Supabase Guide
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </div>
          )}

          {/* Troubleshooting Tips */}
          <div className="mt-6 rounded-xl border border-border bg-muted/30 p-4 text-left">
            <p className="text-xs font-medium text-foreground mb-2">Having trouble?</p>
            <ul className="text-xs text-muted-foreground space-y-1">
              <li>• Check your spam or junk folder</li>
              <li>• Make sure you entered the correct email</li>
              <li>• Wait a few minutes for the email to arrive</li>
              <li>• Try using a different email address</li>
            </ul>
          </div>

          <div className="mt-6 flex flex-col items-center gap-3">
            <Link
              href="/auth/login"
              className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
            >
              Already verified? Sign in
              <ArrowRight className="h-4 w-4" />
            </Link>

            <Link
              href="/auth/sign-up"
              className="text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              Use a different email
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
