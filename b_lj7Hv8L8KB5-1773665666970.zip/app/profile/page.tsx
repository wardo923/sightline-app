"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { 
  Crosshair, 
  ArrowLeft, 
  User,
  Target,
  Clock,
  BarChart3,
  Settings,
  LogOut,
  ChevronRight,
  Shield,
  Edit,
  Lock,
  Zap,
  RefreshCw,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { getModelConfig, MARKET_TYPES } from "@/lib/signal-engine/models"

interface UserProfile {
  id: string
  full_name: string | null
  email: string
}

interface UserStrategy {
  id: string
  name: string
  model_name: string
  asset: string
  market_type: string
  preferred_timeframe: string
  alert_frequency: string
  markets: string[]
  trading_style: string
  setup_preference: string
  setup_frequency: string
  risk_per_trade: string
  confirmation_preference: string
  alert_style: string
}

export default function ProfilePage() {
  const router = useRouter()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [strategy, setStrategy] = useState<UserStrategy | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadProfile() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        router.push("/auth/login")
        return
      }

      // Fetch profile
      const { data: profileData } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .single()

      setProfile({
        id: user.id,
        full_name: profileData?.full_name || null,
        email: user.email || "",
      })

      // Fetch strategy
      const { data: strategyData } = await supabase
        .from("strategies")
        .select("*")
        .eq("user_id", user.id)
        .eq("is_active", true)
        .single()

      if (strategyData) {
        setStrategy(strategyData)
      }

      setIsLoading(false)
    }

    loadProfile()
  }, [router])

  const handleLogout = async () => {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
  }

  if (isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  // Get full model config from the new models system
  const modelConfig = strategy?.model_name ? getModelConfig(strategy.model_name) : null
  const marketType = strategy?.market_type ? MARKET_TYPES[strategy.market_type as keyof typeof MARKET_TYPES] : null

  return (
    <div className="min-h-screen bg-background pb-8">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur-lg">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <button onClick={() => router.back()} className="flex h-10 w-10 items-center justify-center rounded-xl border border-border text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="h-4 w-4" />
            </button>
            <h1 className="text-lg font-bold text-foreground">Profile</h1>
          </div>
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
              <Crosshair className="h-5 w-5 text-primary-foreground" />
            </div>
          </Link>
        </div>
      </header>

      <main className="px-4 py-6 max-w-lg mx-auto">
        {/* User Info */}
        <div className="flex items-center gap-4 mb-8">
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary/10">
            <User className="h-8 w-8 text-primary" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-foreground">{profile?.full_name || "Trader"}</h2>
            <p className="text-sm text-muted-foreground">{profile?.email}</p>
          </div>
        </div>

        {/* Account Section */}
        <div className="mb-6">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Account</h3>
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <button className="w-full flex items-center justify-between p-4 border-b border-border hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <Edit className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Edit Profile</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
            <button className="w-full flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <Shield className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Update Password</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </button>
          </div>
        </div>

        {/* Active Model Summary */}
        {strategy && modelConfig && (
          <div className="mb-6">
            <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Your SightLine Model</h3>
            <div className={`rounded-2xl border border-border bg-gradient-to-br ${modelConfig.gradient} p-5`}>
              {/* Model Header */}
              <div className="flex items-center gap-3 mb-4">
                <div className="rounded-xl bg-background/50 p-3 text-primary">
                  <Zap className="h-6 w-6" />
                </div>
                <div>
                  <h4 className="text-lg font-bold text-foreground">{modelConfig.name}</h4>
                  <p className="text-xs text-primary font-medium">{modelConfig.subtitle}</p>
                </div>
              </div>

              {/* Model Details */}
              <div className="space-y-3 rounded-xl bg-background/50 p-4">
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Asset
                  </span>
                  <span className="text-sm font-bold text-foreground">{strategy.asset}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Market Type
                  </span>
                  <span className="text-sm font-medium text-foreground">{marketType?.name || strategy.market_type}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Timeframe
                  </span>
                  <span className="text-sm font-medium text-foreground">{strategy.preferred_timeframe}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Session
                  </span>
                  <span className="text-sm font-medium text-foreground">{modelConfig.session}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Signal Type
                  </span>
                  <span className="text-sm font-medium text-foreground">{modelConfig.signalType}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Lock className="h-3.5 w-3.5" />
                    Min Reward / Risk
                  </span>
                  <span className="text-sm font-bold text-primary">{modelConfig.minRiskReward} : 1</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Clock className="h-3.5 w-3.5" />
                    Alerts
                  </span>
                  <span className="text-sm font-medium text-foreground">
                    {strategy.alert_frequency === "real_time" ? "Real-Time" : "Batched"}
                  </span>
                </div>
              </div>

              {/* Change Model Button */}
              <Link 
                href="/strategy-wizard"
                className="mt-4 flex items-center justify-center gap-2 w-full h-11 rounded-xl border border-primary/30 text-sm font-semibold text-primary hover:bg-primary/5 transition-colors"
              >
                <RefreshCw className="h-4 w-4" />
                Change Model
              </Link>
            </div>
          </div>
        )}

        {/* Settings Links */}
        <div className="mb-6">
          <h3 className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">Settings</h3>
          <div className="rounded-xl border border-border bg-card overflow-hidden">
            <Link href="/dashboard/settings" className="flex items-center justify-between p-4 border-b border-border hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <Settings className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Notification Preferences</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </Link>
            <Link href="/signals" className="flex items-center justify-between p-4 hover:bg-muted/50 transition-colors">
              <div className="flex items-center gap-3">
                <BarChart3 className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm font-medium text-foreground">Signal History</span>
              </div>
              <ChevronRight className="h-5 w-5 text-muted-foreground" />
            </Link>
          </div>
        </div>

        {/* Log Out */}
        <button
          onClick={handleLogout}
          className="flex items-center justify-center gap-2 w-full h-12 rounded-xl border border-destructive/30 text-destructive hover:bg-destructive/5 transition-colors"
        >
          <LogOut className="h-4 w-4" />
          <span className="text-sm font-medium">Log Out</span>
        </button>
      </main>
    </div>
  )
}
