"use client"

import { useState, useEffect, use } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  Crosshair,
  ChevronLeft,
  Check,
  Lock,
  Loader2,
  TrendingUp,
  TrendingDown,
  Zap,
  Target,
  Shield,
  Activity,
  BarChart2,
  Maximize2,
  RefreshCw,
  GitPullRequest,
  Rocket,
  Repeat,
  Sunrise,
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { 
  getModelConfig, 
  generateExampleTrade, 
  ModelConfig,
  MARKET_TYPES 
} from "@/lib/signal-engine/models"

// Icon mapping
const iconMap: Record<string, typeof TrendingUp> = {
  'sunrise': Sunrise,
  'activity': Activity,
  'zap': Zap,
  'trending-up': TrendingUp,
  'rocket': Rocket,
  'bar-chart-2': BarChart2,
  'git-pull-request': GitPullRequest,
  'shield': Shield,
  'maximize-2': Maximize2,
  'refresh-cw': RefreshCw,
  'repeat': Repeat,
  'target': Target,
}

function getIcon(iconName: string) {
  return iconMap[iconName] || Zap
}

// ============================================
// EXAMPLE TRADE PANEL
// ============================================

interface ExampleTradePanelProps {
  model: ModelConfig
  asset: string
  timeframe: string
}

function ExampleTradePanel({ model, asset, timeframe }: ExampleTradePanelProps) {
  const [trade, setTrade] = useState(generateExampleTrade(model.id, asset))

  useEffect(() => {
    setTrade(generateExampleTrade(model.id, asset))
  }, [model.id, asset])

  if (!trade) return null

  const isBuy = trade.direction === 'BUY'
  const formatPrice = (price: number) => {
    if (price >= 1000) return price.toFixed(0)
    if (price >= 100) return price.toFixed(2)
    return price.toFixed(2)
  }

  return (
    <div className="rounded-2xl border border-border bg-gradient-to-br from-card to-card/50 p-5">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
          Example Trade
        </h3>
        <span className="text-xs text-muted-foreground">{timeframe}</span>
      </div>

      {/* Asset & Direction */}
      <div className="flex items-center gap-3 mb-5">
        <span className="text-2xl font-bold text-foreground">{asset}</span>
        <span className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-bold ${
          isBuy 
            ? "bg-primary/15 text-primary" 
            : "bg-destructive/15 text-destructive"
        }`}>
          {isBuy ? <TrendingUp className="h-4 w-4" /> : <TrendingDown className="h-4 w-4" />}
          {trade.direction}
        </span>
      </div>

      {/* Mini Chart Visualization */}
      <div className="relative h-32 mb-5 rounded-xl bg-background/50 border border-border overflow-hidden">
        <svg className="w-full h-full" viewBox="0 0 200 100" preserveAspectRatio="none">
          {/* Background grid */}
          <defs>
            <pattern id="grid" width="20" height="20" patternUnits="userSpaceOnUse">
              <path d="M 20 0 L 0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.5" className="text-border/30" />
            </pattern>
          </defs>
          <rect width="200" height="100" fill="url(#grid)" />
          
          {/* Price levels */}
          {isBuy ? (
            <>
              {/* Stop loss line */}
              <line x1="0" y1="75" x2="200" y2="75" stroke="currentColor" strokeWidth="1" strokeDasharray="4" className="text-destructive/50" />
              {/* Entry line */}
              <line x1="0" y1="55" x2="200" y2="55" stroke="currentColor" strokeWidth="1.5" className="text-foreground/50" />
              {/* Target line */}
              <line x1="0" y1="20" x2="200" y2="20" stroke="currentColor" strokeWidth="1" strokeDasharray="4" className="text-primary/50" />
              
              {/* Price movement path */}
              <path 
                d="M 20 70 Q 40 65, 60 60 T 100 55 T 140 45 T 180 25" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                className="text-primary"
              />
            </>
          ) : (
            <>
              {/* Stop loss line */}
              <line x1="0" y1="25" x2="200" y2="25" stroke="currentColor" strokeWidth="1" strokeDasharray="4" className="text-destructive/50" />
              {/* Entry line */}
              <line x1="0" y1="45" x2="200" y2="45" stroke="currentColor" strokeWidth="1.5" className="text-foreground/50" />
              {/* Target line */}
              <line x1="0" y1="80" x2="200" y2="80" stroke="currentColor" strokeWidth="1" strokeDasharray="4" className="text-primary/50" />
              
              {/* Price movement path */}
              <path 
                d="M 20 30 Q 40 35, 60 40 T 100 45 T 140 55 T 180 75" 
                fill="none" 
                stroke="currentColor" 
                strokeWidth="2" 
                className="text-destructive"
              />
            </>
          )}
        </svg>

        {/* Level labels */}
        <div className="absolute right-2 top-2 text-[10px] text-primary font-medium">Target</div>
        <div className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] text-foreground font-medium">Entry</div>
        <div className="absolute right-2 bottom-2 text-[10px] text-destructive font-medium">Stop</div>
      </div>

      {/* Trade Levels */}
      <div className="space-y-3">
        <div className="flex items-center justify-between py-2 border-b border-border/50">
          <span className="text-sm text-muted-foreground">Entry</span>
          <span className="text-sm font-bold text-foreground font-mono">{formatPrice(trade.entry)}</span>
        </div>
        <div className="flex items-center justify-between py-2 border-b border-border/50">
          <span className="text-sm text-muted-foreground">Stop Loss</span>
          <span className="text-sm font-bold text-destructive font-mono">{formatPrice(trade.stop)}</span>
        </div>
        <div className="flex items-center justify-between py-2 border-b border-border/50">
          <span className="text-sm text-muted-foreground">Target</span>
          <span className="text-sm font-bold text-primary font-mono">{formatPrice(trade.target)}</span>
        </div>
        <div className="flex items-center justify-between py-2">
          <span className="text-sm text-muted-foreground">Reward / Risk</span>
          <span className="text-sm font-bold text-primary">{trade.riskReward}</span>
        </div>
      </div>
    </div>
  )
}

// ============================================
// MAIN PAGE COMPONENT
// ============================================

export default function ModelDetailPage({ params }: { params: Promise<{ modelId: string }> }) {
  const { modelId } = use(params)
  const router = useRouter()
  const [model, setModel] = useState<ModelConfig | null>(null)
  const [selectedAsset, setSelectedAsset] = useState<string>("")
  const [selectedTimeframe, setSelectedTimeframe] = useState<string>("")
  const [isActivating, setIsActivating] = useState(false)
  const [userName, setUserName] = useState("")

  useEffect(() => {
    const modelConfig = getModelConfig(modelId)
    if (!modelConfig) {
      router.push("/strategy-wizard")
      return
    }
    setModel(modelConfig)
    setSelectedAsset(modelConfig.assets[0])
    setSelectedTimeframe(modelConfig.timeframes[0])
  }, [modelId, router])

  const handleActivate = async () => {
    if (!model || !selectedAsset || !selectedTimeframe) return
    
    setIsActivating(true)
    
    try {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      
      if (user) {
        // Deactivate any existing strategies
        await supabase
          .from("strategies")
          .update({ is_active: false })
          .eq("user_id", user.id)

        // Create new strategy with locked model parameters
        const { error } = await supabase.from("strategies").insert({
          user_id: user.id,
          name: `${model.name} - ${selectedAsset}`,
          model_name: model.id,
          market_type: model.marketType,
          asset: selectedAsset,
          preferred_timeframe: selectedTimeframe,
          alert_frequency: "real_time",
          // Populate legacy columns from model
          markets: [selectedAsset],
          trading_style: model.confirmationStyle,
          setup_preference: model.setupTypes.join(","),
          confirmation_preference: model.confirmationStyle,
          setup_frequency: `${model.minRiskReward}:1`,
          risk_per_trade: "1%",
          is_active: true,
        })
        
        if (error) {
          console.error("Error saving strategy:", error)
        }

        // Update profile with wizard_completed = true
        const { error: profileError } = await supabase.from("profiles").upsert({
          id: user.id,
          full_name: userName.trim() || undefined,
          wizard_completed: true,
          updated_at: new Date().toISOString(),
        })

        if (profileError) {
          alert(`Profile update failed: ${profileError.message}`)
          setIsActivating(false)
          return
        }

        // Verify wizard_completed is set before redirect
        const { data: updatedProfile } = await supabase
          .from("profiles")
          .select("wizard_completed")
          .eq("id", user.id)
          .single()

        if (!updatedProfile?.wizard_completed) {
          alert("Failed to complete wizard. Please try again.")
          setIsActivating(false)
          return
        }
      }
      
      router.replace("/dashboard")
    } catch (error) {
      console.error("Error activating strategy:", error)
      alert("An error occurred. Please try again.")
    } finally {
      setIsActivating(false)
    }
  }

  if (!model) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  const Icon = getIcon(model.icon)
  const marketType = MARKET_TYPES[model.marketType]

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-border bg-card/30 backdrop-blur-sm px-4 py-4">
        <Link href="/" className="flex items-center gap-2">
          <Crosshair className="h-6 w-6 text-primary" />
          <span className="text-lg font-bold text-foreground">SightLine</span>
        </Link>
      </header>

      {/* Content */}
      <main className="flex-1 overflow-y-auto">
        <div className="mx-auto max-w-4xl px-4 py-6">
          {/* Back Button */}
          <button 
            onClick={() => router.back()}
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-6"
          >
            <ChevronLeft className="h-4 w-4" />
            Back to models
          </button>

          {/* Model Header */}
          <div className="text-center mb-8">
            <div className={`inline-flex items-center justify-center rounded-2xl bg-gradient-to-br ${model.gradient} p-4 mb-4`}>
              <Icon className="h-8 w-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold text-foreground">{model.name}</h1>
            <p className="mt-1 text-lg text-primary font-medium">{model.subtitle}</p>
          </div>

          {/* Two Column Layout */}
          <div className="grid gap-6 lg:grid-cols-2">
            
            {/* Left: Strategy Summary Panel */}
            <div className="space-y-6">
              <div className="rounded-2xl border border-border bg-card/50 p-5">
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                  Strategy Configuration
                </h2>

                {/* Asset Selection */}
                <div className="mb-5">
                  <label className="text-xs font-medium text-foreground mb-2 block">
                    Asset Focus
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {model.assets.map((asset) => (
                      <button
                        key={asset}
                        onClick={() => setSelectedAsset(asset)}
                        className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                          selectedAsset === asset
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {asset}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Timeframe Selection */}
                <div className="mb-5">
                  <label className="text-xs font-medium text-foreground mb-2 block">
                    Timeframe
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {model.timeframes.map((tf) => (
                      <button
                        key={tf}
                        onClick={() => setSelectedTimeframe(tf)}
                        className={`rounded-lg px-4 py-2 text-sm font-medium transition-all ${
                          selectedTimeframe === tf
                            ? "bg-primary text-primary-foreground"
                            : "bg-muted text-muted-foreground hover:bg-muted/80"
                        }`}
                      >
                        {tf}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Locked Parameters */}
                <div className="space-y-3 pt-4 border-t border-border">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <Lock className="h-3.5 w-3.5" />
                      Session
                    </span>
                    <span className="text-sm font-medium text-foreground">{model.session}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <Lock className="h-3.5 w-3.5" />
                      Signal Type
                    </span>
                    <span className="text-sm font-medium text-foreground">{model.signalType}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground flex items-center gap-2">
                      <Lock className="h-3.5 w-3.5" />
                      Min Reward/Risk
                    </span>
                    <span className="text-sm font-medium text-primary">{model.minRiskReward} : 1</span>
                  </div>
                </div>
              </div>

              {/* Why This Strategy Works */}
              <div className="rounded-2xl border border-border bg-card/50 p-5">
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-4">
                  Why This Strategy Works
                </h2>
                <ul className="space-y-3">
                  {model.whyItWorks.map((reason, idx) => (
                    <li key={idx} className="flex items-start gap-3">
                      <div className="rounded-full bg-primary/20 p-1 mt-0.5">
                        <Check className="h-3 w-3 text-primary" />
                      </div>
                      <span className="text-sm text-foreground">{reason}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Name Input */}
              <div className="rounded-2xl border border-border bg-card/50 p-5">
                <label className="text-xs font-medium text-foreground mb-2 block">
                  Your Name <span className="text-muted-foreground">(optional)</span>
                </label>
                <input
                  type="text"
                  value={userName}
                  onChange={(e) => setUserName(e.target.value)}
                  placeholder="Enter your name"
                  className="w-full rounded-xl border border-border bg-background px-4 py-3 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
            </div>

            {/* Right: Example Trade Panel */}
            <div>
              <ExampleTradePanel 
                model={model} 
                asset={selectedAsset} 
                timeframe={selectedTimeframe}
              />

              {/* Disclaimer */}
              <div className="mt-4 rounded-xl border border-amber-500/30 bg-amber-500/5 p-4">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  <span className="font-semibold text-amber-500">Important:</span>{" "}
                  This is an example trade for illustration only. Actual signals depend on live market conditions. 
                  Past performance does not guarantee future results. This is not financial advice.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30 backdrop-blur-sm p-4">
        <div className="mx-auto max-w-4xl flex items-center justify-between gap-4">
          <button
            onClick={() => router.back()}
            className="px-6 py-3 rounded-xl border border-border text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-card transition-all"
          >
            Back
          </button>
          <button
            onClick={handleActivate}
            disabled={isActivating || !selectedAsset || !selectedTimeframe}
            className="flex-1 max-w-xs flex items-center justify-center gap-2 rounded-xl bg-primary py-3.5 text-base font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            {isActivating ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Activating...
              </>
            ) : (
              <>
                Activate Strategy
              </>
            )}
          </button>
        </div>
      </footer>
    </div>
  )
}
