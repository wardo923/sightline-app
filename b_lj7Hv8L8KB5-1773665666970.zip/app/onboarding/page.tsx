import type { Metadata } from "next"
import { MasterStrategyWizard } from "@/components/master-strategy-wizard"

export const metadata: Metadata = {
  title: "Strategy Wizard - SightLine Trading Systems",
  description:
    "Calibrate your personalized trading strategy profile. Answer 12 quick questions and SightLine will build your monitoring profile.",
}

export default function OnboardingPage() {
  return <MasterStrategyWizard mode="create" />
}
