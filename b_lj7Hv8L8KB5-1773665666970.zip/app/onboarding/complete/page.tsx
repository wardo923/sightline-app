import { redirect } from "next/navigation"

// Redirect legacy onboarding complete to master wizard complete
export default function OnboardingCompletePage() {
  redirect("/strategy-wizard/complete")
}
