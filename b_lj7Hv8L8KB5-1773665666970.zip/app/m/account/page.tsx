"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { User } from "@supabase/supabase-js"
import { useRouter } from "next/navigation"
import { 
  User as UserIcon, 
  CreditCard, 
  Bell, 
  Shield, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Crown
} from "lucide-react"
import { TopBar } from "@/components/mobile/top-bar"
import { BottomTabs } from "@/components/mobile/bottom-tabs"

export default function AccountPage() {
  const [user, setUser] = useState<User | null>(null)
  const [tier, setTier] = useState<string>("STARTER")
  const [loading, setLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    async function loadUser() {
      const { data: { user } } = await supabase.auth.getUser()
      setUser(user)
      
      if (user) {
        const { data } = await supabase
          .from("user_usage")
          .select("tier")
          .eq("user_id", user.id)
          .single()
        if (data) setTier(data.tier)
      }
      setLoading(false)
    }
    loadUser()
  }, [supabase])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/auth/sign-in")
  }

  const menuItems = [
    { icon: UserIcon, label: "Edit Profile", href: "/m/account/profile" },
    { icon: CreditCard, label: "Subscription", href: "/pricing", badge: tier },
    { icon: Bell, label: "Notifications", href: "/m/account/notifications" },
    { icon: Shield, label: "Privacy & Security", href: "/m/account/security" },
    { icon: HelpCircle, label: "Help & Support", href: "/m/account/support" },
  ]

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-primary border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <TopBar title="Account" />
      
      <main className="flex-1 overflow-y-auto pb-20 pt-14">
        {/* Profile Header */}
        <div className="flex flex-col items-center px-4 py-6">
          <div className="relative">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-primary/20 to-primary/5 ring-2 ring-primary/30">
              <span className="text-2xl font-bold text-primary">
                {user?.user_metadata?.full_name?.[0] || user?.email?.[0]?.toUpperCase() || "U"}
              </span>
            </div>
            {tier !== "STARTER" && (
              <div className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-amber-500">
                <Crown className="h-3 w-3 text-black" />
              </div>
            )}
          </div>
          <h2 className="mt-3 text-lg font-semibold text-foreground">
            {user?.user_metadata?.full_name || "Trader"}
          </h2>
          <p className="text-sm text-muted-foreground">{user?.email}</p>
          <div className="mt-2 rounded-full bg-primary/10 px-3 py-1">
            <span className="text-xs font-medium text-primary">{tier} Plan</span>
          </div>
        </div>

        {/* Menu Items */}
        <div className="px-4">
          <div className="rounded-xl border border-border bg-card/50 divide-y divide-border">
            {menuItems.map((item) => (
              <button
                key={item.label}
                onClick={() => router.push(item.href)}
                className="flex w-full items-center justify-between p-4 transition-colors hover:bg-muted/50"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-muted">
                    <item.icon className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{item.label}</span>
                </div>
                <div className="flex items-center gap-2">
                  {item.badge && (
                    <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-semibold text-primary">
                      {item.badge}
                    </span>
                  )}
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
              </button>
            ))}
          </div>

          {/* Sign Out Button */}
          <button
            onClick={handleSignOut}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-destructive/30 bg-destructive/10 p-4 transition-colors hover:bg-destructive/20"
          >
            <LogOut className="h-4 w-4 text-destructive" />
            <span className="text-sm font-medium text-destructive">Sign Out</span>
          </button>

          {/* App Info */}
          <div className="mt-8 text-center">
            <p className="text-xs text-muted-foreground">SightLine v1.0.0</p>
            <p className="mt-1 text-[10px] text-muted-foreground/60">
              Made with precision for traders
            </p>
          </div>
        </div>
      </main>

      <BottomTabs />
    </div>
  )
}
