"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { 
  TrendingUp, 
  TrendingDown,
  Activity,
  Target,
  Zap,
  Clock,
  ArrowDownUp,
  Layers,
  Settings,
  RefreshCw,
  ChevronRight,
  Bell,
  Mail,
  Smartphone
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { STRATEGY_INFO, StrategyKey } from "@/lib/strategies"
import { useMarketData } from "@/hooks/use-market-data"

const STRATEGY_ICONS: Record<StrategyKey, typeof Zap> = {
  MOMENTUM_BREAKOUT: TrendingUp,
  LIQUIDITY_REVERSAL: ArrowDownUp,
  STRUCTURE_REACTION: Target,
  OPENING_RANGE: Clock,
  VOLATILITY_EXPANSION: Zap,
  SESSION_STRUCTURE: Layers
}

interface UserStrategy {
  id: string
  bundle_name: string
  asset: string
  market_type: string
  timeframe: string
  alert_frequency: string
  confidence_score: number
  wizard_answers: Record<string, string>
  created_at: string
}

interface UsageStats {
  tier: string
  signalsToday: number
  signalsLimit: number
  alertsToday: number
  alertsLimit: number
}

export default function DashboardPage() {
  const [strategy, setStrategy] = useState<UserStrategy | null>(null)
  const [usage, setUsage] = useState<UsageStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  
  const { marketData, isLoading: marketLoading } = useMarketData(strategy?.asset || "")

  useEffect(() => {
    async function loadData() {
      try {
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()
        
        if (!user) return
        
        // Get active strategy
        const { data: strategies } = await supabase
          .from("strategies")
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
        
        if (strategies && strategies.length > 0) {
          setStrategy(strategies[0])
        }
        
        // Fetch usage stats
        try {
          const usageRes = await fetch("/api/signals/scan")
          if (usageRes.ok) {
            const usageData = await usageRes.json()
            setUsage({
              tier: usageData.tier || "STARTER",
              signalsToday: usageData.usage?.signalsToday || 0,
              signalsLimit: usageData.usage?.signalsLimit || 5,
              alertsToday: usageData.usage?.alertsToday || 0,
              alertsLimit: usageData.usage?.alertsLimit || 10,
            })
          }
        } catch {
          // Ignore
        }
      } catch {
        // Ignore
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        <div className="h-32 rounded-xl bg-card animate-pulse" />
        <div className="h-24 rounded-xl bg-card animate-pulse" />
        <div className="h-48 rounded-xl bg-card animate-pulse" />
      </div>
    )
  }

  const strategyKey = strategy?.bundle_name as StrategyKey
  const strategyInfo = strategyKey ? STRATEGY_INFO[strategyKey] : null
  const StrategyIcon = strategyKey ? STRATEGY_ICONS[strategyKey] : Activity

  return (
    <div className="p-4 space-y-4">
      {/* Market Data Card */}
      {strategy && marketData && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <span className="text-lg font-bold text-foreground">{strategy.asset}</span>
              <span className="text-xs text-muted-foreground">{strategy.market_type}</span>
            </div>
            {marketData.changePercent !== undefined && (
              <div className={`flex items-center gap-1 ${marketData.changePercent >= 0 ? "text-primary" : "text-destructive"}`}>
                {marketData.changePercent >= 0 ? (
                  <TrendingUp className="h-4 w-4" />
                ) : (
                  <TrendingDown className="h-4 w-4" />
                )}
                <span className="text-sm font-semibold">
                  {marketData.changePercent >= 0 ? "+" : ""}{marketData.changePercent.toFixed(2)}%
                </span>
              </div>
            )}
          </div>
          <div className="text-2xl font-bold text-foreground mb-2">
            ${marketData.price?.toLocaleString() || "—"}
          </div>
          <div className="grid grid-cols-3 gap-3 text-xs">
            <div>
              <p className="text-muted-foreground">High</p>
              <p className="font-semibold text-foreground">${marketData.high?.toLocaleString() || "—"}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Low</p>
              <p className="font-semibold text-foreground">${marketData.low?.toLocaleString() || "—"}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Volume</p>
              <p className="font-semibold text-foreground">{marketData.volume ? `${(marketData.volume / 1000000).toFixed(1)}M` : "—"}</p>
            </div>
          </div>
        </div>
      )}

      {/* Active Strategy */}
      {strategy ? (
        <div className="rounded-xl border border-primary/30 bg-card p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
                <StrategyIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">
                  {strategyInfo?.name || strategy.bundle_name}
                </h3>
                <p className="text-xs text-muted-foreground">
                  {strategy.timeframe} • {strategy.alert_frequency}
                </p>
              </div>
            </div>
            <Link href="/m/wizard">
              <Button variant="ghost" size="sm" className="text-xs">
                <Settings className="h-3 w-3 mr-1" />
                Edit
              </Button>
            </Link>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full"
                style={{ width: `${strategy.confidence_score}%` }}
              />
            </div>
            <span className="text-xs font-semibold text-primary">
              {strategy.confidence_score}%
            </span>
          </div>
        </div>
      ) : (
        <div className="rounded-xl border border-border bg-card p-4 text-center">
          <p className="text-sm text-muted-foreground mb-3">No strategy configured</p>
          <Link href="/m/wizard">
            <Button size="sm">Configure Strategy</Button>
          </Link>
        </div>
      )}

      {/* Usage Stats */}
      {usage && (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-semibold text-foreground">Daily Usage</h3>
            <span className="text-xs text-primary font-medium">{usage.tier}</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground">Signals</span>
                <span className="text-xs text-foreground">{usage.signalsToday}/{usage.signalsLimit}</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <div 
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${(usage.signalsToday / usage.signalsLimit) * 100}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs text-muted-foreground">Alerts</span>
                <span className="text-xs text-foreground">{usage.alertsToday}/{usage.alertsLimit}</span>
              </div>
              <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                <div 
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${(usage.alertsToday / usage.alertsLimit) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Alert Delivery Settings */}
      <div className="rounded-xl border border-border bg-card p-4">
        <h3 className="text-sm font-semibold text-foreground mb-3">Alert Delivery</h3>
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Bell className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-foreground">Push Notifications</span>
            </div>
            <span className="text-xs text-primary">Enabled</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-foreground">Email</span>
            </div>
            <span className="text-xs text-muted-foreground">Disabled</span>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm text-foreground">SMS</span>
            </div>
            <span className="text-xs text-muted-foreground">Disabled</span>
          </div>
        </div>
      </div>
    </div>
  )
}
