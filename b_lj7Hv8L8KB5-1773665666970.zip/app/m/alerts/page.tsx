"use client"

import { useEffect, useState } from "react"
import { Bell, Filter } from "lucide-react"
import { AlertCard } from "@/components/mobile/alert-card"
import { useSignals } from "@/hooks/use-signals"
import { Button } from "@/components/ui/button"

type FilterStatus = "all" | "watching" | "triggered" | "target_reached" | "invalidated"

export default function AlertsPage() {
  const { signals, isLoading, refreshSignals } = useSignals()
  const [filter, setFilter] = useState<FilterStatus>("all")
  const [isRefreshing, setIsRefreshing] = useState(false)

  const handleRefresh = async () => {
    setIsRefreshing(true)
    await refreshSignals()
    setIsRefreshing(false)
  }

  // Map signals to alert card format with mock data for missing fields
  const alerts = signals.map((signal) => ({
    id: signal.id,
    asset: signal.asset,
    setupType: signal.setupType || "Momentum Breakout",
    timeframe: signal.timeframe,
    bias: (signal.bias === "bullish" || signal.bias === "bearish" ? signal.bias : "bullish") as "bullish" | "bearish",
    entryZone: signal.entry ? `${(signal.entry * 0.998).toFixed(2)} - ${signal.entry.toFixed(2)}` : "—",
    stopLoss: signal.stop?.toFixed(2) || "—",
    target1: signal.target?.toFixed(2) || "—",
    target2: signal.target ? (signal.target * 1.015).toFixed(2) : undefined,
    status: (signal.status === "active" ? "watching" : 
             signal.status === "triggered" ? "triggered" :
             signal.status === "closed" ? "target_reached" : "watching") as "watching" | "triggered" | "target_reached" | "invalidated",
    timestamp: new Date(signal.timestamp).toLocaleString(),
  }))

  const filteredAlerts = filter === "all" 
    ? alerts 
    : alerts.filter(a => a.status === filter)

  // Static demo alerts for when no signals exist
  const demoAlerts = [
    {
      id: "demo-1",
      asset: "BTC",
      setupType: "Momentum Breakout",
      timeframe: "1H",
      bias: "bullish" as const,
      entryZone: "63,250 - 63,420",
      stopLoss: "62,980",
      target1: "63,900",
      target2: "64,300",
      status: "watching" as const,
      timestamp: "Today, 9:30 AM",
    },
    {
      id: "demo-2",
      asset: "ETH",
      setupType: "Structure Reaction",
      timeframe: "4H",
      bias: "bullish" as const,
      entryZone: "3,420 - 3,440",
      stopLoss: "3,380",
      target1: "3,520",
      target2: "3,580",
      status: "triggered" as const,
      timestamp: "Today, 8:15 AM",
    },
    {
      id: "demo-3",
      asset: "SPY",
      setupType: "Opening Range",
      timeframe: "15M",
      bias: "bearish" as const,
      entryZone: "582.50 - 583.00",
      stopLoss: "584.20",
      target1: "580.50",
      target2: "579.00",
      status: "target_reached" as const,
      timestamp: "Yesterday, 10:00 AM",
    },
  ]

  const displayAlerts = alerts.length > 0 ? filteredAlerts : (filter === "all" ? demoAlerts : demoAlerts.filter(a => a.status === filter))

  return (
    <div className="p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-bold text-foreground">Alerts</h1>
        </div>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={handleRefresh}
          disabled={isRefreshing}
          className="text-xs"
        >
          {isRefreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2">
        {(["all", "watching", "triggered", "target_reached", "invalidated"] as FilterStatus[]).map((status) => (
          <button
            key={status}
            onClick={() => setFilter(status)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
              filter === status
                ? "bg-primary text-primary-foreground"
                : "bg-muted text-muted-foreground hover:text-foreground"
            }`}
          >
            {status === "all" ? "All" : 
             status === "watching" ? "Watching" :
             status === "triggered" ? "Triggered" :
             status === "target_reached" ? "Target Hit" : "Invalidated"}
          </button>
        ))}
      </div>

      {/* Alerts List */}
      {isLoading ? (
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-40 rounded-xl bg-card animate-pulse" />
          ))}
        </div>
      ) : displayAlerts.length > 0 ? (
        <div className="space-y-3">
          {displayAlerts.map((alert) => (
            <AlertCard key={alert.id} {...alert} />
          ))}
        </div>
      ) : (
        <div className="text-center py-12">
          <Bell className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <h3 className="text-sm font-semibold text-foreground mb-1">No Alerts</h3>
          <p className="text-xs text-muted-foreground">
            {filter === "all" 
              ? "Alerts will appear here when signals are detected"
              : `No ${filter.replace("_", " ")} alerts`}
          </p>
        </div>
      )}
    </div>
  )
}
