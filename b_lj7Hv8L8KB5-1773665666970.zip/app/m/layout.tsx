"use client"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { AppShell } from "@/components/mobile/app-shell"
import { TopBar } from "@/components/mobile/top-bar"
import { BottomTabs } from "@/components/mobile/bottom-tabs"
import { SplashScreen } from "@/components/mobile/splash-screen"

export default function MobileLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const pathname = usePathname()
  const [showSplash, setShowSplash] = useState(true)
  const [isChecking, setIsChecking] = useState(true)

  useEffect(() => {
    async function checkAuthAndStrategy() {
      try {
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()
        
        if (!user) {
          router.replace("/auth/login")
          return
        }
        
        // Check if user has a strategy (not just profile.wizard_completed)
        const { data: strategy } = await supabase
          .from("strategies")
          .select("id")
          .eq("user_id", user.id)
          .limit(1)
          .single()
        
        // If no strategy exists and not on wizard page, redirect to wizard
        if (!strategy && !pathname?.includes("/m/wizard")) {
          router.replace("/m/wizard")
          return
        }
        
        // If strategy exists and on wizard page, redirect to dashboard
        if (strategy && pathname?.includes("/m/wizard")) {
          router.replace("/m/dashboard")
          return
        }
        
        setIsChecking(false)
      } catch {
        setIsChecking(false)
      }
    }

    if (!showSplash) {
      checkAuthAndStrategy()
    }
  }, [router, pathname, showSplash])

  const handleSplashComplete = () => {
    setShowSplash(false)
  }

  if (showSplash) {
    return <SplashScreen onComplete={handleSplashComplete} duration={1500} />
  }

  if (isChecking) {
    return (
      <AppShell>
        <div className="flex-1 flex items-center justify-center">
          <div className="animate-pulse text-muted-foreground">Loading...</div>
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell>
      <TopBar />
      <main className="flex-1 overflow-y-auto pb-20">
        {children}
      </main>
      <BottomTabs />
    </AppShell>
  )
}
