"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { 
  TrendingUp, 
  TrendingDown, 
  Bell, 
  Compass, 
  LayoutDashboard,
  Activity,
  Target,
  Zap,
  Clock,
  ArrowDownUp,
  Layers
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { STRATEGY_INFO, StrategyKey } from "@/lib/strategies"

const STRATEGY_ICONS: Record<StrategyKey, typeof Zap> = {
  MOMENTUM_BREAKOUT: TrendingUp,
  LIQUIDITY_REVERSAL: ArrowDownUp,
  STRUCTURE_REACTION: Target,
  OPENING_RANGE: Clock,
  VOLATILITY_EXPANSION: Zap,
  SESSION_STRUCTURE: Layers
}

interface UserStrategy {
  id: string
  bundle_name: string
  asset: string
  confidence_score: number
}

export default function HomePage() {
  const [userName, setUserName] = useState("")
  const [strategy, setStrategy] = useState<UserStrategy | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    async function loadData() {
      try {
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()
        
        if (!user) return
        
        // Get profile
        const { data: profile } = await supabase
          .from("profiles")
          .select("name, email")
          .eq("id", user.id)
          .single()
        
        if (profile?.name) {
          setUserName(profile.name.split(' ')[0])
        } else if (profile?.email) {
          setUserName(profile.email.split('@')[0])
        } else if (user.email) {
          setUserName(user.email.split('@')[0])
        }
        
        // Get active strategy
        const { data: strategies } = await supabase
          .from("strategies")
          .select("id, bundle_name, asset, confidence_score")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false })
          .limit(1)
        
        if (strategies && strategies.length > 0) {
          setStrategy(strategies[0])
        }
      } catch {
        // Ignore errors
      } finally {
        setIsLoading(false)
      }
    }

    loadData()
  }, [])

  if (isLoading) {
    return (
      <div className="p-4 space-y-4">
        <div className="h-24 rounded-xl bg-card animate-pulse" />
        <div className="h-40 rounded-xl bg-card animate-pulse" />
      </div>
    )
  }

  const strategyKey = strategy?.bundle_name as StrategyKey
  const strategyInfo = strategyKey ? STRATEGY_INFO[strategyKey] : null
  const StrategyIcon = strategyKey ? STRATEGY_ICONS[strategyKey] : Activity

  return (
    <div className="p-4 space-y-4">
      {/* Welcome Header */}
      <div className="rounded-xl border border-border bg-card p-4">
        <h1 className="text-xl font-bold text-foreground mb-1">
          Welcome back, {userName || "Trader"}
        </h1>
        <p className="text-sm text-muted-foreground">
          Ready to trade with confidence
        </p>
      </div>

      {/* Strategy Status */}
      {strategy ? (
        <div className="rounded-xl border border-primary/30 bg-card p-4 glow-green-sm">
          <div className="flex items-start justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 border border-primary/20">
                <StrategyIcon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-foreground">
                  {strategyInfo?.name || strategy.bundle_name}
                </h3>
                <p className="text-xs text-muted-foreground">{strategy.asset}</p>
              </div>
            </div>
            <span className="rounded-full bg-primary/20 px-2 py-0.5 text-[10px] font-semibold text-primary">
              ACTIVE
            </span>
          </div>
          
          <div className="flex items-center gap-2 mb-3">
            <div className="flex-1 h-2 rounded-full bg-muted overflow-hidden">
              <div 
                className="h-full bg-primary rounded-full"
                style={{ width: `${strategy.confidence_score}%` }}
              />
            </div>
            <span className="text-xs font-semibold text-primary">
              {strategy.confidence_score}% match
            </span>
          </div>
          
          <p className="text-xs text-muted-foreground">
            {strategyInfo?.description || "Custom trading strategy"}
          </p>
        </div>
      ) : (
        <div className="rounded-xl border border-border bg-card p-4">
          <div className="text-center py-4">
            <Compass className="h-10 w-10 text-muted-foreground mx-auto mb-2" />
            <h3 className="text-sm font-semibold text-foreground mb-1">
              No Strategy Active
            </h3>
            <p className="text-xs text-muted-foreground mb-4">
              Complete the wizard to get personalized alerts
            </p>
            <Link href="/m/wizard">
              <Button size="sm" className="w-full">
                Start Wizard
              </Button>
            </Link>
          </div>
        </div>
      )}

      {/* Today's Trade Plan - Static for now */}
      <div className="rounded-xl border border-border bg-card p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold text-foreground">Today&apos;s Trade Plan</h3>
          <span className="rounded-full bg-amber-500/20 px-2 py-0.5 text-[10px] font-semibold text-amber-500">
            WATCHING
          </span>
        </div>
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <p className="text-muted-foreground mb-0.5">Asset</p>
            <p className="font-semibold text-foreground">{strategy?.asset || "BTC"}</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Bias</p>
            <p className="font-semibold text-primary">Bullish intraday</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Setup</p>
            <p className="font-semibold text-foreground">Momentum Breakout</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Entry Zone</p>
            <p className="font-semibold text-foreground">63,250 - 63,420</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Stop</p>
            <p className="font-semibold text-destructive">62,980</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Target 1</p>
            <p className="font-semibold text-primary">63,900</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Target 2</p>
            <p className="font-semibold text-primary">64,300</p>
          </div>
          <div>
            <p className="text-muted-foreground mb-0.5">Status</p>
            <p className="font-semibold text-amber-500">Waiting for trigger</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-3 gap-3">
        <Link href="/m/wizard" className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-card hover:bg-muted/50 transition-colors">
          <Compass className="h-6 w-6 text-primary" />
          <span className="text-xs font-medium text-foreground">Wizard</span>
        </Link>
        <Link href="/m/alerts" className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-card hover:bg-muted/50 transition-colors">
          <Bell className="h-6 w-6 text-primary" />
          <span className="text-xs font-medium text-foreground">Alerts</span>
        </Link>
        <Link href="/m/dashboard" className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border bg-card hover:bg-muted/50 transition-colors">
          <LayoutDashboard className="h-6 w-6 text-primary" />
          <span className="text-xs font-medium text-foreground">Dashboard</span>
        </Link>
      </div>
    </div>
  )
}
