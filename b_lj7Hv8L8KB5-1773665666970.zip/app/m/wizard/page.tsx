"use client"

import { MasterStrategyWizard } from "@/components/master-strategy-wizard"

export default function WizardPage() {
  return (
    <div className="p-4">
      <MasterStrategyWizard mode="create" />
    </div>
  )
}
