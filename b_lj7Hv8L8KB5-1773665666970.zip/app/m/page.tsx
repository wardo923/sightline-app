"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"

export default function MobileRootPage() {
  const router = useRouter()

  useEffect(() => {
    async function redirect() {
      const supabase = createClient()
      const { data: { user } } = await supabase.auth.getUser()
      
      if (!user) {
        router.replace("/auth/login")
        return
      }
      
      // Check if user has a strategy (source of truth)
      const { data: strategy } = await supabase
        .from("strategies")
        .select("id")
        .eq("user_id", user.id)
        .limit(1)
        .single()
      
      if (!strategy) {
        router.replace("/m/wizard")
      } else {
        router.replace("/m/home")
      }
    }

    redirect()
  }, [router])

  return (
    <div className="flex-1 flex items-center justify-center">
      <div className="animate-pulse text-muted-foreground">Redirecting...</div>
    </div>
  )
}
