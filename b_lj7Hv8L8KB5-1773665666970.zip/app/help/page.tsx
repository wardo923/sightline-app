import Link from "next/link"
import { Crosshair, ArrowLeft, Target, ShieldAlert, TrendingUp, Bell, AlertTriangle } from "lucide-react"

export default function HelpCenterPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border px-5 py-4">
        <div className="mx-auto max-w-3xl flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary">
              <Crosshair className="h-4 w-4 text-primary-foreground" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-sm font-bold text-foreground">SightLine</span>
              <span className="text-[9px] font-medium tracking-widest text-primary uppercase">
                Advanced Trading Analytics
              </span>
            </div>
          </Link>
          <Link
            href="/"
            className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            Back to Home
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="px-5 py-12">
        <div className="mx-auto max-w-3xl">
          {/* Page Header */}
          <div className="text-center mb-12">
            <h1 className="text-3xl font-bold text-foreground md:text-4xl">
              SightLine Help Center
            </h1>
            <p className="mt-4 text-lg text-muted-foreground">
              Learn how SightLine works and how to interpret structured trade setups.
            </p>
          </div>

          {/* Section 1: Understanding Trade Setups */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Target className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Understanding Trade Setups</h2>
            </div>

            <div className="space-y-4">
              <HelpCard
                title="Entry"
                description="The price level where a setup becomes active. This is where you would consider entering a trade if conditions are met."
              />
              <HelpCard
                title="Stop Loss"
                description="The level where the setup is invalidated. If price reaches this level, the trade idea is no longer valid and risk should be managed."
              />
              <HelpCard
                title="Targets"
                description="Potential price levels where profits may be taken. These are calculated based on the risk-reward ratio of the setup."
              />
              <HelpCard
                title="Setup Strength"
                description="Indicates how strong the market conditions are for a setup. Ratings include High, Moderate, and Developing based on technical factors."
              />
            </div>
          </section>

          {/* Section 2: What "R" Means */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-foreground">What "R" Means</h2>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <p className="text-muted-foreground mb-4">
                "R" represents the amount of risk in a trade. It&apos;s a standardized way to measure risk and reward.
              </p>

              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4 mb-4">
                <p className="text-sm font-semibold text-foreground mb-2">Example:</p>
                <p className="text-sm text-muted-foreground">
                  <span className="text-primary font-semibold">1R</span> = the amount you risk on a trade
                </p>
                <p className="text-sm text-muted-foreground mt-2">
                  If you risk $100 on a trade:
                </p>
                <ul className="text-sm text-muted-foreground mt-2 space-y-1">
                  <li>• 1R = $100</li>
                  <li>• A trade that gains 2R would produce $200</li>
                  <li>• A trade that loses 1R would lose $100</li>
                </ul>
              </div>

              <p className="text-sm text-muted-foreground">
                This is how many traders measure performance — it standardizes results regardless of position size.
              </p>
            </div>
          </section>

          {/* Section 3: Why Win Rate Isn't Everything */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <ShieldAlert className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Why Win Rate Isn&apos;t Everything</h2>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <p className="text-muted-foreground mb-4">
                Profitable trading often comes from larger winners than losers, not from winning every trade. 
                Many successful strategies win less than 50% of the time.
              </p>

              <div className="rounded-xl border border-primary/20 bg-primary/5 p-4">
                <p className="text-sm font-semibold text-foreground mb-3">Example over 10 trades:</p>
                
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-xs text-muted-foreground">Win Rate</p>
                    <p className="text-lg font-bold text-foreground">45%</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Average Win</p>
                    <p className="text-lg font-bold text-primary">2R</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground">Average Loss</p>
                    <p className="text-lg font-bold text-destructive">1R</p>
                  </div>
                </div>

                <div className="border-t border-border pt-3 space-y-1">
                  <p className="text-sm text-muted-foreground">4 wins x 2R = <span className="text-primary font-semibold">+8R</span></p>
                  <p className="text-sm text-muted-foreground">6 losses x 1R = <span className="text-destructive font-semibold">-6R</span></p>
                  <p className="text-sm font-semibold text-foreground mt-2">Net Result = <span className="text-primary">+2R</span></p>
                </div>
              </div>

              <p className="text-xs text-muted-foreground/60 mt-4">
                Example for educational purposes only. Results will vary.
              </p>
            </div>
          </section>

          {/* Section 4: Alerts */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10">
                <Bell className="h-5 w-5 text-primary" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Alert Types</h2>
            </div>

            <div className="space-y-4">
              <HelpCard
                title="Entry Triggered"
                description="Price has reached the entry level. The setup conditions have been met and the trade idea is now active."
              />
              <HelpCard
                title="Invalidation Alert"
                description="The setup conditions are no longer valid. This typically occurs when price moves against the expected direction and hits the stop level."
              />
              <HelpCard
                title="Target Reached"
                description="Price has reached a target level. This is a potential profit-taking opportunity based on the setup's risk-reward structure."
              />
            </div>
          </section>

          {/* Section 5: Risk Reminder */}
          <section className="mb-12">
            <div className="flex items-center gap-3 mb-6">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/10">
                <AlertTriangle className="h-5 w-5 text-amber-500" />
              </div>
              <h2 className="text-xl font-bold text-foreground">Risk Reminder</h2>
            </div>

            <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-6">
              <p className="text-muted-foreground">
                SightLine provides structured analysis and alerts. Users make their own trading decisions.
              </p>
              <p className="text-sm text-muted-foreground/70 mt-3">
                Trading involves substantial risk of loss. Past performance is not indicative of future results. 
                Never risk more than you can afford to lose.
              </p>
            </div>
          </section>

          {/* CTA */}
          <div className="text-center pt-8 border-t border-border">
            <p className="text-muted-foreground mb-4">Ready to build your trading profile?</p>
            <Link
              href="/get-started"
              className="inline-flex h-12 items-center justify-center gap-2 rounded-xl bg-primary px-6 text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90 glow-green"
            >
              Get Started
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}

function HelpCard({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-4">
      <h3 className="text-sm font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-sm text-muted-foreground">{description}</p>
    </div>
  )
}
