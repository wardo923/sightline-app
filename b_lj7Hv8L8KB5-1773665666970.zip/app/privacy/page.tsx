import { Navbar } from "@/components/navbar"
import Link from "next/link"
import { Crosshair } from "lucide-react"

export const metadata = {
  title: "Privacy Policy - SightLine Advanced Trading Analytics",
  description: "Privacy policy for SightLine Advanced Trading Analytics",
}

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-background">
      <Navbar />
      
      <div className="mx-auto max-w-3xl px-5 py-32">
        <h1 className="text-3xl font-bold text-foreground mb-8">Privacy Policy</h1>
        
        <div className="prose prose-invert prose-sm max-w-none">
          <p className="text-muted-foreground mb-6">
            Last updated: January 2026
          </p>

          {/* Prominent Data Promise */}
          <div className="rounded-xl border border-primary/30 bg-primary/5 p-6 mb-8">
            <h2 className="text-lg font-semibold text-foreground mb-2">We Never Sell Your Data</h2>
            <p className="text-sm text-muted-foreground">
              SightLine does not sell, rent, trade, or share your personal information with third parties for marketing or advertising purposes. Your data is used solely to provide and improve SightLine services. Period.
            </p>
          </div>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Information We Collect</h2>
            <p className="text-muted-foreground mb-4">
              SightLine collects information you provide directly to us, including your name, email address, and trading preferences when you create an account and use our services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">How We Use Your Information</h2>
            <p className="text-muted-foreground mb-4">
              We use the information we collect to:
            </p>
            <ul className="list-disc pl-6 text-muted-foreground space-y-2 mb-4">
              <li>Provide, maintain, and improve our services</li>
              <li>Send you alerts and notifications based on your strategy profile</li>
              <li>Respond to your comments and questions</li>
              <li>Process transactions and send related information</li>
            </ul>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Information Sharing</h2>
            <p className="text-muted-foreground mb-4">
              <strong className="text-foreground">SightLine does not sell, rent, or share personal information with third parties for marketing or advertising purposes.</strong>
            </p>
            <p className="text-muted-foreground mb-4">
              We may share information with service providers who assist us in operating our platform, but only as necessary to provide our services.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Payment Information</h2>
            <p className="text-muted-foreground mb-4">
              Payment information is processed securely by our payment providers and is not stored directly by SightLine. We only receive confirmation of successful transactions.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Data Security</h2>
            <p className="text-muted-foreground mb-4">
              We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction.
            </p>
          </section>

          <section className="mb-8">
            <h2 className="text-xl font-semibold text-foreground mb-4">Contact Us</h2>
            <p className="text-muted-foreground">
              If you have questions about this Privacy Policy, please contact us at privacy@sightline.io
            </p>
          </section>
        </div>

        <div className="mt-12 pt-8 border-t border-border">
          <Link href="/" className="text-sm text-primary hover:underline">
            ← Back to Home
          </Link>
        </div>
      </div>
    </main>
  )
}
