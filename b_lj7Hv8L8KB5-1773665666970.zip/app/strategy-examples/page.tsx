import { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"
import { TrendingUp, TrendingDown, ArrowRight } from "lucide-react"

export const metadata: Metadata = {
  title: "Strategy Examples - SightLine",
  description: "Illustrative examples of how structured setups may appear within the SightLine platform.",
}

const strategyExamples = [
  {
    symbol: "BTC",
    structure: "Breakout",
    keyArea: "Resistance Zone",
    trend: "up",
    description: "Price testing key resistance level with increasing momentum. Breakout structure forming above consolidation range.",
  },
  {
    symbol: "NVDA",
    structure: "Pullback",
    keyArea: "Support Zone",
    trend: "up",
    description: "Healthy pullback into previous resistance turned support. Watching for continuation pattern confirmation.",
  },
  {
    symbol: "ETH",
    structure: "Trend Continuation",
    keyArea: "Structural Support",
    trend: "up",
    description: "Strong trend with higher highs and higher lows. Current pullback finding support at structural level.",
  },
  {
    symbol: "SPY",
    structure: "Range Bound",
    keyArea: "Range Midpoint",
    trend: "neutral",
    description: "Price consolidating within defined range. Watching for breakout or continuation within range boundaries.",
  },
  {
    symbol: "AAPL",
    structure: "Reversal",
    keyArea: "Demand Zone",
    trend: "up",
    description: "Price reaching significant demand zone with potential reversal pattern forming.",
  },
  {
    symbol: "TSLA",
    structure: "Breakdown",
    keyArea: "Support Break",
    trend: "down",
    description: "Key support level broken with increasing volume. Watching for retest of broken support as resistance.",
  },
]

export default function StrategyExamplesPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <p className="mb-4 text-xs font-semibold tracking-widest text-primary uppercase">
            Strategy Examples
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            Illustrative Strategy Examples
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground text-pretty">
            Examples of how structured setups may appear within the SightLine platform.
          </p>
        </div>
      </section>

      {/* Examples Grid */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {strategyExamples.map((example) => (
              <div
                key={example.symbol}
                className="rounded-2xl border border-border/50 bg-card/50 p-6 card-glow transition-all hover:border-primary/30"
              >
                <div className="flex items-center justify-between mb-4">
                  <span className="text-2xl font-bold text-foreground">{example.symbol}</span>
                  <div className={`flex items-center gap-1 rounded-lg px-3 py-1 text-xs font-semibold ${
                    example.trend === "up" 
                      ? "bg-primary/10 text-primary" 
                      : example.trend === "down"
                      ? "bg-destructive/10 text-destructive"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {example.trend === "up" ? (
                      <TrendingUp className="h-3 w-3" />
                    ) : example.trend === "down" ? (
                      <TrendingDown className="h-3 w-3" />
                    ) : null}
                    {example.structure}
                  </div>
                </div>
                
                <div className="space-y-3 mb-4">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Structure:</span>
                    <span className="font-medium text-foreground">{example.structure}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Key Area:</span>
                    <span className="font-medium text-primary">{example.keyArea}</span>
                  </div>
                </div>
                
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {example.description}
                </p>
              </div>
            ))}
          </div>

          <p className="mt-12 text-center text-xs text-muted-foreground/70">
            Examples shown for illustrative purposes only. These do not represent actual trade recommendations or guaranteed outcomes.
          </p>
        </div>
      </section>

      {/* How Setups Are Identified */}
      <section className="section-glow-top grid-bg py-20 md:py-28">
        <div className="mx-auto max-w-4xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              How Setups Are Identified
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground text-pretty">
              SightLine analyzes market structure to identify setups that align with your strategy framework.
            </p>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">1</div>
                <h3 className="text-lg font-semibold text-foreground">Market Structure Analysis</h3>
              </div>
              <p className="text-sm text-muted-foreground ml-11">
                Price action, volume, and structural levels are continuously analyzed to determine market context.
              </p>
            </div>
            
            <div className="flex justify-center">
              <ArrowRight className="h-5 w-5 text-primary/50 rotate-90" />
            </div>
            
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">2</div>
                <h3 className="text-lg font-semibold text-foreground">Framework Matching</h3>
              </div>
              <p className="text-sm text-muted-foreground ml-11">
                Market conditions are compared against your personalized strategy framework preferences.
              </p>
            </div>
            
            <div className="flex justify-center">
              <ArrowRight className="h-5 w-5 text-primary/50 rotate-90" />
            </div>
            
            <div className="rounded-xl border border-border bg-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center text-primary font-bold text-sm">3</div>
                <h3 className="text-lg font-semibold text-foreground">Setup Highlight</h3>
              </div>
              <p className="text-sm text-muted-foreground ml-11">
                When conditions align, the setup is highlighted with defined risk parameters for your review.
              </p>
            </div>
          </div>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
