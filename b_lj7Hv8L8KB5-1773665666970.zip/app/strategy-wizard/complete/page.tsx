"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Loader2, Check, AlertTriangle } from "lucide-react"
import { mapToMatrixAnswers, generateStrategyData, type WizardAnswers } from "@/lib/wizard-config"
import { scoreAnswers } from "@/lib/strategy-matrix"
import { calculateConfidence } from "@/lib/strategy-confidence"
import { STRATEGY_INFO } from "@/lib/strategies"

export default function StrategyWizardCompletePage() {
  const router = useRouter()
  const [status, setStatus] = useState<"loading" | "saving" | "success" | "error">("loading")
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    async function completeWizard() {
      try {
        // Get stored wizard data
        const answersJson = sessionStorage.getItem("wizard_answers")
        const mode = sessionStorage.getItem("wizard_mode") || "create"
        const strategyId = sessionStorage.getItem("wizard_strategy_id")

        if (!answersJson) {
          // No wizard data - redirect to wizard
          router.replace("/strategy-wizard")
          return
        }

        const answers: WizardAnswers = JSON.parse(answersJson)

        // Check if user is logged in
        const supabase = createClient()
        const { data: { user } } = await supabase.auth.getUser()

        if (!user) {
          // Not logged in - redirect to sign-up
          router.replace("/auth/sign-up?redirect=/strategy-wizard/complete")
          return
        }

        setStatus("saving")

        // ==================================================================
        // STRATEGY MATRIX INTEGRATION
        // Convert user-facing wizard answers to matrix format and score
        // ==================================================================
        console.log("[v0] Complete page - Starting strategy save for user:", user.id)
        
        const matrixAnswers = mapToMatrixAnswers(answers)
        const scores = scoreAnswers(matrixAnswers)
        const confidenceData = calculateConfidence(scores)
        
        console.log("[v0] Matrix results:", { 
          topStrategy: confidenceData.topStrategy, 
          confidence: confidenceData.confidence 
        })
        
        // Get strategy info for naming
        const strategyInfo = STRATEGY_INFO[confidenceData.topStrategy]
        const assetFocus = Array.isArray(answers.assetFocus) ? answers.assetFocus : []
        const primaryAsset = assetFocus[0] || "SPY"
        const strategyName = `${primaryAsset} ${strategyInfo?.shortName || "Strategy"}`

        // Build payload matching actual database schema
        const strategyPayload = {
          user_id: user.id,
          name: strategyName,
          markets: assetFocus,
          trading_style: String(answers.tradingPace || "balanced"),
          timeframe: answers.tradeDuration === "fast" ? "5m" : answers.tradeDuration === "swing" ? "1H" : "15m",
          time_of_day: "All Day",
          setup_preference: String(answers.marketBehavior || "momentum"),
          confirmation_style: answers.signalStrictness === "conservative" ? "Strict" : answers.signalStrictness === "expanded" ? "Flexible" : "Moderate",
          alert_style: Array.isArray(answers.alertDelivery) ? answers.alertDelivery.join(", ") : "dashboard",
          signal_frequency: String(answers.signalFrequency || "balanced"),
          bundle_name: confidenceData.topStrategy,
          market_type: answers.marketCoverage === "crypto" ? "crypto" : "index_etf",
          asset: primaryAsset,
          secondary_bundle: confidenceData.secondStrategy || null,
          confidence_score: confidenceData.confidence,
          wizard_answers: {
            ...answers,
            _matrixBundle: confidenceData.topStrategy,
            _matrixSecondary: confidenceData.secondStrategy,
            _matrixConfidence: confidenceData.confidence,
            _matrixScores: scores,
          },
          updated_at: new Date().toISOString(),
        }

        console.log("[v0] Strategy payload:", strategyPayload)

        // Save strategy with real matrix data
        if (mode === "edit" && strategyId) {
          console.log("[v0] Updating existing strategy:", strategyId)
          const { error: updateError } = await supabase
            .from("strategies")
            .update(strategyPayload)
            .eq("id", strategyId)
            .eq("user_id", user.id)

          if (updateError) {
            console.error("[v0] Strategy update error:", updateError)
            throw updateError
          }
        } else {
          console.log("[v0] Inserting new strategy")
          const { data: insertData, error: insertError } = await supabase
            .from("strategies")
            .insert(strategyPayload)
            .select()
            .single()

          if (insertError) {
            console.error("[v0] Strategy insert error:", insertError)
            throw insertError
          }
          console.log("[v0] Strategy inserted:", insertData?.id)
        }

        // Update profile wizard_completed = true
        console.log("[v0] Updating profile wizard_completed")
        const { error: profileError } = await supabase
          .from("profiles")
          .upsert({
            id: user.id,
            wizard_completed: true,
            updated_at: new Date().toISOString(),
          })

        if (profileError) {
          console.error("[v0] Profile update error:", profileError)
          throw profileError
        }

        // Verify wizard_completed is set
        const { data: updatedProfile, error: verifyError } = await supabase
          .from("profiles")
          .select("wizard_completed")
          .eq("id", user.id)
          .single()

        console.log("[v0] Profile verification:", { updatedProfile, verifyError })

        if (!updatedProfile?.wizard_completed) {
          throw new Error("Failed to complete wizard - verification failed")
        }

        // Clear session storage
        sessionStorage.removeItem("wizard_answers")
        sessionStorage.removeItem("wizard_mode")
        sessionStorage.removeItem("wizard_strategy_id")

        setStatus("success")

        // Redirect to dashboard after 2 seconds
        // Check if originally from mobile app context
        const fromMobile = sessionStorage.getItem("wizard_from_mobile") === "true"
        sessionStorage.removeItem("wizard_from_mobile")
        setTimeout(() => {
          router.replace(fromMobile ? "/m/dashboard" : "/dashboard")
        }, 2000)
      } catch (err) {
        console.error("Error completing wizard:", err)
        setError(err instanceof Error ? err.message : "Failed to save strategy")
        setStatus("error")
      }
    }

    completeWizard()
  }, [router])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-[#0a0a0a] text-white px-4">
      <div className="text-center space-y-4 max-w-sm">
        {status === "loading" && (
          <>
            <Loader2 className="h-12 w-12 animate-spin text-[#2bd673] mx-auto" />
            <h1 className="text-xl font-semibold">Loading...</h1>
          </>
        )}

        {status === "saving" && (
          <>
            <Loader2 className="h-12 w-12 animate-spin text-[#2bd673] mx-auto" />
            <h1 className="text-xl font-semibold">Saving Your Strategy</h1>
            <p className="text-sm text-[#888]">Please wait while we configure your monitoring profile...</p>
          </>
        )}

        {status === "success" && (
          <>
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-[#2bd673]/10">
              <Check className="h-10 w-10 text-[#2bd673]" />
            </div>
            <h1 className="text-2xl font-semibold">Strategy Profile Created</h1>
            <p className="text-sm text-[#888]">
              Your strategy profile is now active. SightLine will monitor markets based on your preferences.
            </p>
            <div className="pt-4">
              <Loader2 className="h-5 w-5 animate-spin text-[#2bd673] mx-auto" />
              <p className="text-xs text-[#666] mt-2">Redirecting to dashboard...</p>
            </div>
          </>
        )}

        {status === "error" && (
          <>
            <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-red-500/10">
              <AlertTriangle className="h-10 w-10 text-red-500" />
            </div>
            <h1 className="text-xl font-semibold">Something Went Wrong</h1>
            <p className="text-sm text-[#888]">{error || "Failed to save your strategy. Please try again."}</p>
            <button
              onClick={() => router.push("/strategy-wizard")}
              className="mt-4 rounded-xl bg-[#2bd673] px-6 py-3 text-sm font-semibold text-black"
            >
              Try Again
            </button>
          </>
        )}
      </div>
    </div>
  )
}
