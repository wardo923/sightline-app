import { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"
import { Wand2, BarChart3, Target, Activity, Bell, Mail, Smartphone, ArrowDown, Database, Cpu, AlertCircle, Shield } from "lucide-react"

export const metadata: Metadata = {
  title: "Technology - The SAT Engine | SightLine",
  description: "Learn how the SightLine Analytical Trading Engine evaluates market structure and highlights patterns aligned with your trading profile.",
}

const coreCapabilities = [
  {
    icon: BarChart3,
    title: "Market Structure Analysis",
    description: "Evaluate trend direction and price behavior across supported markets.",
  },
  {
    icon: Target,
    title: "Structural Zone Identification",
    description: "Identify support and resistance areas through pattern recognition.",
  },
  {
    icon: Wand2,
    title: "Trading Profile Mapping",
    description: "Align market conditions with user preferences and risk parameters.",
  },
  {
    icon: Activity,
    title: "Monitoring System",
    description: "Track evolving structures across supported markets in real-time.",
  },
]

const alertChannels = [
  { icon: Bell, label: "Dashboard Notifications" },
  { icon: Mail, label: "Email Updates" },
  { icon: Smartphone, label: "Mobile Notifications" },
]

const architectureFlow = [
  { label: "Market Data", sublabel: "Crypto | Stocks | Indices | Futures", icon: Database },
  { label: "SAT Engine", sublabel: "SightLine Analytical Trading Engine", icon: Cpu },
  { label: "User Trading Profile", sublabel: null, icon: Wand2 },
  { label: "Market Structure Analysis", sublabel: null, icon: BarChart3 },
  { label: "Pattern Monitoring", sublabel: null, icon: Target },
  { label: "Alert Delivery", sublabel: null, icon: AlertCircle },
]

export default function TechnologyPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <p className="mb-4 text-xs font-semibold tracking-widest text-primary uppercase">
            Technology
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            The SAT Engine
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground text-pretty">
            The SightLine Analytical Trading Engine evaluates market structure across supported markets and highlights relevant patterns.
          </p>
        </div>
      </section>

      {/* Core Capabilities */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl">
              Core Capabilities
            </h2>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2">
            {coreCapabilities.map((feature) => (
              <div
                key={feature.title}
                className="rounded-2xl border border-border/50 bg-card/50 p-6 card-glow transition-all hover:border-primary/30"
              >
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
                  <feature.icon className="h-6 w-6" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>

          {/* Alert Channels */}
          <div className="mt-12 rounded-2xl border border-border/50 bg-card/30 p-6">
            <h3 className="text-sm font-semibold text-foreground mb-4 text-center uppercase tracking-wider">
              Alert Channels
            </h3>
            <div className="flex flex-wrap justify-center gap-4">
              {alertChannels.map((channel) => (
                <div
                  key={channel.label}
                  className="flex items-center gap-2 rounded-xl bg-background/60 px-5 py-3 border border-border"
                >
                  <channel.icon className="h-4 w-4 text-primary" />
                  <span className="text-sm font-medium text-foreground">{channel.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Risk-First Analysis */}
      <section className="py-16 md:py-24 bg-card/20">
        <div className="mx-auto max-w-4xl px-4 md:px-6 text-center">
          <div className="inline-flex items-center justify-center h-14 w-14 rounded-xl bg-primary/10 text-primary mb-6">
            <Shield className="h-7 w-7" />
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-foreground md:text-3xl mb-4">
            Risk-First Analysis
          </h2>
          <p className="text-base text-muted-foreground max-w-2xl mx-auto">
            SightLine emphasizes understanding downside risk before evaluating potential opportunities. Every setup includes defined risk parameters.
          </p>
        </div>
      </section>

      {/* Platform Architecture */}
      <section className="section-glow-top grid-bg py-20 md:py-28">
        <div className="mx-auto max-w-4xl px-4 md:px-6">
          <div className="text-center mb-12">
            <p className="mb-3 text-xs font-semibold tracking-widest text-primary uppercase">
              Architecture
            </p>
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              SightLine Platform Architecture
            </h2>
            <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground text-pretty">
              SightLine combines market structure analysis, trading profiles, and risk modeling.
            </p>
          </div>

          {/* Flow Diagram */}
          <div className="flex flex-col items-center gap-3">
            {architectureFlow.map((step, idx) => (
              <div key={step.label} className="w-full max-w-md">
                <div className="rounded-xl border border-border bg-card p-4 text-center">
                  <div className="flex items-center justify-center gap-3">
                    <step.icon className="h-5 w-5 text-primary" />
                    <span className="text-sm font-semibold text-foreground">{step.label}</span>
                  </div>
                  {step.sublabel && (
                    <p className="mt-1 text-xs text-muted-foreground">{step.sublabel}</p>
                  )}
                </div>
                {idx < architectureFlow.length - 1 && (
                  <div className="flex justify-center py-1.5">
                    <ArrowDown className="h-4 w-4 text-primary/50" />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Alert delivery expansion */}
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            {alertChannels.map((channel) => (
              <div
                key={channel.label}
                className="flex items-center gap-2 rounded-lg bg-primary/10 px-3 py-1.5 border border-primary/20"
              >
                <channel.icon className="h-3 w-3 text-primary" />
                <span className="text-xs text-primary">{channel.label}</span>
              </div>
            ))}
          </div>

          <p className="mt-12 text-center text-sm text-muted-foreground">
            SightLine focuses on structured market analysis rather than prediction-based trading signals.
          </p>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
