import { Metadata } from "next"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"
import { AlertTriangle } from "lucide-react"

export const metadata: Metadata = {
  title: "Risk Disclosure - SightLine",
  description: "Important risk disclosure information for SightLine users.",
}

export default function RiskDisclosurePage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl bg-amber-500/10">
            <AlertTriangle className="h-8 w-8 text-amber-500" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            Risk Disclosure
          </h1>
        </div>
      </section>

      {/* Content */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-4 md:px-6">
          <div className="rounded-2xl border border-amber-500/30 bg-amber-500/5 p-8 mb-12">
            <p className="text-lg font-semibold text-foreground mb-4">
              Trading financial markets involves substantial risk of loss and may not be suitable for all investors.
            </p>
            <p className="text-base text-muted-foreground">
              Please read this entire risk disclosure carefully before using SightLine.
            </p>
          </div>

          <div className="space-y-6">
            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Platform Purpose</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                SightLine provides analytical tools designed to assist users in evaluating market structure and potential setups. The platform does not provide investment advice or trading recommendations.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Not Financial Advice</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                SightLine is not a broker, investment advisor, or financial advisor. The platform does not provide investment advice, trading advice, or recommendations to buy, sell, or hold any financial instrument. All content is provided for informational and educational purposes only.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Trading Risk</h2>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Trading involves substantial risk of loss and past performance does not guarantee future results. You could lose some or all of your invested capital.
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Users should only trade with capital they can afford to lose completely.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">User Responsibility</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Users remain solely responsible for their trading decisions and outcomes. SightLine does not guarantee any specific results or outcomes from using the platform.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Hypothetical Examples</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Any setup examples or scenario illustrations displayed on this platform are hypothetical and provided solely to demonstrate how structured risk parameters or market analysis may be presented. They do not represent actual trading performance or guaranteed outcomes.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">No Broker Connection</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                SightLine does not connect to brokerage accounts and does not execute trades. Users maintain full control of their own trading accounts and are responsible for all trading activity.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Market Risk</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Financial markets are subject to various risks including but not limited to market volatility, liquidity risk, and systematic risk. Past market behavior is not indicative of future performance.
              </p>
            </div>

            <div className="rounded-xl border border-border bg-card p-6">
              <h2 className="text-lg font-semibold text-foreground mb-4">Seek Professional Advice</h2>
              <p className="text-sm text-muted-foreground leading-relaxed">
                Before making any investment decisions, you should consult with a qualified financial advisor who can assess your individual circumstances, risk tolerance, and financial goals.
              </p>
            </div>
          </div>

          <div className="mt-12 rounded-xl border border-border bg-muted/30 p-6 text-center">
            <p className="text-xs text-muted-foreground">
              By using SightLine, you acknowledge that you have read, understood, and agree to this risk disclosure.
            </p>
          </div>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
