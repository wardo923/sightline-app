import { Metadata } from "next"
import Link from "next/link"
import { Navbar } from "@/components/navbar"
import { CtaFooter } from "@/components/cta-footer"
import { Check } from "lucide-react"

export const metadata: Metadata = {
  title: "Pricing - SightLine",
  description: "Simple, transparent pricing with no hidden fees. All plans include structured setup monitoring and market analysis tools.",
}

const plans = [
  {
    name: "Starter",
    price: "$19.99",
    period: "/mo",
    description: "For learning traders",
    features: [
      "1 strategy profile",
      "Market structure alerts",
      "Entry / stop / target",
      "Email alerts",
    ],
    popular: false,
    freeTrial: true,
  },
  {
    name: "Pro",
    price: "$29.99",
    period: "/mo",
    description: "For developing traders",
    features: [
      "Up to 3 strategy profiles",
      "Email + Telegram alerts",
      "Strategy monitoring",
      "Dashboard analytics",
    ],
    popular: false,
    freeTrial: true,
  },
  {
    name: "Elite",
    price: "$39.99",
    period: "/mo",
    description: "Full alert suite for serious traders",
    features: [
      "Unlimited strategy profiles",
      "Full alert suite",
      "Advanced setup confirmations",
      "Priority alerts",
      "Daily market brief",
    ],
    popular: true,
    freeTrial: true,
  },
]

export default function PricingPage() {
  return (
    <main className="min-h-screen">
      <Navbar />
      
      {/* Hero */}
      <section className="relative pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="absolute inset-0 bg-background" />
        <div className="absolute inset-0 grid-bg-hero" />
        
        <div className="relative mx-auto max-w-4xl px-4 md:px-6 text-center">
          <p className="mb-4 text-xs font-semibold tracking-widest text-primary uppercase">
            Pricing
          </p>
          <h1 className="text-4xl font-bold tracking-tight text-foreground md:text-6xl text-balance">
            Transparent Pricing
          </h1>
          <p className="mx-auto mt-6 max-w-xl text-lg text-muted-foreground text-pretty">
            Simple plans with no hidden fees.
          </p>
          <p className="mx-auto mt-4 max-w-xl text-base text-muted-foreground">
            All plans include structured setup monitoring and market analysis tools.
          </p>
        </div>
      </section>

      {/* Pricing Cards */}
      <section className="py-20 md:py-28">
        <div className="mx-auto max-w-6xl px-4 md:px-6">
          <div className="grid gap-6 md:grid-cols-3">
            {plans.map((plan) => (
              <div
                key={plan.name}
                className={`card-glow relative flex flex-col rounded-2xl border p-8 md:p-9 transition-all ${
                  plan.popular
                    ? "border-primary/30 bg-primary/[0.03] glow-green-sm"
                    : "border-border bg-card"
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 right-6 rounded-full bg-primary px-4 py-1 text-[11px] font-bold tracking-wide text-primary-foreground uppercase">
                    Most Popular
                  </div>
                )}

                <h3 className="text-xl font-bold text-foreground">{plan.name}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>

                <div className="mt-7 flex items-baseline gap-1">
                  <span className="text-5xl font-extrabold tracking-tight text-foreground">
                    {plan.price}
                  </span>
                  <span className="text-sm font-medium text-muted-foreground">{plan.period}</span>
                </div>

                <div className="my-8 h-px bg-border" />

                <ul className="flex flex-col gap-4">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-center gap-3 text-sm text-muted-foreground">
                      <Check className={`h-4 w-4 shrink-0 ${plan.popular ? "text-primary" : "text-success"}`} />
                      {feature}
                    </li>
                  ))}
                </ul>

                <div className="mt-auto pt-9">
                  <Link
                    href="/strategy-wizard"
                    className={`flex h-12 items-center justify-center rounded-xl text-sm font-semibold transition-all ${
                      plan.popular
                        ? "bg-primary text-primary-foreground hover:bg-primary/90 glow-green-sm"
                        : "border border-border bg-secondary text-secondary-foreground hover:border-primary/30 hover:text-primary"
                    }`}
                  >
                    Unlock My Strategy
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <p className="mt-12 text-center text-sm text-muted-foreground">
            Starter plan includes a 3-day free trial. No credit card required.
          </p>
        </div>
      </section>

      {/* FAQ Preview */}
      <section className="section-glow-top grid-bg py-20 md:py-28">
        <div className="mx-auto max-w-3xl px-4 md:px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold tracking-tight text-foreground md:text-4xl text-balance">
              Common Questions
            </h2>
          </div>

          <div className="space-y-4">
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-base font-semibold text-foreground mb-2">Can I cancel anytime?</h3>
              <p className="text-sm text-muted-foreground">
                Yes. All plans are month-to-month with no long-term commitment. Cancel anytime from your account settings.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-base font-semibold text-foreground mb-2">What payment methods do you accept?</h3>
              <p className="text-sm text-muted-foreground">
                We accept all major credit cards through our secure payment processor.
              </p>
            </div>
            <div className="rounded-xl border border-border bg-card p-6">
              <h3 className="text-base font-semibold text-foreground mb-2">Can I upgrade or downgrade my plan?</h3>
              <p className="text-sm text-muted-foreground">
                Yes. You can change your plan at any time. Changes take effect at the start of your next billing cycle.
              </p>
            </div>
          </div>

          <div className="mt-8 text-center">
            <Link href="/faq" className="text-sm font-medium text-primary hover:underline">
              View all FAQs
            </Link>
          </div>
        </div>
      </section>

      <CtaFooter />
    </main>
  )
}
