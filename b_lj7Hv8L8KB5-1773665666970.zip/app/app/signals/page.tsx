import { Metadata } from "next"
import Link from "next/link"
import { Target, ChevronRight } from "lucide-react"

export const metadata: Metadata = {
  title: "Signals - SightLine",
  description: "Current active trade signals",
}

const signals = [
  {
    id: "btc-15m-1",
    asset: "BTC",
    timeframe: "15m",
    direction: "BUY",
    probability: 84,
    entry: "64,200",
    stop: "63,700",
    target: "65,300",
    grade: "A",
  },
  {
    id: "sol-1h-1",
    asset: "SOL",
    timeframe: "1h",
    direction: "BUY",
    probability: 72,
    entry: "142.50",
    stop: "138.20",
    target: "152.00",
    grade: "B+",
  },
  {
    id: "eth-4h-1",
    asset: "ETH",
    timeframe: "4h",
    direction: "BUY",
    probability: 68,
    entry: "3,420",
    stop: "3,320",
    target: "3,580",
    grade: "B",
  },
  {
    id: "nvda-1d-1",
    asset: "NVDA",
    timeframe: "1d",
    direction: "SELL",
    probability: 65,
    entry: "892.50",
    stop: "915.00",
    target: "845.00",
    grade: "B",
  },
  {
    id: "spy-1h-1",
    asset: "SPY",
    timeframe: "1h",
    direction: "BUY",
    probability: 58,
    entry: "512.40",
    stop: "509.80",
    target: "517.20",
    grade: "C+",
  },
]

export default function SignalsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="mx-auto max-w-7xl px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <Target className="h-4 w-4 text-primary" />
                </div>
                <span className="text-lg font-bold text-foreground">SightLine</span>
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm text-muted-foreground">Signals</span>
            </div>
            <nav className="flex items-center gap-6">
              <Link href="/app/mission" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Mission
              </Link>
              <Link href="/app/radar" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Radar
              </Link>
              <Link href="/app/strategy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Strategy
              </Link>
              <Link href="/app/performance" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Performance
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-5 py-8">
        {/* Page title */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">Active Signals</h1>
          <p className="mt-1 text-sm text-muted-foreground">{signals.length} signals currently active</p>
        </div>

        {/* Signals list */}
        <div className="space-y-4">
          {signals.map((signal) => (
            <Link
              key={signal.id}
              href={`/app/signal/${signal.id}`}
              className="flex items-center justify-between rounded-2xl border border-border bg-card p-5 transition-all hover:border-primary/30"
            >
              <div className="flex items-center gap-5">
                {/* Asset & Direction */}
                <div className="min-w-[80px]">
                  <div className="flex items-center gap-2">
                    <span className="text-lg font-bold text-foreground">{signal.asset}</span>
                    <span className="text-xs text-muted-foreground">/ {signal.timeframe}</span>
                  </div>
                  <span className={`mt-1 inline-block rounded px-2 py-0.5 text-xs font-semibold ${
                    signal.direction === "BUY" 
                      ? "bg-primary/20 text-primary" 
                      : "bg-destructive/20 text-destructive"
                  }`}>
                    {signal.direction}
                  </span>
                </div>

                {/* Probability */}
                <div className="hidden sm:block">
                  <span className="text-xs text-muted-foreground">Probability</span>
                  <p className="text-lg font-bold text-primary">{signal.probability}%</p>
                </div>

                {/* Entry / Stop / Target */}
                <div className="hidden md:flex gap-6">
                  <div>
                    <span className="text-xs text-muted-foreground">Entry</span>
                    <p className="text-sm font-semibold text-foreground">{signal.entry}</p>
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground">Stop</span>
                    <p className="text-sm font-semibold text-destructive">{signal.stop}</p>
                  </div>
                  <div>
                    <span className="text-xs text-muted-foreground">Target</span>
                    <p className="text-sm font-semibold text-primary">{signal.target}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4">
                {/* Grade */}
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg font-bold ${
                  signal.grade.startsWith("A") 
                    ? "bg-primary/20 text-primary" 
                    : signal.grade.startsWith("B")
                    ? "bg-primary/10 text-primary/80"
                    : "bg-muted text-muted-foreground"
                }`}>
                  {signal.grade}
                </div>
                <ChevronRight className="h-5 w-5 text-muted-foreground" />
              </div>
            </Link>
          ))}
        </div>
      </main>
    </div>
  )
}
