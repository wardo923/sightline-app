import { Metadata } from "next"
import Link from "next/link"
import { 
  TrendingUp, 
  Bell, 
  Activity, 
  BarChart3, 
  ArrowUpRight,
  ChevronRight,
  Gauge,
  Target
} from "lucide-react"

export const metadata: Metadata = {
  title: "Mission Control - SightLine",
  description: "Your daily trading command center",
}

const opportunities = [
  { asset: "BTC", status: "Breakout forming", strength: "strong", direction: "up" },
  { asset: "SOL", status: "Pullback forming", strength: "forming", direction: "up" },
  { asset: "NVDA", status: "Momentum building", strength: "forming", direction: "up" },
  { asset: "SPY", status: "Neutral", strength: "neutral", direction: "neutral" },
]

const activeSignals = [
  {
    id: "btc-15m-1",
    asset: "BTC",
    timeframe: "15m",
    direction: "BUY",
    probability: 84,
    entry: "64,200",
    stop: "63,700",
    target: "65,300",
    expectedPath: "dip → consolidation → breakout",
    pressure: 82,
    riskSteps: { current: 5, max: 25 },
  },
  {
    id: "sol-1h-1",
    asset: "SOL",
    timeframe: "1h",
    direction: "BUY",
    probability: 72,
    entry: "142.50",
    stop: "138.20",
    target: "152.00",
    expectedPath: "range → breakout",
    pressure: 68,
    riskSteps: { current: 8, max: 25 },
  },
]

const strategyPerformance = {
  name: "Crypto Breakout",
  trades: 128,
  winRate: 61,
  avgWin: "+2.1R",
  avgLoss: "-1R",
}

export default function MissionControlPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="mx-auto max-w-7xl px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <Target className="h-4 w-4 text-primary" />
                </div>
                <span className="text-lg font-bold text-foreground">SightLine</span>
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm text-muted-foreground">Mission Control</span>
            </div>
            <nav className="flex items-center gap-6">
              <Link href="/app/radar" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Radar
              </Link>
              <Link href="/app/signals" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Signals
              </Link>
              <Link href="/app/strategy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Strategy
              </Link>
              <Link href="/app/performance" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Performance
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 py-8">
        {/* Page title */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">Mission Control</h1>
          <p className="mt-1 text-sm text-muted-foreground">Your daily trading command center</p>
        </div>

        {/* Dashboard grid */}
        <div className="grid gap-5 lg:grid-cols-3">
          {/* Left column */}
          <div className="space-y-5">
            {/* Top Opportunities */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  <h2 className="text-sm font-semibold text-foreground">Top Opportunities</h2>
                </div>
                <Link href="/app/radar" className="text-xs text-primary hover:underline">
                  View all
                </Link>
              </div>
              <div className="space-y-3">
                {opportunities.map((opp) => (
                  <div key={opp.asset} className="flex items-center justify-between rounded-lg bg-secondary/50 p-3">
                    <div className="flex items-center gap-3">
                      <span className="text-sm font-semibold text-foreground">{opp.asset}</span>
                      {opp.direction === "up" && (
                        <ArrowUpRight className="h-3 w-3 text-primary" />
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">{opp.status}</span>
                      <span className={`h-2 w-2 rounded-full ${
                        opp.strength === "strong" ? "bg-primary" : 
                        opp.strength === "forming" ? "bg-primary/50" : "bg-muted"
                      }`} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Conditions */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center gap-2">
                <Activity className="h-4 w-4 text-primary" />
                <h2 className="text-sm font-semibold text-foreground">Market Conditions</h2>
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Market trend</span>
                  <span className="text-sm font-semibold text-primary">Bullish</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Volatility</span>
                  <span className="text-sm font-semibold text-foreground">Medium</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Best strategy today</span>
                  <span className="text-sm font-semibold text-foreground">Breakouts</span>
                </div>
              </div>
            </div>

            {/* Strategy Performance */}
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="mb-4 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4 text-primary" />
                  <h2 className="text-sm font-semibold text-foreground">Strategy Performance</h2>
                </div>
                <Link href="/app/performance" className="text-xs text-primary hover:underline">
                  Details
                </Link>
              </div>
              <div className="mb-3">
                <span className="text-lg font-bold text-foreground">{strategyPerformance.name}</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-xs text-muted-foreground">Trades</span>
                  <p className="text-sm font-semibold text-foreground">{strategyPerformance.trades}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Win rate</span>
                  <p className="text-sm font-semibold text-primary">{strategyPerformance.winRate}%</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Avg win</span>
                  <p className="text-sm font-semibold text-primary">{strategyPerformance.avgWin}</p>
                </div>
                <div>
                  <span className="text-xs text-muted-foreground">Avg loss</span>
                  <p className="text-sm font-semibold text-destructive">{strategyPerformance.avgLoss}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right column - Active Signals */}
          <div className="lg:col-span-2">
            <div className="rounded-2xl border border-border bg-card p-5">
              <div className="mb-5 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Bell className="h-4 w-4 text-primary" />
                  <h2 className="text-sm font-semibold text-foreground">Active Signals</h2>
                </div>
                <Link href="/app/signals" className="text-xs text-primary hover:underline">
                  View all signals
                </Link>
              </div>

              <div className="space-y-4">
                {activeSignals.map((signal) => (
                  <Link 
                    key={signal.id}
                    href={`/app/signal/${signal.id}`}
                    className="block rounded-xl border border-border bg-secondary/30 p-5 transition-all hover:border-primary/30"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xl font-bold text-foreground">{signal.asset}</span>
                          <span className="text-sm text-muted-foreground">/ {signal.timeframe}</span>
                        </div>
                        <span className={`mt-1 inline-block rounded px-2 py-0.5 text-xs font-semibold ${
                          signal.direction === "BUY" 
                            ? "bg-primary/20 text-primary" 
                            : "bg-destructive/20 text-destructive"
                        }`}>
                          {signal.direction}
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="text-3xl font-bold text-primary">{signal.probability}%</div>
                        <span className="text-xs text-muted-foreground">Probability</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div>
                        <span className="text-xs text-muted-foreground">Entry</span>
                        <p className="text-sm font-semibold text-foreground">{signal.entry}</p>
                      </div>
                      <div>
                        <span className="text-xs text-muted-foreground">Stop</span>
                        <p className="text-sm font-semibold text-destructive">{signal.stop}</p>
                      </div>
                      <div>
                        <span className="text-xs text-muted-foreground">Target</span>
                        <p className="text-sm font-semibold text-primary">{signal.target}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between border-t border-border/50 pt-4">
                      <div className="flex items-center gap-6">
                        <div>
                          <span className="text-xs text-muted-foreground">Expected Path</span>
                          <p className="text-xs font-medium text-foreground">{signal.expectedPath}</p>
                        </div>
                        <div>
                          <span className="text-xs text-muted-foreground">Pressure</span>
                          <div className="flex items-center gap-2">
                            <div className="h-1.5 w-16 rounded-full bg-border">
                              <div 
                                className="h-full rounded-full bg-primary" 
                                style={{ width: `${signal.pressure}%` }} 
                              />
                            </div>
                            <span className="text-xs font-medium text-foreground">{signal.pressure}%</span>
                          </div>
                        </div>
                        <div>
                          <span className="text-xs text-muted-foreground">Risk Steps</span>
                          <p className="text-xs font-medium text-foreground">{signal.riskSteps.current} / {signal.riskSteps.max}</p>
                        </div>
                      </div>
                      <ChevronRight className="h-4 w-4 text-muted-foreground" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
