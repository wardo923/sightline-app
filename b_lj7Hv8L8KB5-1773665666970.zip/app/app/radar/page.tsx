"use client"

import { useState } from "react"
import Link from "next/link"
import { Target, ArrowUpRight } from "lucide-react"

const radarTargets = [
  { id: "btc-15m-1", asset: "BTC", strength: 95, status: "strong", angle: 30, distance: 15 },
  { id: "eth-1h-1", asset: "ETH", strength: 70, status: "forming", angle: 120, distance: 35 },
  { id: "sol-15m-1", asset: "SOL", strength: 65, status: "forming", angle: 200, distance: 40 },
  { id: "nvda-1h-1", asset: "NVDA", strength: 60, status: "forming", angle: 280, distance: 45 },
  { id: "spy-4h-1", asset: "SPY", strength: 40, status: "weak", angle: 350, distance: 65 },
  { id: "qqq-1d-1", asset: "QQQ", strength: 35, status: "weak", angle: 80, distance: 70 },
]

export default function RadarPage() {
  const [selectedTarget, setSelectedTarget] = useState<string | null>(null)
  const selected = radarTargets.find((t) => t.id === selectedTarget)

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="mx-auto max-w-7xl px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <Target className="h-4 w-4 text-primary" />
                </div>
                <span className="text-lg font-bold text-foreground">SightLine</span>
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm text-muted-foreground">Market Radar</span>
            </div>
            <nav className="flex items-center gap-6">
              <Link href="/app/mission" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Mission
              </Link>
              <Link href="/app/signals" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Signals
              </Link>
              <Link href="/app/strategy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Strategy
              </Link>
              <Link href="/app/performance" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Performance
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-5 py-8">
        {/* Page title */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">Market Radar</h1>
          <p className="mt-1 text-sm text-muted-foreground">Visualize opportunity strength. Closer to center = stronger setup.</p>
        </div>

        <div className="grid gap-8 lg:grid-cols-[1fr_350px]">
          {/* Radar visualization */}
          <div className="rounded-2xl border border-border bg-card p-8">
            <div className="relative mx-auto aspect-square max-w-lg">
              {/* Radar rings */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="h-full w-full rounded-full border border-border/30" />
              </div>
              <div className="absolute inset-[15%] flex items-center justify-center">
                <div className="h-full w-full rounded-full border border-border/40" />
              </div>
              <div className="absolute inset-[30%] flex items-center justify-center">
                <div className="h-full w-full rounded-full border border-border/50" />
              </div>
              <div className="absolute inset-[45%] flex items-center justify-center">
                <div className="h-full w-full rounded-full border border-primary/30 bg-primary/5" />
              </div>

              {/* Center pulse */}
              <div className="absolute inset-[48%] flex items-center justify-center">
                <div className="h-full w-full rounded-full bg-primary/20 animate-pulse" />
              </div>

              {/* Crosshairs */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="absolute h-full w-px bg-border/30" />
                <div className="absolute h-px w-full bg-border/30" />
              </div>

              {/* Radar sweep animation */}
              <div className="absolute inset-0 animate-[spin_8s_linear_infinite]">
                <div className="absolute left-1/2 top-1/2 h-1/2 w-px origin-top -translate-x-1/2 bg-gradient-to-b from-primary/50 to-transparent" />
              </div>

              {/* Targets */}
              {radarTargets.map((target) => {
                const radians = (target.angle * Math.PI) / 180
                const x = 50 + (target.distance * Math.cos(radians))
                const y = 50 + (target.distance * Math.sin(radians))
                
                return (
                  <button
                    key={target.id}
                    onClick={() => setSelectedTarget(target.id)}
                    className={`absolute flex items-center justify-center transition-all ${
                      selectedTarget === target.id ? "z-10 scale-125" : "hover:scale-110"
                    }`}
                    style={{
                      left: `${x}%`,
                      top: `${y}%`,
                      transform: "translate(-50%, -50%)",
                    }}
                  >
                    <div className={`flex h-10 w-10 items-center justify-center rounded-full border-2 ${
                      target.status === "strong" 
                        ? "border-primary bg-primary/20 text-primary" 
                        : target.status === "forming"
                        ? "border-primary/50 bg-primary/10 text-primary/80"
                        : "border-muted bg-muted/20 text-muted-foreground"
                    } ${selectedTarget === target.id ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""}`}>
                      <span className="text-xs font-bold">{target.asset}</span>
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Legend */}
            <div className="mt-6 flex items-center justify-center gap-6 text-xs text-muted-foreground">
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full border-2 border-primary bg-primary/20" />
                <span>Strong</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full border-2 border-primary/50 bg-primary/10" />
                <span>Forming</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="h-3 w-3 rounded-full border-2 border-muted bg-muted/20" />
                <span>Weak</span>
              </div>
            </div>
          </div>

          {/* Selected target details */}
          <div className="rounded-2xl border border-border bg-card p-5">
            <h2 className="mb-4 text-sm font-semibold text-foreground">Target Details</h2>
            
            {selected ? (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-foreground">{selected.asset}</span>
                  <span className={`rounded px-2 py-1 text-xs font-semibold ${
                    selected.status === "strong" 
                      ? "bg-primary/20 text-primary" 
                      : selected.status === "forming"
                      ? "bg-primary/10 text-primary/80"
                      : "bg-muted text-muted-foreground"
                  }`}>
                    {selected.status.charAt(0).toUpperCase() + selected.status.slice(1)}
                  </span>
                </div>

                <div>
                  <span className="text-xs text-muted-foreground">Signal Strength</span>
                  <div className="mt-2 flex items-center gap-3">
                    <div className="h-2 flex-1 rounded-full bg-border">
                      <div 
                        className="h-full rounded-full bg-primary transition-all"
                        style={{ width: `${selected.strength}%` }}
                      />
                    </div>
                    <span className="text-sm font-semibold text-foreground">{selected.strength}%</span>
                  </div>
                </div>

                <Link
                  href={`/app/signal/${selected.id}`}
                  className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary text-sm font-semibold text-primary-foreground transition-all hover:bg-primary/90"
                >
                  View Signal
                  <ArrowUpRight className="h-4 w-4" />
                </Link>
              </div>
            ) : (
              <div className="flex h-40 items-center justify-center text-sm text-muted-foreground">
                Click a target to view details
              </div>
            )}

            {/* Opportunity list */}
            <div className="mt-6 border-t border-border pt-5">
              <h3 className="mb-3 text-xs font-semibold text-muted-foreground uppercase tracking-wider">All Opportunities</h3>
              <div className="space-y-2">
                {radarTargets.map((target) => (
                  <button
                    key={target.id}
                    onClick={() => setSelectedTarget(target.id)}
                    className={`flex w-full items-center justify-between rounded-lg p-3 transition-all ${
                      selectedTarget === target.id 
                        ? "bg-primary/10 border border-primary/30" 
                        : "bg-secondary/50 hover:bg-secondary"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <span className={`h-2 w-2 rounded-full ${
                        target.status === "strong" ? "bg-primary" : 
                        target.status === "forming" ? "bg-primary/50" : "bg-muted"
                      }`} />
                      <span className="text-sm font-medium text-foreground">{target.asset}</span>
                    </div>
                    <span className="text-xs text-muted-foreground">{target.strength}%</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
