import { Metadata } from "next"
import Link from "next/link"
import { Target, TrendingUp, TrendingDown, BarChart3 } from "lucide-react"

export const metadata: Metadata = {
  title: "Performance - SightLine",
  description: "Your trading performance metrics",
}

const metrics = {
  totalTrades: 47,
  winRate: 61,
  avgR: 1.4,
  totalR: 65.8,
  bestAsset: "BTC",
  worstAsset: "SPY",
  profitFactor: 2.1,
}

const tradeHistory = [
  { id: 1, asset: "BTC", entry: "64,200", exit: "65,300", result: "Win", rMultiple: "+2.2R", date: "Mar 2, 2026" },
  { id: 2, asset: "SOL", entry: "142.50", exit: "139.20", result: "Loss", rMultiple: "-1R", date: "Mar 1, 2026" },
  { id: 3, asset: "ETH", entry: "3,420", exit: "3,580", result: "Win", rMultiple: "+1.6R", date: "Feb 28, 2026" },
  { id: 4, asset: "BTC", entry: "63,800", exit: "64,900", result: "Win", rMultiple: "+1.8R", date: "Feb 27, 2026" },
  { id: 5, asset: "NVDA", entry: "892.50", exit: "878.30", result: "Loss", rMultiple: "-1R", date: "Feb 26, 2026" },
  { id: 6, asset: "SOL", entry: "138.80", exit: "145.60", result: "Win", rMultiple: "+2.0R", date: "Feb 25, 2026" },
  { id: 7, asset: "SPY", entry: "512.40", exit: "509.80", result: "Loss", rMultiple: "-1R", date: "Feb 24, 2026" },
  { id: 8, asset: "BTC", entry: "62,500", exit: "64,200", result: "Win", rMultiple: "+2.4R", date: "Feb 23, 2026" },
]

export default function PerformancePage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="mx-auto max-w-5xl px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <Target className="h-4 w-4 text-primary" />
                </div>
                <span className="text-lg font-bold text-foreground">SightLine</span>
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm text-muted-foreground">Performance</span>
            </div>
            <nav className="flex items-center gap-6">
              <Link href="/app/mission" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Mission
              </Link>
              <Link href="/app/radar" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Radar
              </Link>
              <Link href="/app/signals" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Signals
              </Link>
              <Link href="/app/strategy" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Strategy
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-5xl px-5 py-8">
        {/* Page title */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-foreground md:text-3xl">Performance</h1>
          <p className="mt-1 text-sm text-muted-foreground">Track your trading results and metrics</p>
        </div>

        {/* Metrics grid */}
        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Trades</span>
              <BarChart3 className="h-4 w-4 text-primary" />
            </div>
            <p className="mt-2 text-3xl font-bold text-foreground">{metrics.totalTrades}</p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Win Rate</span>
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
            <p className="mt-2 text-3xl font-bold text-primary">{metrics.winRate}%</p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Average R</span>
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
            <p className="mt-2 text-3xl font-bold text-foreground">{metrics.avgR}R</p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total R</span>
              <TrendingUp className="h-4 w-4 text-primary" />
            </div>
            <p className="mt-2 text-3xl font-bold text-primary">+{metrics.totalR}R</p>
          </div>
        </div>

        {/* Additional metrics */}
        <div className="mb-8 grid gap-4 sm:grid-cols-3">
          <div className="rounded-2xl border border-border bg-card p-5">
            <span className="text-sm text-muted-foreground">Best Asset</span>
            <p className="mt-2 text-xl font-bold text-primary">{metrics.bestAsset}</p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5">
            <span className="text-sm text-muted-foreground">Worst Asset</span>
            <p className="mt-2 text-xl font-bold text-destructive">{metrics.worstAsset}</p>
          </div>

          <div className="rounded-2xl border border-border bg-card p-5">
            <span className="text-sm text-muted-foreground">Profit Factor</span>
            <p className="mt-2 text-xl font-bold text-foreground">{metrics.profitFactor}</p>
          </div>
        </div>

        {/* Trade History */}
        <div className="rounded-2xl border border-border bg-card overflow-hidden">
          <div className="p-5 border-b border-border">
            <h2 className="text-lg font-semibold text-foreground">Trade History</h2>
          </div>

          {/* Table header */}
          <div className="hidden sm:grid grid-cols-6 gap-4 px-5 py-3 bg-secondary/50 text-xs font-semibold text-muted-foreground uppercase tracking-wider">
            <span>Asset</span>
            <span>Entry</span>
            <span>Exit</span>
            <span>Result</span>
            <span>R Multiple</span>
            <span>Date</span>
          </div>

          {/* Table rows */}
          <div className="divide-y divide-border">
            {tradeHistory.map((trade) => (
              <div key={trade.id} className="grid sm:grid-cols-6 gap-2 sm:gap-4 px-5 py-4 hover:bg-secondary/30 transition-colors">
                <div className="flex items-center justify-between sm:block">
                  <span className="font-semibold text-foreground">{trade.asset}</span>
                  <span className="sm:hidden text-sm text-muted-foreground">{trade.date}</span>
                </div>
                <div className="hidden sm:block">
                  <span className="text-sm text-foreground">{trade.entry}</span>
                </div>
                <div className="hidden sm:block">
                  <span className="text-sm text-foreground">{trade.exit}</span>
                </div>
                <div className="flex items-center gap-2 sm:block">
                  <span className={`inline-flex items-center gap-1 text-sm font-medium ${
                    trade.result === "Win" ? "text-primary" : "text-destructive"
                  }`}>
                    {trade.result === "Win" ? (
                      <TrendingUp className="h-3 w-3" />
                    ) : (
                      <TrendingDown className="h-3 w-3" />
                    )}
                    {trade.result}
                  </span>
                </div>
                <div>
                  <span className={`text-sm font-semibold ${
                    trade.rMultiple.startsWith("+") ? "text-primary" : "text-destructive"
                  }`}>
                    {trade.rMultiple}
                  </span>
                </div>
                <div className="hidden sm:block">
                  <span className="text-sm text-muted-foreground">{trade.date}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <p className="mt-4 text-xs text-muted-foreground text-center">
          Performance data is based on signals taken. Past performance does not guarantee future results.
        </p>
      </main>
    </div>
  )
}
