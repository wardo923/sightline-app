import { Metadata } from "next"
import Link from "next/link"
import { Target, Settings, TrendingUp, Clock, Shield, BarChart3 } from "lucide-react"

export const metadata: Metadata = {
  title: "Strategy - SightLine",
  description: "Your trading strategy profile",
}

// Mock strategy profile based on wizard answers
const strategyProfile = {
  market: "Crypto",
  strategy: "Breakout Momentum",
  timeframe: "15m",
  risk: "Moderate",
  instruments: ["BTC", "ETH", "SOL"],
  behaviors: ["Volatility Breakouts", "Momentum Continuation"],
  createdAt: "Feb 15, 2026",
}

const expectations = {
  typicalWinRate: "55-65%",
  avgWin: "2R",
  avgLoss: "1R",
  expectedLosingStreak: "4 trades",
  expectedWinStreak: "6 trades",
}

export default function StrategyPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="mx-auto max-w-4xl px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                  <Target className="h-4 w-4 text-primary" />
                </div>
                <span className="text-lg font-bold text-foreground">SightLine</span>
              </Link>
              <span className="text-muted-foreground">/</span>
              <span className="text-sm text-muted-foreground">Strategy</span>
            </div>
            <nav className="flex items-center gap-6">
              <Link href="/app/mission" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Mission
              </Link>
              <Link href="/app/radar" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Radar
              </Link>
              <Link href="/app/signals" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Signals
              </Link>
              <Link href="/app/performance" className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                Performance
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-5 py-8">
        {/* Page title */}
        <div className="mb-8 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground md:text-3xl">Your Strategy</h1>
            <p className="mt-1 text-sm text-muted-foreground">Built from your wizard responses</p>
          </div>
          <Link
            href="/wizard"
            className="flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-foreground hover:border-primary/30 transition-colors"
          >
            <Settings className="h-4 w-4" />
            Edit Strategy
          </Link>
        </div>

        {/* Strategy Profile */}
        <div className="mb-8 rounded-2xl border border-border bg-card p-6">
          <h2 className="mb-6 text-lg font-semibold text-foreground">Strategy Profile</h2>
          
          <div className="grid gap-6 sm:grid-cols-2">
            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Market</span>
                <p className="text-lg font-semibold text-foreground">{strategyProfile.market}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <BarChart3 className="h-5 w-5 text-primary" />
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Strategy</span>
                <p className="text-lg font-semibold text-foreground">{strategyProfile.strategy}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Clock className="h-5 w-5 text-primary" />
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Timeframe</span>
                <p className="text-lg font-semibold text-foreground">{strategyProfile.timeframe}</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                <Shield className="h-5 w-5 text-primary" />
              </div>
              <div>
                <span className="text-xs text-muted-foreground">Risk Profile</span>
                <p className="text-lg font-semibold text-foreground">{strategyProfile.risk}</p>
              </div>
            </div>
          </div>

          <div className="mt-6 border-t border-border pt-6">
            <div className="mb-4">
              <span className="text-xs text-muted-foreground">Instruments</span>
              <div className="mt-2 flex flex-wrap gap-2">
                {strategyProfile.instruments.map((instrument) => (
                  <span key={instrument} className="rounded-lg bg-secondary px-3 py-1.5 text-sm font-medium text-foreground">
                    {instrument}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <span className="text-xs text-muted-foreground">Behaviors</span>
              <div className="mt-2 flex flex-wrap gap-2">
                {strategyProfile.behaviors.map((behavior) => (
                  <span key={behavior} className="rounded-lg bg-primary/10 px-3 py-1.5 text-sm font-medium text-primary">
                    {behavior}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <p className="mt-6 text-xs text-muted-foreground">Strategy created on {strategyProfile.createdAt}</p>
        </div>

        {/* Strategy Expectations */}
        <div className="rounded-2xl border border-border bg-card p-6">
          <h2 className="mb-6 text-lg font-semibold text-foreground">Strategy Expectations</h2>
          <p className="mb-6 text-sm text-muted-foreground">
            Based on historical data for similar strategy configurations
          </p>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-xl bg-secondary/50 p-4">
              <span className="text-xs text-muted-foreground">Typical Win Rate</span>
              <p className="mt-1 text-xl font-bold text-primary">{expectations.typicalWinRate}</p>
            </div>

            <div className="rounded-xl bg-secondary/50 p-4">
              <span className="text-xs text-muted-foreground">Average Win</span>
              <p className="mt-1 text-xl font-bold text-primary">{expectations.avgWin}</p>
            </div>

            <div className="rounded-xl bg-secondary/50 p-4">
              <span className="text-xs text-muted-foreground">Average Loss</span>
              <p className="mt-1 text-xl font-bold text-destructive">{expectations.avgLoss}</p>
            </div>

            <div className="rounded-xl bg-secondary/50 p-4">
              <span className="text-xs text-muted-foreground">Expected Losing Streak</span>
              <p className="mt-1 text-xl font-bold text-foreground">{expectations.expectedLosingStreak}</p>
            </div>

            <div className="rounded-xl bg-secondary/50 p-4">
              <span className="text-xs text-muted-foreground">Expected Win Streak</span>
              <p className="mt-1 text-xl font-bold text-foreground">{expectations.expectedWinStreak}</p>
            </div>
          </div>

          <div className="mt-6 rounded-xl bg-primary/5 border border-primary/20 p-4">
            <p className="text-sm text-foreground">
              <strong>Note:</strong> These are statistical expectations, not guarantees. 
              Trading involves risk. Past performance does not guarantee future results.
            </p>
          </div>
        </div>
      </main>
    </div>
  )
}
