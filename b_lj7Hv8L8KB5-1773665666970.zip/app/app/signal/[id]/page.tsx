"use client"

import { useState } from "react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { Target, ArrowLeft, TrendingUp, AlertTriangle, BarChart3, FileText, Info } from "lucide-react"

// Mock signal data
const signalData: Record<string, {
  asset: string
  timeframe: string
  direction: "BUY" | "SELL"
  probability: number
  grade: string
  entry: string
  stop: string
  target: string
  expectedPath: string
  pressure: number
  riskSteps: { current: number, max: number }
  performance: {
    winRate: number
    avgWin: string
    sampleSize: number
  }
}> = {
  "btc-15m-1": {
    asset: "BTC",
    timeframe: "15m",
    direction: "BUY",
    probability: 84,
    grade: "A",
    entry: "64,200",
    stop: "63,700",
    target: "65,300",
    expectedPath: "dip → consolidation → breakout",
    pressure: 82,
    riskSteps: { current: 5, max: 25 },
    performance: { winRate: 59, avgWin: "2.1R", sampleSize: 842 },
  },
  "sol-1h-1": {
    asset: "SOL",
    timeframe: "1h",
    direction: "BUY",
    probability: 72,
    grade: "B+",
    entry: "142.50",
    stop: "138.20",
    target: "152.00",
    expectedPath: "range → breakout",
    pressure: 68,
    riskSteps: { current: 8, max: 25 },
    performance: { winRate: 55, avgWin: "1.8R", sampleSize: 324 },
  },
}

// Default signal for unknown IDs
const defaultSignal = {
  asset: "BTC",
  timeframe: "15m",
  direction: "BUY" as const,
  probability: 84,
  grade: "A",
  entry: "64,200",
  stop: "63,700",
  target: "65,300",
  expectedPath: "dip → consolidation → breakout",
  pressure: 82,
  riskSteps: { current: 5, max: 25 },
  performance: { winRate: 59, avgWin: "2.1R", sampleSize: 842 },
}

export default function SignalDetailPage() {
  const params = useParams()
  const id = params.id as string
  const signal = signalData[id] || defaultSignal
  
  const [notes, setNotes] = useState("")
  const [activeTab, setActiveTab] = useState<"overview" | "risk" | "performance" | "notes">("overview")

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-40">
        <div className="mx-auto max-w-4xl px-5 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/app/signals" className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors">
                <ArrowLeft className="h-4 w-4" />
                <span className="text-sm">Back to Signals</span>
              </Link>
            </div>
            <Link href="/" className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
                <Target className="h-4 w-4 text-primary" />
              </div>
              <span className="text-lg font-bold text-foreground">SightLine</span>
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-4xl px-5 py-8">
        {/* Signal header */}
        <div className="mb-8 flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3">
              <h1 className="text-3xl font-bold text-foreground">{signal.asset}</h1>
              <span className="text-lg text-muted-foreground">/ {signal.timeframe}</span>
            </div>
            <span className={`mt-2 inline-block rounded px-3 py-1 text-sm font-semibold ${
              signal.direction === "BUY" 
                ? "bg-primary/20 text-primary" 
                : "bg-destructive/20 text-destructive"
            }`}>
              {signal.direction}
            </span>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold text-primary">{signal.probability}%</div>
            <span className="text-sm text-muted-foreground">Probability</span>
            <div className={`mt-2 inline-block rounded-lg px-3 py-1 text-lg font-bold ${
              signal.grade.startsWith("A") 
                ? "bg-primary/20 text-primary" 
                : "bg-primary/10 text-primary/80"
            }`}>
              Grade {signal.grade}
            </div>
          </div>
        </div>

        {/* Entry / Stop / Target */}
        <div className="mb-8 grid grid-cols-3 gap-4 rounded-2xl border border-border bg-card p-6">
          <div className="text-center">
            <span className="text-sm text-muted-foreground">Entry</span>
            <p className="mt-1 text-2xl font-bold text-foreground">{signal.entry}</p>
          </div>
          <div className="text-center border-x border-border">
            <span className="text-sm text-muted-foreground">Stop</span>
            <p className="mt-1 text-2xl font-bold text-destructive">{signal.stop}</p>
          </div>
          <div className="text-center">
            <span className="text-sm text-muted-foreground">Target</span>
            <p className="mt-1 text-2xl font-bold text-primary">{signal.target}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="mb-6 flex gap-2 border-b border-border">
          {[
            { id: "overview", label: "Overview", icon: Info },
            { id: "risk", label: "Risk", icon: AlertTriangle },
            { id: "performance", label: "Performance", icon: BarChart3 },
            { id: "notes", label: "Notes", icon: FileText },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors ${
                activeTab === tab.id
                  ? "border-b-2 border-primary text-primary"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <tab.icon className="h-4 w-4" />
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <div className="rounded-2xl border border-border bg-card p-6">
          {activeTab === "overview" && (
            <div className="space-y-6">
              <div>
                <h3 className="mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider">Expected Path</h3>
                <p className="text-lg text-foreground">{signal.expectedPath}</p>
              </div>
              
              <div>
                <h3 className="mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider">Pressure Meter</h3>
                <div className="flex items-center gap-4">
                  <div className="h-3 flex-1 rounded-full bg-border">
                    <div 
                      className="h-full rounded-full bg-primary transition-all"
                      style={{ width: `${signal.pressure}%` }}
                    />
                  </div>
                  <span className="text-xl font-bold text-foreground">{signal.pressure}%</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">
                  {signal.pressure >= 80 ? "Breakout likely" : signal.pressure >= 60 ? "Building pressure" : "Low compression"}
                </p>
              </div>

              <div>
                <h3 className="mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider">Why This Signal Fired</h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    Breakout structure detected
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    Momentum confirmation
                  </li>
                  <li className="flex items-center gap-2">
                    <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                    Volatility compression
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeTab === "risk" && (
            <div className="space-y-6">
              <div>
                <h3 className="mb-3 text-sm font-semibold text-muted-foreground uppercase tracking-wider">Risk Cliff</h3>
                <p className="mb-4 text-sm text-muted-foreground">Distance to stop loss measured in price steps</p>
                
                {/* Risk cliff visualization */}
                <div className="relative h-8 rounded-lg bg-border overflow-hidden">
                  <div 
                    className="absolute left-0 top-0 h-full bg-gradient-to-r from-primary to-destructive"
                    style={{ width: `${(signal.riskSteps.current / signal.riskSteps.max) * 100}%` }}
                  />
                  <div className="absolute inset-0 flex items-center justify-center text-sm font-bold text-foreground">
                    Step {signal.riskSteps.current} / {signal.riskSteps.max}
                  </div>
                </div>
                
                <div className="mt-4 flex justify-between text-xs text-muted-foreground">
                  <span>Entry</span>
                  <span>Stop Loss</span>
                </div>
              </div>

              <div className="rounded-xl bg-secondary/50 p-4">
                <p className="text-sm text-foreground">
                  <strong>Current position:</strong> {signal.riskSteps.current} steps from entry. 
                  Stop loss is {signal.riskSteps.max - signal.riskSteps.current} steps away.
                </p>
              </div>
            </div>
          )}

          {activeTab === "performance" && (
            <div className="space-y-6">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Similar Setup Statistics</h3>
              
              <div className="grid grid-cols-3 gap-6">
                <div className="rounded-xl bg-secondary/50 p-4 text-center">
                  <span className="text-xs text-muted-foreground">Win Rate</span>
                  <p className="mt-1 text-2xl font-bold text-primary">{signal.performance.winRate}%</p>
                </div>
                <div className="rounded-xl bg-secondary/50 p-4 text-center">
                  <span className="text-xs text-muted-foreground">Average Win</span>
                  <p className="mt-1 text-2xl font-bold text-foreground">{signal.performance.avgWin}</p>
                </div>
                <div className="rounded-xl bg-secondary/50 p-4 text-center">
                  <span className="text-xs text-muted-foreground">Sample Size</span>
                  <p className="mt-1 text-2xl font-bold text-foreground">{signal.performance.sampleSize}</p>
                </div>
              </div>

              <p className="text-xs text-muted-foreground">
                Based on historical analysis of similar setups across the same asset and timeframe.
              </p>
            </div>
          )}

          {activeTab === "notes" && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">Trade Notes</h3>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add your notes for this trade..."
                className="w-full h-40 rounded-xl border border-border bg-secondary/50 p-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none"
              />
              <button className="h-10 px-6 rounded-lg bg-primary text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors">
                Save Notes
              </button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
