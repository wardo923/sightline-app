import type { Metadata } from "next"
import { redirect } from "next/navigation"

export const metadata: Metadata = {
  title: "Strategy Wizard - SightLine Advanced Trading Analytics",
  description:
    "Build your personalized trading strategy in 12 simple steps. SightLine Proprietary Strategy Wizard™ generates clean, risk-defined setups.",
}

// Redirect to master wizard route
export default function WizardPage() {
  redirect("/strategy-wizard")
}
